﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Base4Entity.MyUIControls.UIForms;

namespace Base4Entity
{
    public partial class Form2 : BrowseBase4<CONTACTS_BASE>
    {
        public Form2()
        {
            InitializeComponent();
        }
    }
}

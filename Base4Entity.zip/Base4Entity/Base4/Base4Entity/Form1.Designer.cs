﻿using System.ComponentModel;
using Base4Entity.MyUIControls.Controls;

namespace Base4Entity
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkedComboBox1 = new CheckedComboBox();
            this.SuspendLayout();
            // 
            // checkedComboBox1
            // 
            this.checkedComboBox1.BindingField = null;
            this.checkedComboBox1.CheckOnClick = true;
            this.checkedComboBox1.DataBindings = null;
            this.checkedComboBox1.DropDownHeight = 1;
            this.checkedComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
            this.checkedComboBox1.FieldName = null;
            this.checkedComboBox1.FormattingEnabled = true;
            this.checkedComboBox1.HasRules = false;
            this.checkedComboBox1.IntegralHeight = false;
            this.checkedComboBox1.ItemHeight = 23;
            this.checkedComboBox1.Location = new System.Drawing.Point(313, 150);
            this.checkedComboBox1.MyExpression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.checkedComboBox1.Name = "checkedComboBox1";
            this.checkedComboBox1.Size = new System.Drawing.Size(390, 29);
            this.checkedComboBox1.Style = Base4Controls.Base4ColorStyle.Blue;
            this.checkedComboBox1.TabIndex = 0;
            this.checkedComboBox1.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.checkedComboBox1.UseSelectable = true;
            this.checkedComboBox1.ValueSeparator = ", ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.checkedComboBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CheckedComboBox checkedComboBox1;
    }
}


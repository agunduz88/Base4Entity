﻿using System.Drawing;

namespace Base4Entity.BaseTemplates
{
    class BaseTemplate
    {
        #region BrowseDialogColors

        public  Color BrowseDialogBackgroundColor { get; set; }

        public  Color BrowseDialogTextColor { get; set; }

        #endregion

        #region CrudColors
        public  Color CrudBackgroundColor { get; set; }
        public  Color CrudTextColor { get; set; }
        #endregion

        #region MessageBoxColors
        public  Color MessageBoxBackgroundColor { get; set; }
        public  Color MessageBoxTextColor { get; set; }
        #endregion

        #region Misc
        public  Color BrowseDialogToolStripColor { get; set; }
        #endregion
    }
}

﻿using System.Drawing;

namespace Base4Entity.BaseTemplates
{
    internal class Classic:BaseTemplate
    {
        public Classic()
        {
            #region BrowseDialogColors
            BrowseDialogBackgroundColor = Color.FromArgb(1, 1, 1);
            BrowseDialogTextColor = Color.FromArgb(1, 1, 1);
            #endregion

            #region CrudColors
            CrudBackgroundColor = Color.FromArgb(1, 1, 1);
            CrudTextColor = Color.FromArgb(1, 1, 1);
            #endregion

            #region MessageBoxColors
            MessageBoxBackgroundColor = Color.FromArgb(1, 1, 1);
            MessageBoxTextColor = Color.FromArgb(1, 1, 1);
            #endregion

            #region Misc
            BrowseDialogToolStripColor = Color.FromArgb(1, 1, 1);
            #endregion
        }    
    }
}

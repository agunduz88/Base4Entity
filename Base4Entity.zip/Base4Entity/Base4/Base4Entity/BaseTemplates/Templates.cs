﻿namespace Base4Entity.BaseTemplates
{
    public enum Templates
    {
        Classic = 0,Sahra = 1
    }
}
﻿using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Base4Entity.BUSINESS_LAYER;
using Base4Entity.Extensions;
using Base4Entity.MyUIControls.Controls;
using Base4Entity.MyUIControls.UIForms;
using Base4Entity.UITypeEditors;

//using Base4Entity.BUSINESS_LAYER;
//using Base4Entity.MyUIControls.Controls;
//using Base4Entity.MyUIControls.UIForms;

namespace Base4Entity.EFHelper
{
    public class MyControls
    {

        public static Control MyGetSearchFieldControl(MySearchFields pBindingField)
        {
            Control loControl = null;
            //CONTACTS_BASE A = null;
            //A.Age = 5;
            switch (pBindingField.ControlType)
            {
                case ControlTypes.ComboBox:
                    loControl = new Base4ComboBox();                    
                    if (loControl is Base4ComboBox base4ComboBox)
                    {

                        base4ComboBox.Text = pBindingField.ValueMember;
                        base4ComboBox.BindingField = pBindingField.BindingField;
                        base4ComboBox.MyExpression = pBindingField.ExpressionType;
                        base4ComboBox.ValueMember = pBindingField.ValueMember;
                        base4ComboBox.DisplayMember = pBindingField.DisplayMember;
                        base4ComboBox.EditingState = Base4Crud.CrudActions.Idle;
                        var a = Generic.MyFillAll(pBindingField.ChildEntity,
                            pBindingField.ValueMember, pBindingField.DisplayMember);
                        base4ComboBox.DataSource = a;

                    }                 
                    break;


                case ControlTypes.CheckedComboBox:
                    loControl = new CheckedComboBox();
                    if (loControl is CheckedComboBox checkedComboBox)
                    {

                        checkedComboBox.Text = pBindingField.ValueMember;
                        checkedComboBox.BindingField = pBindingField.BindingField;
                        checkedComboBox.MyExpression = pBindingField.ExpressionType;
                        checkedComboBox.ValueMember = pBindingField.ValueMember;
                        checkedComboBox.DisplayMember = pBindingField.DisplayMember;
                        checkedComboBox.EditingState = Base4Crud.CrudActions.Idle;
                        var a = Generic.MyFillAll(pBindingField.ChildEntity,
                            pBindingField.ValueMember, pBindingField.DisplayMember);

                        checkedComboBox.ValueSeparator = ", ";

                        var i = 0;
                        foreach (var variable in a)
                        {
                            if (i == 0)
                            {
                                i++;
                                continue;
                            }
                            checkedComboBox.Items.Add(variable);                           
                        }
                        //Size size = 
                        var maxWidth = (from object obj in checkedComboBox.Items select TextRenderer.MeasureText(obj.GetPropValue(pBindingField.DisplayMember).ToString(), checkedComboBox.Font).Width).Concat(new[] { 0 }).Max();
                        checkedComboBox.Width = maxWidth+40;
                        //checkedComboBox.DataSource = a;
                        checkedComboBox.Text = @"<Select>";
                    }

                    break;
                case ControlTypes.TextBox:
                    loControl = new Base4TextBox();
                    if (loControl is Base4TextBox Base4TextBox)
                    {
                        Base4TextBox.Expression = pBindingField.ExpressionType;
                        Base4TextBox.BindingField = pBindingField.BindingField;
                        //((Base4TextBox)loControl).LabelName = pBindingField.BindingField;
                        SetControlProperties(Base4TextBox);
                        Base4TextBox.Theme = BaseConfigurations.BaseConfigurations.Theme;
                        Base4TextBox.Style = BaseConfigurations.BaseConfigurations.Style;
                        Base4TextBox.Width = Base4TextBox.BindingField.Contains("NAME")
                            ? 200
                            : Base4TextBox.Width;
                    }
                    
                    break;
                case ControlTypes.DateTimePicker:
                    loControl = new Base4DateTime();
                    if (loControl is Base4DateTime Base4DateTime)
                    {
                        Base4DateTime.Expression = pBindingField.ExpressionType;
                        Base4DateTime.BindingField = pBindingField.BindingField;
                        //((Base4TextBox)loControl).LabelName = pBindingField.BindingField;
                        //SetControlProperties((Base4DateTime)loControl);
                        Base4DateTime.Theme = BaseConfigurations.BaseConfigurations.Theme;
                        Base4DateTime.Style = BaseConfigurations.BaseConfigurations.Style;
                        Base4DateTime.Value = null;
                    }
                   
                    break;
            }


            return loControl;
        }

        private static void SetControlProperties(Base4TextBox pControl)
        {
            pControl.CustomButton.Image = null;
            //pControl.CustomButton.Location = new System.Drawing.Point(53, 1);
            //pControl.CustomButton.Name = "";
           
            //pControl.CustomButton.Style = Base4Controls.Base4ColorStyle.Blue;
            pControl.CustomButton.TabIndex = 1;
            //pControl.CustomButton.Theme = Base4Controls.Base4ThemeStyle.Light;
            pControl.CustomButton.UseSelectable = true;
            pControl.CustomButton.Visible = false;
            pControl.Text = pControl.Text;
            //pControl.Expression = MyExpressions.Equals;
            pControl.HasRules = false;
            //pControl.Lines = new string[] {
            //    "base4TextBox1"};
            //pControl.Location = new System.Drawing.Point(162, 223);
            pControl.MaxLength = 32767;
            //pControl.Name = pControl.BindingField;
            pControl.PasswordChar = '\0';
            pControl.ScrollBars = ScrollBars.None;
            pControl.SelectedText = "";
            pControl.SelectionLength = 0;
            pControl.SelectionStart = 0;
            pControl.ShortcutsEnabled = true;
            pControl.Size = new Size(75, 23);
            pControl.TabIndex = 2;            
            pControl.UseSelectable = true;
            pControl.WaterMarkColor = Color.FromArgb(109, 109, 109);
            pControl.WaterMarkFont = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Pixel);
        }
              
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Base4Entity.MyUIControls.Controls;
using efcfwf.MyUIControls.Controls;

namespace Base4Entity.EFHelper
{
    public class BaseMessages
    {

        public static DialogResult BaseShowMessages(string pHeader, string pTitle, MessageBoxButtons pButtons, MessageBoxIcon pIcon)
        {
            return MessageBox.Show(pTitle, pHeader, pButtons, pIcon);
        }

        

        
        public static async Task<MySearchBox> BaseMessageSearchAsync(Form pForm)
        {
            var errorbox = new MySearchBox();

            errorbox.Location = new Point(pForm.Right + 10, pForm.Top - errorbox.Height - 10);
            errorbox.TopMost = true;
            //errorbox.BackColor = Color.DodgerBlue;

            return errorbox;         
        }

        public static BaseErrorBox BaseMessageDialog(Form pForm, string title, string message)
        {
            var errorbox = new BaseErrorBox(title, message, Animations.Icon.Error, Animations.AnimateStyle.FadeIn);
            errorbox.Location = new Point(pForm.Left + 10, pForm.Bottom - errorbox.Height - 10);

            //using (errorbox)
            //{
            return errorbox;// errorbox.Show();
            //}                       
            //return new BaseErrorBox(title, message, Animations.Icon.Error, Animations.AnimateStyle.FadeIn);
        }


        public static void BaseMessageDialog( Form pForm, List<ValidationResult> pErrors)
        {
            var title = string.Empty;
            var message = $"{pErrors.Count} Errors Found";

            title = pErrors.Aggregate(title, (current, error) => current + $"{error.ErrorMessage}\n");

            var errorbox = new BaseErrorBox(title, message, Animations.Icon.Error, Animations.AnimateStyle.FadeIn);
            errorbox.Location = new Point(pForm.Left + 10, pForm.Bottom - errorbox.Height - 10);

            
                errorbox.Show();
            //return new BaseErrorBox(title, message,Animations.Icon.Error, Animations.AnimateStyle.FadeIn);
        }
    }
}

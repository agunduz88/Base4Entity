﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Windows.Forms;
using Base4Controls.Controls;
using Base4Entity.Extensions;
using Base4Entity.MyUIControls.Controls;
using Base4Entity.MyUIControls.Properties;

namespace Base4Entity.EFHelper
{   
    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]   
    public  class BaseSql<TParentEntity> where TParentEntity : class 
    {
        #region Properties
        private readonly DbContext _loContext;
        private  IQueryable _loBo;
        protected  Dictionary<string, bool> AllFields;
        private readonly Dictionary<string, List<MyQueryFields>> _myQueryFieldsList;
        private readonly List<string> _tablesUsed = new List<string>();
        #endregion

        #region Constructors
        public BaseSql(DbContext pContext, IQueryable pBo)
        {
            _loContext = pContext;
            _loBo = pBo;
            AllFields = new Dictionary<string, bool>();
            _myQueryFieldsList = new Dictionary<string, List<MyQueryFields>>();

            AllFields = EntityBase.BaseGetTableFieldList<TParentEntity>(true);
            
        }
        #endregion

        #region Joins
        internal void AddJoin(string pParentTable, string pChildTable, string pParentKey, string pChildKey)
        {
            if (!_tablesUsed.Contains(pParentTable))
                _tablesUsed.Add(pParentTable);

            if (!_tablesUsed.Contains(pChildTable))
                _tablesUsed.Add(pChildTable);

            if (_myQueryFieldsList.All(x => x.Key.Contains(pParentTable)) && _myQueryFieldsList.Count != 0)
            {

                foreach (var childJoin in _myQueryFieldsList[pParentTable])
                {
                    if (childJoin.ChildTable != pChildTable && childJoin.ParentKey != pParentKey &&
                        childJoin.ChildKey != pChildKey)
                    {
                        _myQueryFieldsList[pParentTable].Add(new MyQueryFields(pChildTable,pChildKey,pParentKey));
                      
                    }
                }        
            }
            else
            {
                var queryFields = new MyQueryFields
                {
                    ChildKey = (pChildKey),
                    ParentKey = (pParentKey),
                    ChildTable = (pChildTable)
                };


                _myQueryFieldsList.Add(pParentTable, new List<MyQueryFields> {queryFields});
              
                //Child Table alanlarını alıp select içerisine yazılacak alanlara set edelim
                var childTableFields = EntityBase.BaseGetTableFieldList(pChildTable);
                foreach (var field in childTableFields)
                {
                    AllFields.Add(field.Key, field.Value);
                }
            }

            
        }
        //protected  internal IQueryable MyProcessJoins()
        //{
        //    if (_myQueryFieldsList.Count == 0) return null;
        //    foreach (var currentJoin in _myQueryFieldsList)
        //    {
                
        //        for (var i = 0; i < currentJoin.Value.Count; i++)
        //        {
        //            var loChild = (IQueryable)_loContext.GetPropValue(currentJoin.Value[i].ChildTable);

        //            var loParentKey = currentJoin.Value[i].ParentKey;
        //            var loChildKey = currentJoin.Value[i].ChildKey;
                   

        //            //Set Fields to true
        //            foreach (var field in AllFields.ToList())
        //            {
        //                if (field.Key.MyGetFieldPrefix().Equals(loParentKey.MyGetFieldPrefix()))
        //                    AllFields[field.Key] = true;

        //                if (field.Key.MyGetFieldPrefix().Equals(loChildKey.MyGetFieldPrefix()))
        //                    AllFields[field.Key] = true;
        //            }                                 
        //            var selectStatement = MyCreateSelectedFields(loChildKey.MyGetFieldPrefix());

        //            _loBo = _loBo.Join(loChild, "it."+loParentKey, "it."+loChildKey, selectStatement, null);
        //        }
        //    }
        //    return _loBo;
        //}
        //private string MyCreateSelectedFields(string pChildPrefix)
        //{
        //    var selectList = AllFields.
        //        Select(field => new { field.Value, field.Key }).
        //        Where(field => field.Value).
        //        Select(field => field.Key.MyGetFieldPrefix().Equals(pChildPrefix) ? "inner." + field.Key : "outer." + field.Key)
        //        .ToList();

        //    return "new ( " + string.Join(",", selectList) + " )";
        //}
        #endregion

        #region Wheres
        internal IQueryable MyAddWhere( string pField, MyExpressions pExpressions, object pValue)
        {         
            if(!string.IsNullOrEmpty(pField) && pValue != null)
                _loBo = _loBo.Where(pField + MyAddExpr(pExpressions), pValue);

            return _loBo;
        }

        public Dictionary<bool,IQueryable> MyProcessSearchFields(Dictionary<string,List<Control>> pSearchFields)
        {
            //CONTACTS_BASE a = null;
            //a.Age = 12;
            if (pSearchFields == null)
                return new Dictionary<bool, IQueryable> { {true,_loBo}};

            var loWhereString = "1=1 ";
            var loWhereValues = new List<object>();

            List<MyWhere> loWhereList = new List<MyWhere>();
            foreach ( KeyValuePair<string,List<Control>> keyalue in pSearchFields)
            {
                foreach (var control in keyalue.Value)
                {
                    if (MyGetSearchFieldWhere(control).Value != null)
                    {
                        loWhereList.Add(MyGetSearchFieldWhere(control));
                    }
                }
            }

            var indexToAdd = 0;

            for (var i = 0; i < loWhereList.Count; i++)
            {
                var loValue = loWhereList[i].Value;
                if (string.IsNullOrEmpty(loValue?.ToString()) || loValue.Equals(-1)) continue;

                var loBindingField = loWhereList[i].BindingField;
                var loExpression = MyAddExpr(loWhereList[i].Expression, indexToAdd,loBindingField);
                
                if (!CheckValueFormat(loBindingField, loValue)) 
                  return new Dictionary<bool, IQueryable> { { false, _loBo } };


                //loWhereString += " AND " + loBindingField + " " + loExpression + " ";
                loWhereString += " AND " + loExpression + " ";
                loWhereValues.Add(loValue);
                indexToAdd++;
            }
            return new Dictionary<bool, IQueryable> { { true, _loBo.Where(loWhereString , loWhereValues.ToArray()) } };            
        }
        protected internal MyWhere MyGetSearchFieldWhere(Control pControl)
        {
            var loWhere = new MyWhere();

            if (pControl is CheckedComboBox checkedCombobox)
            {
                if (!Equals(checkedCombobox.CheckedItems.Count, 0))
                {
                    var tableName = checkedCombobox.CheckedItems.ToDynamicList().First().GetType().Name;
                    var PrimaryKey = EntityBase.MyGetPrimaryKey(tableName).ToString();

                    loWhere = new MyWhere
                    {
                        Expression = checkedCombobox.MyExpression,
                        BindingField = checkedCombobox.BindingField,                        
                    };

                    var selectedValues =  (from object loValue in checkedCombobox.CheckedItems select "'" + ((dynamic)loValue).GetType().GetProperty(PrimaryKey).GetValue(loValue) + "'").Cast<string>();

                    loWhere.Value = string.Join(",", selectedValues);                 
                }
            }
          
            else if (pControl is Base4ComboBox baseComboBox)
            {
                //CONTACTS_BASE a = null;
                //a.Age = 12;
                if (!Equals(baseComboBox.SelectedIndex, 0))
                {
                    loWhere = new MyWhere
                    {
                        Expression = baseComboBox.MyExpression,
                        BindingField = baseComboBox.BindingField,
                        Value = baseComboBox.SelectedValue
                    };
                }
            }

            if (pControl is Base4TextBox baseTextBox)
            {
                if (!Equals(baseTextBox.Text, string.Empty))
                {
                    loWhere = new MyWhere
                    {
                        Expression = baseTextBox.Expression,
                        BindingField = baseTextBox.BindingField,
                        Value = baseTextBox.Text
                    };
                }
            }

            if (pControl is Base4DateTime base4DateTime)
            {
                if (!string.IsNullOrWhiteSpace(base4DateTime.Text)) 
                {
                    loWhere = new MyWhere
                    {
                        Expression = base4DateTime.Expression,
                        BindingField = base4DateTime.BindingField,
                        Value = DateTime.Parse(base4DateTime.Text)
                    };
                }
            }
            return loWhere;
        }
        #endregion

        #region Expressions
        private static string MyAddExpr(MyExpressions pExpressions, int pIndex = 0, string pBindingField="")
        {
            switch (pExpressions)
            {
                case MyExpressions.Equals:
                    return $" {pBindingField} = @{pIndex}";
                case MyExpressions.GreaterThan:
                    return $"{pBindingField} > @{pIndex}"; 
                case MyExpressions.LesserThan:
                    return $"{pBindingField} < @{pIndex}";
                case MyExpressions.GreaterOrEqual:
                    return $"{pBindingField} >= @{pIndex}";// + pIndex;
                case MyExpressions.LesserOrEqual:
                    return $"{pBindingField} <= @{pIndex}"; 
                case MyExpressions.Like:
                    return $"{pBindingField}.StartsWith(@" + pIndex + ") ";
                case MyExpressions.In:
                    return $@"@{pIndex}.Contains({pBindingField})"; //$"@{pIndex}.Contains({pBindingField});
                default: return string.Empty;
            }
        }
        #endregion

        private bool CheckValueFormat(string pBindingField, object pValue)
        {
            if (pValue == null) return false;

            var projectName = Assembly.GetExecutingAssembly().GetName().Name;

            foreach (var table in _tablesUsed)
            {                
                var type = Assembly.GetExecutingAssembly().CreateInstance(projectName+ "." + table)?.GetType();

                var entity = Activator.CreateInstance(type);

                foreach (var prop in entity.GetType().GetProperties())
                {
                    if (prop.Name != pBindingField) continue;
                    try
                    {
                        if (!string.IsNullOrEmpty(pValue.ToString()))                        
                            Convert.ChangeType(pValue, Type.GetType(prop.PropertyType.FullName));                        
                    }
                    catch (Exception)
                    {
                        var loMessageBox = MessageBox.Show(pBindingField + @" Alanı için girilen değer doğru değil",
                            @"Uyarı",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        //loMessageBox.ow(pBindingField + @" Alanı için girilen değer doğru değil");
                        return false;
                    }
                }
            }
            return true;            
        }
    }
    #region DefinitionClassesAndEnums
    internal class MyQueryFields
    {
        public string ParentKey = string.Empty;
        public string ChildKey = string.Empty;
        public string ChildTable = string.Empty;

        public MyQueryFields()
        {
            
        }
        public MyQueryFields(string pChildTable, string pChildKey, string pParentKey)
        {
            ChildTable = pChildTable;
            ChildKey = pChildKey;
            ParentKey = pParentKey;
        }
    }
    public enum MyExpressions
    {
        Equals, GreaterThan, LesserThan, GreaterOrEqual, LesserOrEqual, Like,In
    }
    #endregion

}

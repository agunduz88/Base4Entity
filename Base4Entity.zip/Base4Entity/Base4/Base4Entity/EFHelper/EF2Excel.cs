﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Resources;
using Base4Entity.Extensions;
using DataTable = System.Data.DataTable;
using Excel = Microsoft.Office.Interop.Excel;


namespace Base4Entity.EFHelper
{
    internal static class EfExt
    {
        private static DataTable ToDataTable<T>(this IList<T> data, ResourceManager pResourceManager)
         {
          

            string colName;
            var properties = data[0].GetType().GetProperties();

            var table = new DataTable();
            foreach (var prop in properties)
            {
                colName = pResourceManager.GetString(prop.Name) ??
                          prop.Name;

                if(colName.Equals("Item"))continue;
                table.Columns.Add(colName, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }

            foreach (T item in data)
            {
                var row = table.NewRow();
                foreach (var prop in properties)
                {
                    colName = pResourceManager.GetString(prop.Name) ??
                              prop.Name;
                    if (colName.Equals("Item")) continue;
                    row[colName] = item.GetPropValue(prop.Name) ?? DBNull.Value;
                }

                table.Rows.Add(row);
            }
            return table;


        }

        public static void ToExcelSheet<T>(this IList<T> data, ResourceManager pResourceManager)
        {
            // Start Excel and get Application object.
            var oXl = new Excel.Application
            {
                Visible = true,
                DisplayAlerts = false
            };

            // Set some properties

            // Get a new workbook. 
            var oWb = oXl.Workbooks.Add(Missing.Value);

            // Get the active sheet 
            var oSheet = (Excel.Worksheet)oWb.ActiveSheet;
            //oSheet.Name = sheetName;

            // Process the DataTable    

            List<object> listToConvertToExcel = new List<object>();
            ////Get Fields
            foreach (var item in data)
            {
                listToConvertToExcel.Add(item);


            }

            //return;
            var dt = listToConvertToExcel.ToDataTable(pResourceManager);

            Excel.Range range = null;
            var rowCount = 1;
            foreach (DataRow dr in dt.Rows)
            {
                rowCount += 1;
                for (var i = 1; i < dt.Columns.Count + 1; i++)
                {
                    if (rowCount == 2)
                        oSheet.Cells[1, i] = dt.Columns[i - 1].ColumnName;
                    try
                    {
                        oSheet.Cells[rowCount, i] = dr[i - 1].ToString();
                    }
                    catch (Exception)
                    {
                        // ignored
                    }
                }
            }

            //Resize the columns
            var oRange = oSheet.Range[oSheet.Cells[1, 1], oSheet.Cells[rowCount, dt.Columns.Count]];
            oRange.Columns.AutoFit();


            //if (range != null)
            //    Marshal.FinalReleaseComObject(range);


            try
            {
                //oWb.SaveAs(excelFilePath, Excel.XlFileFormat.xlWorkbookDefault, Missing.Value,
                //    Missing.Value, Missing.Value, Missing.Value,
                //    Excel.XlSaveAsAccessMode.xlExclusive, Missing.Value,
                //    Missing.Value, Missing.Value, Missing.Value);
                //oWb.Close(Missing.Value, Missing.Value, Missing.Value);
                //oXL.Quit();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }
        
    }
}

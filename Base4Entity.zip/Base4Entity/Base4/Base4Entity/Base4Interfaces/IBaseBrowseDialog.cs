﻿namespace Base4Entity.Base4Interfaces
{
    public interface IBaseBrowseDialog
    {
        void ReturnSelectedRow( object PrimaryKeyValue);
    }
}

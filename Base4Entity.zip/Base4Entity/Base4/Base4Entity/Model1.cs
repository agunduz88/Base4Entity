namespace Base4Entity
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<CONTACTS_BASE> CONTACTS_BASE { get; set; }
        public virtual DbSet<COUNTRy> COUNTRIES { get; set; }
        public virtual DbSet<ORDER_DETAILS> ORDER_DETAILS { get; set; }
        public virtual DbSet<ORDER_TYPES> ORDER_TYPES { get; set; }
        public virtual DbSet<ORDER> ORDERS { get; set; }
        public virtual DbSet<SPORT> SPORT { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CONTACTS_BASE>()
                .HasMany(e => e.ORDERS)
                .WithOptional(e => e.CONTACTS_BASE)
                .HasForeignKey(e => e.OR_REFNO);

            modelBuilder.Entity<ORDER_TYPES>()
                .HasMany(e => e.ORDERS)
                .WithOptional(e => e.ORDER_TYPES)
                .HasForeignKey(e => e.OR_PROD_CODE);

            modelBuilder.Entity<ORDER>()
                .HasMany(e => e.ORDER_DETAILS)
                .WithOptional(e => e.ORDER)
                .HasForeignKey(e => e.OD_REFNO);

            modelBuilder.Entity<SPORT>()
                .HasMany(e => e.CONTACTS_BASE)
                .WithOptional(e => e.SPORT)
                .HasForeignKey(e => e.CB_SPORTS_REFNO);
        }
    }
}

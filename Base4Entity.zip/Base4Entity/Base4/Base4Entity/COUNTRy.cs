namespace Base4Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("COUNTRIES")]
    public partial class COUNTRy
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int C_ROWID { get; set; }

        public string C_NAME { get; set; }
    }
}

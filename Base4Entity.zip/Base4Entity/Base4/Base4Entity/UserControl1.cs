﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Base4Entity.MyUIControls.Controls;

namespace Base4Entity
{
    public partial class UserControl1 : Base4UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
    }
}

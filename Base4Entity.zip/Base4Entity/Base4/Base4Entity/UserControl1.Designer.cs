﻿namespace Base4Entity
{
    partial class UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.base4TextBox1 = new Base4Entity.MyUIControls.Controls.Base4TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // BindingSource
            // 
            this.BindingSource.DataSource = typeof(Base4Entity.SPORT);
            // 
            // base4TextBox1
            // 
            this.base4TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.base4TextBox1.BindingField = "SP_NAME";
            this.base4TextBox1.BrowseDialogName = null;
            // 
            // 
            // 
            this.base4TextBox1.CustomButton.Image = null;
            this.base4TextBox1.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.base4TextBox1.CustomButton.Name = "";
            this.base4TextBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.base4TextBox1.CustomButton.Style = Base4Controls.Base4ColorStyle.Blue;
            this.base4TextBox1.CustomButton.TabIndex = 1;
            this.base4TextBox1.CustomButton.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.base4TextBox1.CustomButton.UseSelectable = true;
            this.base4TextBox1.CustomButton.Visible = false;
            this.base4TextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.BindingSource, "SP_NAME", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.base4TextBox1.Expression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.base4TextBox1.FieldName = "SP_NAME";
            this.base4TextBox1.HasRules = false;
            this.base4TextBox1.InformationPanelName = null;
            this.base4TextBox1.Lines = new string[] {
        "base4TextBox1"};
            this.base4TextBox1.Location = new System.Drawing.Point(4, 4);
            this.base4TextBox1.MaxLength = 32767;
            this.base4TextBox1.Name = "base4TextBox1";
            this.base4TextBox1.PasswordChar = '\0';
            this.base4TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.base4TextBox1.SelectedText = "";
            this.base4TextBox1.SelectionLength = 0;
            this.base4TextBox1.SelectionStart = 0;
            this.base4TextBox1.ShortcutsEnabled = true;
            this.base4TextBox1.Size = new System.Drawing.Size(75, 23);
            this.base4TextBox1.Style = Base4Controls.Base4ColorStyle.Blue;
            this.base4TextBox1.TabIndex = 0;
            this.base4TextBox1.Text = "base4TextBox1";
            this.base4TextBox1.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.base4TextBox1.UseSelectable = true;
            this.base4TextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.base4TextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.base4TextBox1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(88, 30);
            ((System.ComponentModel.ISupportInitialize)(this.BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MyUIControls.Controls.Base4TextBox base4TextBox1;
    }
}

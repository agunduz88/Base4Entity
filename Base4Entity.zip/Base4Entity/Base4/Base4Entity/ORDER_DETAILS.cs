namespace Base4Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class ORDER_DETAILS
    {
        [Key]
        public int OD_ROWID { get; set; }

        public int? OD_REFNO { get; set; }

        [Required]
        public string OD_INFO { get; set; }

        public virtual ORDER ORDER { get; set; }
    }
}

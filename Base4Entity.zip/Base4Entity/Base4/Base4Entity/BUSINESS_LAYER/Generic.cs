﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
//using System.Linq.Dynamic.Core;
using System.Reflection;
using Base4Entity.Extensions;

namespace Base4Entity.BUSINESS_LAYER
{
    public  class Generic
    {
        public static IEnumerable MyFillAll(string pTableName, string pValueMember, string pDisplayMember)
        {
            using (var context = EntityBase.MyCreateNewDbContextInstance())
            {
              
                //var data = ((IEnumerable)context.GetPropValue(pTableName)).ToDynamicList();
                var data = ((IEnumerable) context.GetPropValue(pTableName)).ToDynamicList();
                //if (data.Count == 0) yield break;
                
                var fakeInstanceType = Assembly.GetEntryAssembly().DefinedTypes.FirstOrDefault(x => x.Name == pTableName);

                //var fakeInstance = Assembly.GetExecutingAssembly().CreateInstance(projectName + "." + pTableName);
                var fakeInstance = Activator.CreateInstance(fakeInstanceType, false);

                fakeInstance.SetPropertyValue(pValueMember, -1);
                fakeInstance.SetPropertyValue(pDisplayMember, "<Select>");

                data.Insert(0, fakeInstance);

                
                return data.MySort(pDisplayMember); ;
            }
        }
        
        public static IEnumerable MyFillAll(string pTableName, bool pIsCombo = false)
        {
            var context = EntityBase.MyCreateNewDbContextInstance();

            using (context)
            {
                var listToAdd = ((IEnumerable)context.GetPropValue(pTableName)).ToDynamicList();
                if (pIsCombo)
                    listToAdd?.Insert(0, "<Seçiniz>");
                return listToAdd;
            }

        }

        //public static IEnumerable MyFillAll<TEntity>(this DbSet<TEntity> pEntity) where TEntity:class 
        //{
        //    var tableName = typeof(TEntity).MyGetTableName();
        //    using (var loBo = new MyGymEntities())
        //    {
        //        return ((IEnumerable) loBo.GetPropValue(tableName)).Cast<TEntity>().ToList();
        //    }
        //}
        //public static TEntity MyFillByPrimaryKey<TEntity>(this DbSet<TEntity> pEntity, object pPk) where TEntity : class
        //{
        //    var tableName = typeof(TEntity).MyGetTableName();
        //    using (var loBo = new MyGymEntities())
        //    {

        //        return ((DbSet<TEntity>) loBo.GetPropValue(tableName)).Find(pPk);
        //    }
        //}
    }
}

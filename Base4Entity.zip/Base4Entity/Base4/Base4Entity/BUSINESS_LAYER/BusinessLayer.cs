﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using Base4Entity.Extensions;

namespace Base4Entity.BUSINESS_LAYER
{
    public class BusinessLayer<TEntity>:IDisposable, IEnumerable where TEntity:class, new()
    {

        public delegate void BusinessObjectFilled();
        public event BusinessObjectFilled ValueChanged;
        private IEnumerable<TEntity> _myBusinessObject = new List<TEntity>();
        [Browsable(false)]
        public int MyCount => _myBusinessObject.Count();
        [Browsable(false)]
        public bool IsEmpty => MyCount != 0;
        private readonly DbContext _context = EntityBase.MyCreateNewDbContextInstance();
        private TEntity _currentEntity;
        private string PrimaryKey;
        //private TEntity _currentEntity = new TEntity();
        private readonly string _tableName = typeof(TEntity).Name;
        private readonly IEnumerable _fieldsList = EntityBase.BaseGetTableFullFieldList<TEntity>();

        public BusinessLayer()
        {
            PrimaryKey = _context.MyGetPrimaryKey<TEntity>();
            ValueChanged += BusinessLayer_ValueChanged;
        }
        
        public void Dispose()
        {
            _context.Dispose();
        }

        public IEnumerator GetEnumerator()
        {
            return _myBusinessObject.GetEnumerator();
        }

        public void MyFillAll()
        {            
            _myBusinessObject = ((IEnumerable)_context.GetPropValue(_tableName)).Cast<TEntity>().ToList();
            ValueChanged?.Invoke();
        }

        public void Next()
        {
            var lomyBusinessObject = new LinkedList<TEntity>(_myBusinessObject);
            _currentEntity = lomyBusinessObject.Find(_currentEntity)?.Next?.Value;


            foreach (var field in _fieldsList)
            {
                var fieldName = (string)field.GetPropValue("Name");

                if (_currentEntity == null) return;
                GetType().GetProperty(fieldName)?.SetValue(this, _currentEntity.GetPropValue(fieldName));

            }
        }

        private void BusinessLayer_ValueChanged()
        {            
            foreach (var field in _fieldsList)
            {
                var fieldName = (string) field.GetPropValue("Name");

                GetType().GetProperty(fieldName)?.SetValue(this, _myBusinessObject.First().GetPropValue(fieldName));                
            }

            if (this.GetPropValue(PrimaryKey).Equals(_myBusinessObject.First().GetPropValue(PrimaryKey)))
            {
                _currentEntity = _myBusinessObject.First();
            }
           
        }
    }
}

﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Linq.Dynamic.Core;
using System.Windows.Forms;
using Base4Entity.Extensions;

namespace Base4Entity.UITypeEditors
{
    public partial class MyEditorForm<TParentEntity> : Form where TParentEntity : class
    {

        //public BindingList<MySearchFields> _list = new BindingList<MySearchFields>();

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public BindingList<MySearchFields> List
        {
            get => (BindingList<MySearchFields>) myCrudGridView1.DataSource;
            set
            {
                if (value == null)
                    value = new BindingList<MySearchFields>();

                //MyUpdateGridView();
                myCrudGridView1.DataSource = new BindingList<MySearchFields>(value);
                Invalidate();
            }
        }



        //private BindingList<MyBindingFields> _myBindingFieldsList = new BindingList<MyBindingFields>();
        ////[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        //public BindingList<MyBindingFields> List
        //{
        //    get => _myBindingFieldsList;
        //    set
        //    {
        //        _myBindingFieldsList = value;
        //        MyUpdateGridView();
        //    }
        //}
        private IEnumerable _parentEntityFieldsList;
        

        public MyEditorForm()
        {            
            InitializeComponent();
            MyInitialize();
        }

        public void MyInitialize()
        {
            _parentEntityFieldsList = EntityBase.GetFieldListForEditor<TParentEntity>();
            //_parentEntityFieldsList = EntityBase.BaseGetTableFieldList2(typeof(TParentEntity).Name);
            
            StartPosition = FormStartPosition.CenterScreen;
            
            myCrudGridView1.MyAddButton.Click += MyAddButton_Click1;
            myCrudGridView1.MyDownButton.Click += MyDownButton_Click;
            myCrudGridView1.MyUpButton.Click += MyUpButton_Click;
          
        }

     

        private void MyUpButton_Click(object sender, EventArgs e)
        {
            var index = myCrudGridView1.SelectedCells[0].RowIndex;

            if (index == 0 || List.Count == 0) return;

            List.Swap(index, index - 1);

            MyUpdateGridView();

            myCrudGridView1.Rows[index - 1].Selected = true;
        }

        private void MyDownButton_Click(object sender, EventArgs e)
        {

            var index = myCrudGridView1.SelectedCells[0].RowIndex;

            if (index == List.Count - 1 || List.Count == 0) return;

            List.Swap(index, index + 1);

            MyUpdateGridView();


            myCrudGridView1.Rows[index + 1].Selected = true;
            
        }

        private void MyAddButton_Click1(object sender, EventArgs e)
        {
            var newList = List ?? new BindingList<MySearchFields>();
            using (var componentForm = new BdEditorFormComponentsForm(_parentEntityFieldsList, newList))
            {
                componentForm.ShowDialog();                
            }

            List = newList;
            MyUpdateGridView();
        }

        private void MyUpdateGridView()
        {
            myCrudGridView1.DataSource = new BindingList<MySearchFields>(List);
            //myCrudGridView1.DataSource = List;
            myCrudGridView1.Invalidate();
        }
        private void btnClose_Click(object sender, EventArgs e)
        {            
            Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            //Close();
        }

      
    }
}

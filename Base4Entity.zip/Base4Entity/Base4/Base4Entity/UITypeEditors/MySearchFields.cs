﻿using Base4Entity.EFHelper;

namespace Base4Entity.UITypeEditors
{    
    public class MySearchFields
    {
        private ControlTypes _controlType;
        public ControlTypes ControlType
        {
            get => _controlType;
            set => _controlType = value;
        }
        public string BindingField { get; set; }

        private MyExpressions _expressionType;
        public MyExpressions ExpressionType
        {
            get => _expressionType;
            set => _expressionType = value;
        }

        public string Section { get; set; }
        public string ChildEntity { get; set; }
        public string ValueMember { get; set; }
        public string DisplayMember { get; set; }

        
    }
}
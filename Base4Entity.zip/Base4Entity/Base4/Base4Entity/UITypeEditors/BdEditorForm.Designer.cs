﻿using System.ComponentModel;
using System.Windows.Forms;
using Base4Entity.MyUIControls.Controls;

//using MyUIControls.Controls;

namespace Base4Entity.UITypeEditors
{
    partial class MyEditorForm<TParentEntity>
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.BtnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.myCrudGridView1 = new Base4Entity.MyUIControls.Controls.MyCrudGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pageDateTimePicker = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myCrudGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Display Member";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Value Member";
            // 
            // BtnSave
            // 
            this.BtnSave.Location = new System.Drawing.Point(515, 8);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(94, 34);
            this.BtnSave.TabIndex = 5;
            this.BtnSave.Text = "Save";
            this.BtnSave.UseVisualStyleBackColor = true;
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(636, 8);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(94, 34);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Cancel";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.47709F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 86.52291F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(745, 433);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.AliceBlue;
            this.panel4.Controls.Add(this.btnClose);
            this.panel4.Controls.Add(this.BtnSave);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 379);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(739, 51);
            this.panel4.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.myCrudGridView1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 53);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(739, 320);
            this.panel2.TabIndex = 1;
            // 
            // myCrudGridView1
            // 
            this.myCrudGridView1.AllowUserToResizeRows = false;
            this.myCrudGridView1.BackgroundColor = System.Drawing.Color.White;
            this.myCrudGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.myCrudGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.myCrudGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.myCrudGridView1.GridColor = System.Drawing.Color.LightGray;
            this.myCrudGridView1.HasAddButton = true;
            this.myCrudGridView1.HasRemoveButton = true;
            this.myCrudGridView1.Location = new System.Drawing.Point(24, 25);
            this.myCrudGridView1.MultiSelect = false;
            this.myCrudGridView1.MySideToolBarIsVisible = true;
            this.myCrudGridView1.MyToolBarIsVisible = true;
            this.myCrudGridView1.Name = "myCrudGridView1";
            this.myCrudGridView1.ReadOnly = true;
            this.myCrudGridView1.RowHeadersVisible = false;
            this.myCrudGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.myCrudGridView1.Size = new System.Drawing.Size(715, 295);
            this.myCrudGridView1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(739, 44);
            this.panel1.TabIndex = 0;
            // 
            // pageDateTimePicker
            // 
            this.pageDateTimePicker.BackColor = System.Drawing.Color.AliceBlue;
            this.pageDateTimePicker.Location = new System.Drawing.Point(4, 22);
            this.pageDateTimePicker.Name = "pageDateTimePicker";
            this.pageDateTimePicker.Size = new System.Drawing.Size(658, 145);
            this.pageDateTimePicker.TabIndex = 2;
            this.pageDateTimePicker.Text = "DateTimePicker";
            // 
            // MyEditorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(745, 433);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "MyEditorForm";
            this.Text = "Base Searchfields";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myCrudGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        //private System.Windows.Forms.TabControl tabControl1;

        private Button BtnSave;
        private Button btnClose;
        private Label label4;
        //private System.Windows.Forms.ComboBox MyValueMember;
        private Label label5;
        //private System.Windows.Forms.ComboBox MyDisplayMember;
        //private MyUIControls.Controls.MyLbComboBox2 MyComboDataSource;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel4;
        private Panel panel2;
        private Panel panel1;
        
        private TabPage pageDateTimePicker;
        private MyCrudGridView myCrudGridView1;
        //private System.Windows.Forms.DataGridViewComboBoxCell controlTypeDataGridViewTextBoxCell;
        //private System.Windows.Forms.DataGridViewComboBoxColumn controlTypeDataGridViewTextBoxColumn;
        //private System.Windows.Forms.DataGridViewTextBoxColumn myBindingFieldDataGridViewTextBoxColumn;
        //private System.Windows.Forms.DataGridViewTextBoxColumn myChildEntityDataGridViewTextBoxColumn;
        //private System.Windows.Forms.DataGridViewTextBoxColumn myValueMemberDataGridViewTextBoxColumn;
        //private System.Windows.Forms.DataGridViewTextBoxColumn myDisplayMemberDataGridViewTextBoxColumn;
    }
}
﻿using System.ComponentModel;
using System.Windows.Forms;
using Base4Entity.EFHelper;
using Base4Entity.MyUIControls.Controls;

namespace Base4Entity.UITypeEditors
{
    partial class BdEditorFormComponentsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BdEditorFormComponentsForm));
            this.MyControlType = new Base4Entity.MyUIControls.Controls.MyLbComboBox2();
            this.MyBindingField = new Base4Entity.MyUIControls.Controls.MyLbComboBox2();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ButtonSave = new System.Windows.Forms.ToolStripButton();
            this.MyExpressionType = new Base4Entity.MyUIControls.Controls.MyLbComboBox2();
            this.BtnSection = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MyDataSource = new Base4Entity.MyUIControls.Controls.MyLbComboBox2();
            this.MyValueMember = new Base4Entity.MyUIControls.Controls.MyLbComboBox2();
            this.MyDisplayMember = new Base4Entity.MyUIControls.Controls.MyLbComboBox2();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MyControlType
            // 
            this.MyControlType.Description = "Control Type";
            this.MyControlType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MyControlType.FormattingEnabled = true;
            this.MyControlType.Location = new System.Drawing.Point(116, 60);
            this.MyControlType.MyBindingField = null;
            this.MyControlType.MyExpression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.MyControlType.Name = "MyControlType";
            this.MyControlType.Size = new System.Drawing.Size(141, 21);
            this.MyControlType.TabIndex = 0;
            // 
            // MyBindingField
            // 
            this.MyBindingField.Description = "Binding Field";
            this.MyBindingField.FormattingEnabled = true;
            this.MyBindingField.Location = new System.Drawing.Point(116, 28);
            this.MyBindingField.MyBindingField = null;
            this.MyBindingField.MyExpression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.MyBindingField.Name = "MyBindingField";
            this.MyBindingField.Size = new System.Drawing.Size(152, 21);
            this.MyBindingField.TabIndex = 5;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ButtonSave});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(618, 25);
            this.toolStrip1.TabIndex = 18;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // ButtonSave
            // 
            this.ButtonSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ButtonSave.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSave.Image")));
            this.ButtonSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ButtonSave.Name = "ButtonSave";
            this.ButtonSave.Size = new System.Drawing.Size(23, 22);
            this.ButtonSave.Text = "toolStripButton1";
            this.ButtonSave.Click += new System.EventHandler(this.ButtonSave_Click);
            // 
            // MyExpressionType
            // 
            this.MyExpressionType.Description = "Expression";
            this.MyExpressionType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MyExpressionType.FormattingEnabled = true;
            this.MyExpressionType.Location = new System.Drawing.Point(116, 92);
            this.MyExpressionType.MyBindingField = null;
            this.MyExpressionType.MyExpression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.MyExpressionType.Name = "MyExpressionType";
            this.MyExpressionType.Size = new System.Drawing.Size(212, 21);
            this.MyExpressionType.TabIndex = 25;
            // 
            // BtnSection
            // 
            this.BtnSection.Location = new System.Drawing.Point(465, 28);
            this.BtnSection.Name = "BtnSection";
            this.BtnSection.Size = new System.Drawing.Size(42, 20);
            this.BtnSection.TabIndex = 32;
            this.BtnSection.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(416, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 33;
            this.label1.Text = "Section";
            // 
            // MyDataSource
            // 
            this.MyDataSource.Description = "DataSource";
            this.MyDataSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MyDataSource.FormattingEnabled = true;
            this.MyDataSource.Location = new System.Drawing.Point(116, 134);
            this.MyDataSource.MyBindingField = null;
            this.MyDataSource.MyExpression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.MyDataSource.Name = "MyDataSource";
            this.MyDataSource.Size = new System.Drawing.Size(212, 21);
            this.MyDataSource.TabIndex = 51;
            // 
            // MyValueMember
            // 
            this.MyValueMember.Description = "Value Member";
            this.MyValueMember.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MyValueMember.FormattingEnabled = true;
            this.MyValueMember.Location = new System.Drawing.Point(116, 161);
            this.MyValueMember.MyBindingField = null;
            this.MyValueMember.MyExpression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.MyValueMember.Name = "MyValueMember";
            this.MyValueMember.Size = new System.Drawing.Size(212, 21);
            this.MyValueMember.TabIndex = 53;
            // 
            // MyDisplayMember
            // 
            this.MyDisplayMember.Description = "DisplayMember";
            this.MyDisplayMember.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MyDisplayMember.FormattingEnabled = true;
            this.MyDisplayMember.Location = new System.Drawing.Point(116, 190);
            this.MyDisplayMember.MyBindingField = null;
            this.MyDisplayMember.MyExpression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.MyDisplayMember.Name = "MyDisplayMember";
            this.MyDisplayMember.Size = new System.Drawing.Size(212, 21);
            this.MyDisplayMember.TabIndex = 55;
            // 
            // BdEditorFormComponentsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 234);
            this.Controls.Add(this.MyDisplayMember);
            this.Controls.Add(this.MyValueMember);
            this.Controls.Add(this.MyDataSource);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnSection);
            this.Controls.Add(this.MyExpressionType);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.MyBindingField);
            this.Controls.Add(this.MyControlType);
            this.Name = "BdEditorFormComponentsForm";
            this.Text = "Control Settings";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MyLbComboBox2 MyControlType;
        private MyLbComboBox2 MyBindingField;
        private ToolStrip toolStrip1;
        private ToolStripButton ButtonSave;
        private MyLbComboBox2 MyExpressionType;
        private TextBox BtnSection;
        private Label label1;
        private MyLbComboBox2 MyDataSource;
        private MyLbComboBox2 MyValueMember;
        private MyLbComboBox2 MyDisplayMember;
    }
}
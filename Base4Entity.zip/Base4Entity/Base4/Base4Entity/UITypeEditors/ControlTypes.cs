﻿namespace Base4Entity.UITypeEditors
{
    public enum ControlTypes
    {
        None,TextBox,ComboBox,CheckedComboBox,DateTimePicker,CheckBox
    }
}
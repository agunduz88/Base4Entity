﻿using System;
using System.ComponentModel;
using System.Data.Entity.Infrastructure.Interception;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using Base4Entity.Extensions;

//using MyBaseFrameWork.Extensions;

namespace Base4Entity.UITypeEditors
{

    class BdFormTypeEditor : UITypeEditor
    {
        public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context)
        {
            return UITypeEditorEditStyle.Modal;
        }

        public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
        {
            //IWindowsFormsEditorService svc = provider.GetService(typeof(IWindowsFormsEditorService)) as IWindowsFormsEditorService;
            ////Foo foo = value as Foo;
            var svc = provider.GetService(typeof(IWindowsFormsEditorService))
                as IWindowsFormsEditorService;
            //var myGenericTypeProperty = context?.Instance.GetType()
            //.GetProperty("MyGenericType");  

            //BindingList<MyBindingFields> bindingFieldsList = context.Instance.GetPropValue("MyBindingFieldsCollection") as BindingList<MyBindingFields>;//.SomeList;
            var genericType = (Type) context?.Instance.GetPropValue("MyGenericType");

            //var genericArgument = (Type)myGenericTypeProperty.GetValue(context.Instance);
            var editorFormType = typeof(MyEditorForm<>);
            //var genericArguments = new[] { genericArgument };
            var editorFormInstance = editorFormType.MakeGenericType(genericType);
            if (svc != null)
            {
                using (var f = (Form) Activator.CreateInstance(editorFormInstance))
                {
                    f.GetType().GetProperty("List")?.SetValue(f, value);
                    if (svc.ShowDialog(f) == DialogResult.OK)
                        return ((dynamic) f).List;

                }

            }
            else
            {
                using (var f = (Form) Activator.CreateInstance(editorFormInstance))
                {
                    f.GetType().GetProperty("List")?.SetValue(f, value);
                    if (svc.ShowDialog(f) == DialogResult.OK)
                        return ((dynamic) f).List;
                }
            }
            return base.EditValue(context, provider, value);
        }
    }

}

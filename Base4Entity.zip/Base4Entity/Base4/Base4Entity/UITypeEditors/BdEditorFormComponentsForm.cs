﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Windows.Forms;
using Base4Entity.EFHelper;
using Base4Entity.Extensions;

namespace Base4Entity.UITypeEditors
{
    public partial class BdEditorFormComponentsForm : Form
    {
        readonly BindingList<MySearchFields> _myBindingFieldsList;
        private readonly IEnumerable _parentEntityList;
        public ControlTypes MyControlTypes;
        public MyExpressions MyExpressions;

        //private readonly string _projectName = Assembly.GetExecutingAssembly().GetName().Name;

        public BdEditorFormComponentsForm(IEnumerable pParentEntityList, BindingList<MySearchFields> pCurrentBindingList)
        {
            InitializeComponent();
            _myBindingFieldsList = pCurrentBindingList;
            _parentEntityList = pParentEntityList;
            MyInitialize();
        }

        private void MyInitialize()
        {
            MyControlType.DataSource = Enum.GetNames(typeof(ControlTypes));
            MyExpressionType.DataSource = Enum.GetNames(typeof(MyExpressions));
            StartPosition = FormStartPosition.CenterScreen;

            this.Load += BdEditorFormComponentsForm_Load;
        }

        private void BdEditorFormComponentsForm_Load(object sender, EventArgs e)
        {
            var listToAdd = EntityBase.MyFillByEntities(EntityBase.GetEntryAssembly());
            MyDataSource.DataSource = listToAdd;




            MyBindingField.DataSource = _parentEntityList;
            MyDataSource.SelectedIndexChanged += MyDataSource_SelectedIndexChanged;
            MyControlType.SelectedIndexChanged += MyControlType_SelectedIndexChanged;
        }

        private void MyControlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!MyControlType.SelectedValue.Equals(ControlTypes.ComboBox.ToString()) && !MyControlType.SelectedValue.Equals(ControlTypes.CheckedComboBox.ToString()))
            {
                try
                {
                   
                    MyValueMember.SelectedIndex = 0;
                    MyDisplayMember.SelectedIndex = 0;
                    MyDataSource.SelectedIndex = 0;
                    MyDataSource.Visible = false;
                    MyValueMember.Visible = false;
                    MyDisplayMember.Visible = false;
                }
                catch (Exception exception)
                {                  
                }
                //label2.Visible = false;
                //label3.Visible = false;
                //label4.Visible = false;

            }
            else if(MyControlType.SelectedValue.Equals(ControlTypes.ComboBox.ToString()) || MyControlType.SelectedValue.Equals(ControlTypes.CheckedComboBox.ToString()))
            {
                try
                {
                    if (MyControlType.SelectedValue.Equals(ControlTypes.CheckedComboBox.ToString()))
                    {
                        Console.WriteLine(MyExpressions.In.ToString());
                        MyExpressionType.SelectedIndex = MyExpressionType.Items.IndexOf(MyExpressions.In.ToString());
                        MyExpressionType.Visible = false;
                    }
                    else
                    {
                        MyExpressionType.Visible = true;
                        MyExpressionType.SelectedIndex = 0;
                    }
                    MyDataSource.Visible = true;
                    MyValueMember.Visible = true;
                    MyDisplayMember.Visible = true;
                }
                catch (Exception exception)
                {
                    //Console.WriteLine(exception);
                    //throw;
                }
            }
            
        }

        private void MyDataSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            MyValueMember.DataSource = EntityBase.MyFillByEntityFields(MyDataSource.Text);
            MyDisplayMember.DataSource = EntityBase.MyFillByEntityFields(MyDataSource.Text);
        }

        

        private void ButtonSave_Click(object sender, EventArgs e)
        {
            Validate();
            var loNewBindingList = new MySearchFields();

            Enum.TryParse<ControlTypes>(MyControlType.SelectedValue.ToString(), out var loControlType);
            Enum.TryParse<MyExpressions>(MyExpressionType.SelectedValue.ToString(), out var loExpressionType);
            loNewBindingList.Section = BtnSection.Text;
            loNewBindingList.ControlType = loControlType;
            loNewBindingList.ExpressionType = loExpressionType;
            loNewBindingList.BindingField = MyBindingField.Text ?? "";
            loNewBindingList.ChildEntity = MyDataSource.Text;
            loNewBindingList.ValueMember = MyValueMember.Text;
              
            loNewBindingList.DisplayMember = MyDisplayMember.Text;
            
            _myBindingFieldsList.Add(loNewBindingList);


            Close();            
        }
    }    
}

namespace Base4Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SPORTS")]
    public partial class SPORT
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public SPORT()
        {
            CONTACTS_BASE = new HashSet<CONTACTS_BASE>();
        }

        [Key]
        public string SP_REFNO { get; set; }

        [Required]
        public string SP_NAME { get; set; }

        public int SP_PRICE { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CONTACTS_BASE> CONTACTS_BASE { get; set; }
    }
}

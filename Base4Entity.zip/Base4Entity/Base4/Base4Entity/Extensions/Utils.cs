﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;

namespace Base4Entity.Extensions
{
    public static class Utils
    {
       

        public static bool IsInDesignMode
        {
            get
            {
                var isInDesignMode = LicenseManager.UsageMode == LicenseUsageMode.Designtime;//|| Debugger.IsAttached;

                if (isInDesignMode) return true;
                using (var process = Process.GetCurrentProcess())
                {
                    return process.ProcessName.ToLowerInvariant().Contains("devenv");
                }
            }
        }

        public static IList<T> Swap<T>(this IList<T> list, int indexA, int indexB)
        {
            T tmp = list[indexA];
            list[indexA] = list[indexB];
            list[indexB] = tmp;
            return list;
        }

    }

}

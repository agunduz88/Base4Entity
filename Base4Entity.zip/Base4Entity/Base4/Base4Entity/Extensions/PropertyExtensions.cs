﻿using System;
using System.Linq;
using System.Reflection;

namespace Base4Entity.Extensions
{
    public static class PropertyExtensions
    {

        public static void SetPropertyValue(this object obj, string propName, object value)
        {
            try
            {
                object newValue;
                try
                {
                     newValue = Convert.ChangeType(value, Type.GetType(obj?.GetType().GetProperty(propName)?.PropertyType.FullName));
                }
                catch (Exception e)
                {
                    newValue = null;
                }

                obj?.GetType().GetProperty(propName)?.SetValue(obj, newValue, null);
            }
            catch (Exception)
            {
                obj?.GetType().GetProperty(propName)?.SetValue(obj, value, null);
            }
                                     
        }


        public static object GetPropValue(this object obj, string propertyName)
        {
            var property = obj.GetType().GetRuntimeProperties().FirstOrDefault(p => string.Equals(p.Name, propertyName, StringComparison.OrdinalIgnoreCase));
            return property != null ? property.GetValue(obj) : null;
        }


        internal static object MyCallFunction(this object obj, string pFunctionName, object pParameters)
        {
            return obj.GetType().GetMethod(pFunctionName)?.Invoke(obj, new[] { pParameters });
        }       
    }
   
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.Infrastructure;
using System.Diagnostics;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Windows.Forms;
using Base4Entity.MyUIControls.UIForms;
using Base4Entity.UITypeEditors;

namespace Base4Entity.Extensions
{
    static class EntityBase
    {
        public static Assembly GetEntryAssembly()
        {            
            var entryAssemblyList = AppDomain.CurrentDomain.GetAssemblies();
            
            return entryAssemblyList.Where(assembly => assembly.EntryPoint != null && assembly.EntryPoint.DeclaringType != null && assembly.EntryPoint.Name.Equals("Main") && !assembly.EntryPoint.DeclaringType.IsPublic).FirstOrDefault(assembly => assembly.DefinedTypes.Any(x => typeof(DbContext).IsAssignableFrom(x)));
        }
        internal static IEnumerable MyFillByEntities(Assembly pEntryAssembly)
        {           
                var myDbContextName = pEntryAssembly.DefinedTypes
                    .Where(t => typeof(DbContext).IsAssignableFrom(t)).ToList().First().FullName;

                var contextType = Type.GetType(myDbContextName);

                var listToAdd = contextType?.GetProperties()
                    .Select(property => new { property.Name, property.CanRead, property.CanWrite })
                    .Where(property => property.CanRead && property.CanWrite).Select(property => property.Name).ToList();

                listToAdd?.Insert(0, "<Select>");
                return listToAdd;       
        }
        internal static IEnumerable MyFillByEntityFields(string pTableName)
        {
            var typeOfTable = EntityBase.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == pTableName); 

            var listToAdd = typeOfTable?.GetProperties()
                .Select(property => new { property.Name, property.PropertyType })
                .Where(property => property.PropertyType.Namespace == "System").Select(property => property.Name)
                .ToList();

            listToAdd?.Insert(0, "<Seçiniz>");

            return listToAdd;
        }
        public static string MyGetPrimaryKey<TEntity>(this DbContext pContext) where TEntity : class
        {
            var objectContext = ((IObjectContextAdapter) pContext).ObjectContext;
            var set = objectContext.CreateObjectSet<TEntity>();

            return set.EntitySet.ElementType
                .KeyMembers[0].Name; 
        }

        public static List<object> MySort(this List<object> pInput, string pProperty)
        {
            return pInput.OrderBy(p => p.GetType()
                .GetProperty(pProperty)
                ?.GetValue(p, null)).ToList();
        }

        public static string MyGetPrimaryKey(string pTableName)
        {

            using (var Context = MyCreateNewDbContextInstance())
            {
                var objectContext = ((IObjectContextAdapter)Context).ObjectContext;
                //var projectName = Assembly.GetEntryAssembly().GetName().Name;

                Type type = Assembly.GetEntryAssembly()
                    .DefinedTypes
                    .FirstOrDefault(t => t.Name == pTableName);


                //var type = Type.GetType(projectName+"." + pTableName);
                var method = objectContext.GetType().GetMethod("CreateObjectSet", Type.EmptyTypes);
                var generic = method.MakeGenericMethod(type);
                object objectSet = generic.Invoke(objectContext, null);

                IEnumerable keyMembersList = (IEnumerable)objectSet.GetPropValue("EntitySet").GetPropValue("ElementType")
                    .GetPropValue("KeyMembers");

                return keyMembersList.ToDynamicList().First().ToString();
            }            
        }
        public static string MyGetPrimaryKey(this DbContext pContext,string pTableName)
        {
            var objectContext = ((IObjectContextAdapter)pContext).ObjectContext;
            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == pTableName);
            var method = objectContext.GetType().GetMethod("CreateObjectSet", Type.EmptyTypes);
            var generic = method?.MakeGenericMethod(type);
            object objectSet = generic?.Invoke(objectContext, null);

            var keyMembersList = (IEnumerable) objectSet.GetPropValue("EntitySet").GetPropValue("ElementType")
                .GetPropValue("KeyMembers");

            return keyMembersList.ToDynamicList().First().ToString();
        }

        public static object MyGetPrimaryKeyValue(object pData, string pPrimaryKey)
        {
            return pData.GetPropValue(pPrimaryKey);
        }


        public static bool MyIsAutoIncrement(string pTableName)
        {
            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == pTableName);

            var pk = MyGetPrimaryKey(pTableName);

            if (type == null) return false;
            var attributes = type.GetProperty(pk).GetCustomAttributes()
                .ToDictionary(a => a.GetType().Name, a => a).Values;


            return attributes.Where(attribute => attribute.GetPropValue("DatabaseGeneratedOption") != null).Any(attribute => attribute.GetPropValue("DatabaseGeneratedOption").Equals(DatabaseGeneratedOption.Identity));
        }

        public static bool IsRequiredField(object pPocoClass, string pField)
        {
            return (bool)pPocoClass.GetType().GetProperty(pField)?.GetCustomAttributesData().Any(x => x.AttributeType.Name == "RequiredAttribute");
        } 

        public static string MyGetTableName(object pDatataSource)
        {
            try
            {
                return (((BindingSource)pDatataSource).Current?.GetType().BaseType?.Name == "Object" ? ((BindingSource)pDatataSource).Current?.GetType().Name : ((BindingSource)pDatataSource).Current?.GetType().BaseType?.Name)?? ((BindingSource)pDatataSource)?.DataSource.GetPropValue("Name").ToString();               
            }
            catch (Exception)
            {

                return null;
                //return ((BindingSource)pDatataSource)?.DataSource.GetPropValue("Name").ToString();
            }
                    
        }
        public static bool MyIsAutoIncrement(this DbContext pContext, string pTableName)
        {

            var objectContext = ((IObjectContextAdapter)pContext).ObjectContext;
            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == pTableName);
            var method = objectContext.GetType().GetMethod("CreateObjectSet", Type.EmptyTypes);
            var generic = method?.MakeGenericMethod(type);
            var objectSet = generic?.Invoke(objectContext, null);


            var keyMembersList = ((IEnumerable)objectSet.GetPropValue("EntitySet").GetPropValue("ElementType")
                .GetPropValue("KeyMembers")).ToDynamicList().First();

            var primitiveTypes = ((EdmProperty) keyMembersList).PrimitiveType
                .PrimitiveTypeKind;                

            switch (primitiveTypes)
            {
                case PrimitiveTypeKind.Int16:
                    return true;
                case PrimitiveTypeKind.Int32:
                    return true;
                case PrimitiveTypeKind.Int64:
                    return true;
            }
            return false;

        }



        public static object MyGetCurrentRecord(this DbContext pContext, string pTableName)
        {

            var entity = pContext.GetPropValue(pTableName);

            var currentContext = ((IEnumerable) entity.GetPropValue("Local")).ToDynamicList()[0];
            
            return currentContext;
        }

        public static bool MyIsAutoIncrement<TEntity>(this DbContext pContext) where TEntity : class
        {
            var objectContext = ((IObjectContextAdapter) pContext).ObjectContext;            
            var set = objectContext.CreateObjectSet<TEntity>();

            var myPkTypeKind = (PrimitiveTypeKind) set.EntitySet.ElementType.KeyMembers[0].GetPropValue("PrimitiveType")
                .GetPropValue("PrimitiveTypeKind");

            switch (myPkTypeKind)
            {
                case PrimitiveTypeKind.Int16:
                    return true;
                case PrimitiveTypeKind.Int32:
                    return true;
                case PrimitiveTypeKind.Int64:
                    return true;
            }
            return false;
        }


        internal static IEnumerable GetFieldListForEditor<TParentEntity>()
        {            
            var a = typeof(TParentEntity).GetProperties().Select(property => new { property.Name, property.PropertyType })
                .Where(property => property.PropertyType.Namespace == "System").Select(property => property.Name)
                .ToList();

            MessageBox.Show(a.First());

            return a;

        }
        internal static IEnumerable BaseGetChildList(string pTableName)
        {
            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == pTableName);
         
            return type?.GetProperties()
                .Select(property => new { property.Name, property.PropertyType })
                .Where(property => property.PropertyType.Namespace != "System").Select(property => property.Name)
                .ToList();

        }

        internal static dynamic GetDataWithChilds(string pTableName,DbContext pContext,object pkValue,string pMyPrimaryKey)
        {
            var childList = BaseGetChildList(pTableName);

            //var data = ((dynamic)(IQueryable)pContext.GetPropValue(pTableName)).Find(pkValue);                        
            var data = pContext.GetPropValue(pTableName);
            foreach (string child in childList)
            {
                try
                {
                    data = data.MyCallFunction("Include", child);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    //throw;
                }
            }

            //return data.MyCallFunction("Find", pkValue);
            //((dynamic)(IQueryable)pContext.GetPropValue(pTableName)).Find(pkValue);
            //return data.MyCallFunction("Find", pkValue);

            //return data.MyCallFunction("Where", $"{pMyPrimaryKey} = {pkValue}");
            object dataToReturn = new object();

            try
            {
                dataToReturn = ((IQueryable)data).Where($"{pMyPrimaryKey} = @0",pkValue).ToDynamicList().FirstOrDefault();
            }
            catch (Exception e)
            {
                dataToReturn = ((IQueryable)data).Where($"{pMyPrimaryKey} = @0", $"'{pkValue}'").ToDynamicList().FirstOrDefault();
            }
            return dataToReturn;
        }

        internal static IEnumerable BaseGetTableFullFieldList<TParentEntity>()
        {
            //var projectName = Assembly.GetEntryAssembly().GetName().Name;
            //var typeOfTable = Type.GetType(projectName + "." + typeof(TParentEntity).Name);
            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == typeof(TParentEntity).Name);


            return type?.GetProperties()
                .Select(property => new { property.Name, property.PropertyType }).ToList();

        }
        internal static IEnumerable BaseGetTableFieldList2<TParentEntity>()
        {
            //var projectName = Assembly.GetEntryAssembly().GetName().Name;
            //var typeOfTable = Type.GetType(projectName + "." + typeof(TParentEntity).Name);

            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == typeof(TParentEntity).Name);

            return type?.GetProperties()
                .Select(property => new {property.Name, property.PropertyType})
                .Where(property => property.PropertyType.Namespace == "System").Select(property => property.Name)
                .ToList();

        }

        internal static Dictionary<string, bool> BaseGetTableFieldList<TParentEntity>(bool isOnSelected = false)
        {
            return typeof(TParentEntity).GetProperties()
                .Select(property => new { property.Name, property.PropertyType })
                .Where(property => property.PropertyType.Namespace == "System").ToDictionary(field => field.Name, field => true);
        }

        internal static Dictionary<string, bool> BaseGetTableFieldList(string pTableName,bool isOnSelected = false)
        {
            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == pTableName);

            return type?.GetProperties()
                .Select(property => new { property.Name, property.PropertyType })
                .Where(property => property.PropertyType.Namespace == "System").ToDictionary(field => field.Name, field => isOnSelected);

        }
        public static object CreatePocoInstanceOf(string pTableName)
        {
            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == pTableName);

            var instance = Activator.CreateInstance(type, false);

            return instance;
        }

        public static DbContext MyCreateNewDbContextInstance()
        {


            Type type2 = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => typeof(DbContext).IsAssignableFrom(t));
            object res = null;
            if (type2 != null)
            {
                res = Activator.CreateInstance(type2, false);
            }
            return (DbContext)res;


            //string myDbContextName = Assembly.GetEntryAssembly().DefinedTypes
            //    .Where(t => typeof(DbContext).IsAssignableFrom(t)).ToList().First().FullName;


            //var a = Assembly.GetEntryAssembly().DefinedTypes
                //.Where(t => typeof(DbContext).IsAssignableFrom(t)).ToList().First().GetType();
            //string myDbContextName = Assembly.GetEntryAssembly().DefinedTypes
            //    .Where(t => typeof(DbContext).IsAssignableFrom(t)).ToList().First().FullName;


            //string myDbContextName = Assembly.GetEntryAssembly().DefinedTypes
            //    .Where(t => typeof(DbContext).IsAssignableFrom(t)).ToList().First().FullName;

            //Type type = Assembly.GetEntryAssembly().CreateInstance(myDbContextName)?.GetType();
            //Type type = Type.GetType(myDbContextName);

            //var context = Activator.CreateInstance(type, false);

            //return (DbContext)context;
        }


        public static IList ConvertList(Type newItemType, IList source)
        {
            var listType = typeof(List<>);
            Type[] typeArgs = { newItemType };
            var genericListType = listType.MakeGenericType(typeArgs);
            var typedList = (IList)Activator.CreateInstance(genericListType);
            foreach (var item in source)
            {
                typedList.Add(item);
            }
            return typedList;
        }

        public static object Clone(this object entity)
        {
            var type = entity.GetType();
            var clone = Activator.CreateInstance(type);

            foreach (var property in type.GetProperties(BindingFlags.GetProperty | BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.SetProperty))
            {               
                if (property.CanWrite)
                {
                    property.SetValue(clone, property.GetValue(entity, null), null);
                }
            }

            return clone;
        }


        public static Form CreateGenericBrowseForm(string browseDialogName)
        {
            if (String.IsNullOrEmpty(browseDialogName)) return null;
            //var type = Type.GetType(BrowseDialogName);
            //var type = Type.GetType("efcfwf.SPORTS");
            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == browseDialogName); 
            //Type myGeneric = typeof(MyBrowseForm<>);
            //Type constructedClass = myGeneric.MakeGenericType(type);
            //object created = ;


            //dynamic comparer = created;
            try
            {
                return Activator.CreateInstance(type, false) as Form;
            }
            catch (Exception e)
            {
                throw new Exception(e.GetBaseException().Message);
            }
            
        }
    }
}

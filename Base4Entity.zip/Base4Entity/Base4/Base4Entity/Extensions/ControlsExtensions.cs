﻿using System.ComponentModel;
using Base4Controls;
using Base4Controls.Forms;
using MetroFramework.Components;

namespace Base4Entity.Extensions
{
   

    public static class ControlsExtensions
    {
        //What is your style
        private const Base4ColorStyle FormStyle = Base4ColorStyle.Green;
        public static void SetStyle(this IContainer container, BaseForm ownerForm)
        {
            if (container == null)
            {
                container = new Container();
            }
            var manager = new Base4StyleManager(container) { Owner = ownerForm };
            container.SetDefaultStyle(ownerForm, FormStyle);


        }
        public static void SetDefaultStyle(this IContainer contr, BaseForm owner, Base4ColorStyle style)
        {
            var manager = FindManager(contr, owner);
            manager.Style = style;
            owner.Style = style;
        }
        public static void SetDefaultTheme(this IContainer contr, BaseForm owner, Base4ThemeStyle thme)
        {
            Base4StyleManager manager = FindManager(contr, owner);
            manager.Theme = thme;
        }
        private static Base4StyleManager FindManager(IContainer contr, BaseForm owner)
        {
            Base4StyleManager manager = null;
            foreach (IComponent item in contr.Components)
            {
                if (item.GetType() != typeof(Base4StyleManager)) continue;
                if (((Base4StyleManager)item).Owner == owner)
                {
                    manager = (Base4StyleManager)item;
                }
            }
            return manager;
        }
    }
}

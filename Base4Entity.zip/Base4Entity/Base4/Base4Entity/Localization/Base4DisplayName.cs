﻿using System.ComponentModel;
using Base4Entity.Properties;

namespace Base4Entity.Localization
{
    class Base4DisplayName : DisplayNameAttribute
    {
        private readonly string _resourceName;
        public Base4DisplayName(string resourceName)
        {
            _resourceName = resourceName;
        }

        public override string DisplayName => Resources.ResourceManager.GetString(_resourceName);
    }
}

﻿using System.Drawing;
using System.Resources;
using Base4Controls;
using Base4Entity.Properties;

//using System.Globalization;

namespace Base4Entity.BaseConfigurations
{
    public class ConfigurationFile {
        
        public  Bitmap BdLogo { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Search");

        public  Bitmap SearchBtnImage { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Search");

        public  Bitmap NewBtnImage { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("NewDocument");

        public  Bitmap EditBtnImage { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Edit");

        public  Bitmap WatchBtnImage { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Find");

        public  Bitmap RemoveBtnImage { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Remove");

        public  Bitmap CrudSaveBtn { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Save");

        public  Bitmap CrudDeleteBtn { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Remove");

        public Base4ThemeStyle Theme = Base4ThemeStyle.Light;

        public Base4ColorStyle Style = Base4ColorStyle.Blue;
      
        public ResourceManager Base4ResourceManager = Resources.ResourceManager;

        public string DefaultCultureInfo = "tr-TR";


      
    }
}

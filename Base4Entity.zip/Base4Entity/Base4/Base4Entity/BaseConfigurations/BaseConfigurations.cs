﻿using System;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Threading;
using Base4Controls;
using Base4Entity.Extensions;
using Base4Entity.Properties;

namespace Base4Entity.BaseConfigurations
{
    public class BaseConfigurations
    {
        #region Properties

        public static ResourceManager Base4Resources = Resources.ResourceManager;
        public static Base4ThemeStyle Theme = Base4ThemeStyle.Light;

        public static Base4ColorStyle Style = Base4ColorStyle.Blue;

        public static Color ThemeColor = Base4Colors.White;

        public static Color StyleColor = Base4Colors.Blue;

        public static Bitmap BdLogo;// { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Search");

        public static Bitmap SearchBtnImage;// { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Search");

        public static Bitmap NewBtnImage;// { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("NewDocument");

        public static Bitmap EditBtnImage;// { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Edit");

        public static Bitmap WatchBtnImage;// { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Find");

        public static Bitmap RemoveBtnImage;// { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Remove");

        public static Bitmap CrudSaveBtn;// { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Save");

        public static Bitmap CrudDeleteBtn;// { get; set; } = (Bitmap)Resources.ResourceManager.GetObject("Remove");
       
        #endregion


        private static void SetThemeColor()
        {
            switch (Theme)
            {               
                case Base4ThemeStyle.Default:
                    ThemeColor = Base4Colors.White;
                    break;
                case Base4ThemeStyle.Light:
                    ThemeColor = Base4Colors.White;
                    break;
                case Base4ThemeStyle.Dark:
                    ThemeColor = Base4Colors.Black;
                    break;
               
            }
        }

        private static void SetStyleColor()
        {
            switch (Style)
            {
                case Base4ColorStyle.Default:
                    StyleColor = Base4Colors.Blue;
                    break;
                case Base4ColorStyle.Black:
                    StyleColor = Base4Colors.Black;
                    break;
                case Base4ColorStyle.White:
                    StyleColor = Base4Colors.White;
                    break;
                case Base4ColorStyle.Silver:
                    StyleColor = Base4Colors.Silver;
                    break;
                case Base4ColorStyle.Blue:
                    StyleColor = Base4Colors.Blue;
                    break;
                case Base4ColorStyle.Green:
                    StyleColor = Base4Colors.Green;
                    break;
                case Base4ColorStyle.Lime:
                    StyleColor = Base4Colors.Lime;
                    break;
                case Base4ColorStyle.Teal:
                    StyleColor = Base4Colors.Teal;
                    break;
                case Base4ColorStyle.Orange:
                    StyleColor = Base4Colors.Orange;
                    break;
                case Base4ColorStyle.Brown:
                    StyleColor = Base4Colors.Brown;
                    break;
                case Base4ColorStyle.Pink:
                    StyleColor = Base4Colors.Pink;
                    break;
                case Base4ColorStyle.Magenta:
                    StyleColor = Base4Colors.Magenta;
                    break;
                case Base4ColorStyle.Purple:
                    StyleColor = Base4Colors.Purple;
                    break;
                case Base4ColorStyle.Red:
                    StyleColor = Base4Colors.Red;
                    break;
                case Base4ColorStyle.Yellow:
                    StyleColor = Base4Colors.Yellow;
                    break;
                case Base4ColorStyle.Custom:
                    StyleColor = Base4Colors.Custom;
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        public static void SetConfiguration(object configuration)
        {
           
            BdLogo = (Bitmap) configuration.GetPropValue("BdLogo");

            SearchBtnImage = (Bitmap) configuration.GetPropValue("SearchBtnImage");

            NewBtnImage = (Bitmap) configuration.GetPropValue("NewBtnImage");

            EditBtnImage = (Bitmap) configuration.GetPropValue("EditBtnImage");

            WatchBtnImage = (Bitmap) configuration.GetPropValue("WatchBtnImage");

            RemoveBtnImage = (Bitmap) configuration.GetPropValue("RemoveBtnImage");

            CrudSaveBtn = (Bitmap) configuration.GetPropValue("CrudSaveBtn");

            CrudDeleteBtn = (Bitmap) configuration.GetPropValue("CrudDeleteBtn");

            Theme = (Base4ThemeStyle) configuration.GetPropValue("Theme");

            Style = (Base4ColorStyle) configuration.GetPropValue("Style"); 
            SetThemeColor();
            SetStyleColor();

            Base4Resources = (ResourceManager) configuration.GetPropValue("Base4ResourceManager");

            if (string.IsNullOrEmpty((string) configuration.GetPropValue("DefaultCultureInfo") )) return;         
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(configuration.GetPropValue("DefaultCultureInfo").ToString());
          
        }
    }
}
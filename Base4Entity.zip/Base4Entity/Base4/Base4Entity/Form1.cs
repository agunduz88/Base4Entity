﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Base4Entity.MyUIControls.UIForms;
using Base4Entity.UITypeEditors;

namespace Base4Entity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //this.Load += Form1_Load;

            var context = new Model1();

            var data = context.SPORT.Select(x => x.SP_NAME).ToList();




            // If more than 5 items, add a scroll bar to the dropdown.
            //ccb.MaxDropDownItems = 5;
            // Make the "Name" property the one to display, rather than the ToString() 
            // representation of the item.
            //checkedComboBox1.DisplayMember = "Name";
            // Set a separator for how the checked items will appear in the Text portion.
            checkedComboBox1.ValueSeparator = ", ";

            foreach (var VARIABLE in data)
            {
                checkedComboBox1.Items.Add(VARIABLE);
            }

            //string[] coloursArr = { "Red", "Green", "Black",
            //    "White", "Orange", "Yellow",
            //    "Blue", "Maroon", "Pink", "Purple" };

            //for (int i = 0; i<coloursArr.Length; i++) {
            //    CCBoxItem item = new CCBoxItem(coloursArr[i], i);
            //    ccb.Items.Add(item);
            //}

        }

        //private void Form1_Load(object sender, System.EventArgs e)
        //{
        //    using (var a = new Form2())
        //    {
        //        a.ShowDialog();
        //    }
        //}
    }
}

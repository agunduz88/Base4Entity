﻿namespace Base4Entity
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.base4TextBox1 = new Base4Entity.MyUIControls.Controls.Base4TextBox();
            this.base4TextBox2 = new Base4Entity.MyUIControls.Controls.Base4TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // BindingSource
            // 
            this.BindingSource.DataSource = typeof(Base4Entity.CONTACTS_BASE);
            // 
            // base4TextBox1
            // 
            this.base4TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.base4TextBox1.BindingField = "CB_REFNO";
            this.base4TextBox1.BrowseDialogName = null;
            // 
            // 
            // 
            this.base4TextBox1.CustomButton.Image = null;
            this.base4TextBox1.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.base4TextBox1.CustomButton.Name = "";
            this.base4TextBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.base4TextBox1.CustomButton.Style = Base4Controls.Base4ColorStyle.Blue;
            this.base4TextBox1.CustomButton.TabIndex = 1;
            this.base4TextBox1.CustomButton.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.base4TextBox1.CustomButton.UseSelectable = true;
            this.base4TextBox1.CustomButton.Visible = false;
            this.base4TextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.BindingSource, "CB_REFNO", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.base4TextBox1.Expression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.base4TextBox1.FieldName = "CB_REFNO";
            this.base4TextBox1.HasRules = false;
            this.base4TextBox1.InformationPanelName = null;
            this.base4TextBox1.Lines = new string[] {
        "base4TextBox1"};
            this.base4TextBox1.Location = new System.Drawing.Point(326, 89);
            this.base4TextBox1.MaxLength = 32767;
            this.base4TextBox1.Name = "base4TextBox1";
            this.base4TextBox1.PasswordChar = '\0';
            this.base4TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.base4TextBox1.SelectedText = "";
            this.base4TextBox1.SelectionLength = 0;
            this.base4TextBox1.SelectionStart = 0;
            this.base4TextBox1.ShortcutsEnabled = true;
            this.base4TextBox1.Size = new System.Drawing.Size(75, 23);
            this.base4TextBox1.Style = Base4Controls.Base4ColorStyle.Blue;
            this.base4TextBox1.TabIndex = 1;
            this.base4TextBox1.Text = "base4TextBox1";
            this.base4TextBox1.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.base4TextBox1.UseSelectable = true;
            this.base4TextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.base4TextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // base4TextBox2
            // 
            this.base4TextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.base4TextBox2.BindingField = "CB_SPORTS_REFNO";
            this.base4TextBox2.BrowseDialogName = "Form4";
            // 
            // 
            // 
            this.base4TextBox2.CustomButton.Image = null;
            this.base4TextBox2.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.base4TextBox2.CustomButton.Name = "";
            this.base4TextBox2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.base4TextBox2.CustomButton.Style = Base4Controls.Base4ColorStyle.Blue;
            this.base4TextBox2.CustomButton.TabIndex = 1;
            this.base4TextBox2.CustomButton.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.base4TextBox2.CustomButton.UseSelectable = true;
            this.base4TextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.BindingSource, "CB_SPORTS_REFNO", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.base4TextBox2.Expression = Base4Entity.EFHelper.MyExpressions.Equals;
            this.base4TextBox2.FieldName = "CB_SPORTS_REFNO";
            this.base4TextBox2.HasRules = false;
            this.base4TextBox2.InformationPanelName = "UserControl1";
            this.base4TextBox2.Lines = new string[] {
        "base4TextBox2"};
            this.base4TextBox2.Location = new System.Drawing.Point(326, 166);
            this.base4TextBox2.MaxLength = 32767;
            this.base4TextBox2.Name = "base4TextBox2";
            this.base4TextBox2.PasswordChar = '\0';
            this.base4TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.base4TextBox2.SelectedText = "";
            this.base4TextBox2.SelectionLength = 0;
            this.base4TextBox2.SelectionStart = 0;
            this.base4TextBox2.ShortcutsEnabled = true;
            this.base4TextBox2.ShowButton = true;
            this.base4TextBox2.Size = new System.Drawing.Size(75, 23);
            this.base4TextBox2.Style = Base4Controls.Base4ColorStyle.Blue;
            this.base4TextBox2.TabIndex = 4;
            this.base4TextBox2.Text = "base4TextBox2";
            this.base4TextBox2.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.base4TextBox2.UseSelectable = true;
            this.base4TextBox2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.base4TextBox2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.base4TextBox2);
            this.Controls.Add(this.base4TextBox1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Controls.SetChildIndex(this.base4TextBox1, 0);
            this.Controls.SetChildIndex(this.base4TextBox2, 0);
            ((System.ComponentModel.ISupportInitialize)(this.BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MyUIControls.Controls.Base4TextBox base4TextBox1;
        private MyUIControls.Controls.Base4TextBox base4TextBox2;
    }
}
﻿using System.ComponentModel;
using System.Windows.Forms;
using Base4Entity.MyUIControls.Controls;
using efcfwf.MyUIControls.Controls;

namespace Base4Entity.MyUIControls.UIForms
{
    partial class Base4Crud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Base4Crud));
            this.BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.toolStrip1 = new Base4ToolStrip();
            this.MySaveBtn = new System.Windows.Forms.ToolStripButton();
            this.MyDeleteBtn = new System.Windows.Forms.ToolStripButton();
            this.ErrorDescriptionLabel = new System.Windows.Forms.Label();
            this.ErrorCountLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.BindingSource)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MySaveBtn,
            this.MyDeleteBtn});
            this.toolStrip1.Location = new System.Drawing.Point(0, 60);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(620, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // MySaveBtn
            // 
            this.MySaveBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.MySaveBtn.Image = ((System.Drawing.Image)(resources.GetObject("MySaveBtn.Image")));
            this.MySaveBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MySaveBtn.Name = "MySaveBtn";
            this.MySaveBtn.Size = new System.Drawing.Size(23, 22);
            this.MySaveBtn.Text = "Save";
            this.MySaveBtn.Click += new System.EventHandler(this.MySaveBtn_Click);
            // 
            // MyDeleteBtn
            // 
            this.MyDeleteBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.MyDeleteBtn.Image = ((System.Drawing.Image)(resources.GetObject("MyDeleteBtn.Image")));
            this.MyDeleteBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MyDeleteBtn.Name = "MyDeleteBtn";
            this.MyDeleteBtn.Size = new System.Drawing.Size(23, 22);
            this.MyDeleteBtn.Text = "Delete";
            this.MyDeleteBtn.Click += new System.EventHandler(this.MyDeleteBtn_Click);
            // 
            // ErrorDescriptionLabel
            // 
            this.ErrorDescriptionLabel.AutoSize = true;
            this.ErrorDescriptionLabel.BackColor = System.Drawing.Color.Transparent;
            this.ErrorDescriptionLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ErrorDescriptionLabel.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ErrorDescriptionLabel.Location = new System.Drawing.Point(0, 0);
            this.ErrorDescriptionLabel.Name = "ErrorDescriptionLabel";
            this.ErrorDescriptionLabel.Size = new System.Drawing.Size(108, 13);
            this.ErrorDescriptionLabel.TabIndex = 0;
            this.ErrorDescriptionLabel.Text = "ErrorDescriptionLabel";
            this.ErrorDescriptionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ErrorDescriptionLabel.Visible = false;
            // 
            // ErrorCountLabel
            // 
            this.ErrorCountLabel.AutoSize = true;
            this.ErrorCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.ErrorCountLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ErrorCountLabel.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ErrorCountLabel.Location = new System.Drawing.Point(0, 0);
            this.ErrorCountLabel.Name = "ErrorCountLabel";
            this.ErrorCountLabel.Size = new System.Drawing.Size(43, 13);
            this.ErrorCountLabel.TabIndex = 0;
            this.ErrorCountLabel.Text = "0 Errors";
            // 
            // MyCrud
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 396);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Base4Crud";
            this.Padding = new System.Windows.Forms.Padding(0, 60, 0, 0);
            this.Click += new System.EventHandler(this.MyBindingSource_DataSourceChanged);
            ((System.ComponentModel.ISupportInitialize)(this.BindingSource)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public BindingSource BindingSource;
        private Base4ToolStrip toolStrip1;
        private ToolStripButton MySaveBtn;
        private ToolStripButton MyDeleteBtn;
        private Label ErrorDescriptionLabel;
        private Label ErrorCountLabel;
    }
}
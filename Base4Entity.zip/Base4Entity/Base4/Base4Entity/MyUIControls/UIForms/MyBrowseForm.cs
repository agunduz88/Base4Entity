﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data.Entity;
using System.Drawing;
using System.Drawing.Design;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Base4Controls.MessageBox;
using Base4Entity.Base4Interfaces;
using Base4Entity.EFHelper;
using Base4Entity.Extensions;
using Base4Entity.MyUIControls.Controls;
using Base4Entity.MyUIControls.Properties;
using Base4Entity.UITypeEditors;

//using Resources = efcfwf.Properties.Resources;

namespace Base4Entity.MyUIControls.UIForms
{
    public partial class BrowseBase4<TParentEntity> : Base4Form, IBaseBrowseDialog where TParentEntity : class
    {
        #region PropertiesPassedToBdCrud       
        private string _myNewCrudName = string.Empty;

        [Category("Base4Data")]
        public string MyNewCrudName
        {
            get => _myNewCrudName;
            set
            {
                _myNewCrudName = value;
                myBdGridView1.MyCrudName = _myNewCrudName;
            }
        }


        private int _selectTop = 0;
        [Category("Base4Data")]      
        public int SelectTop
        {
            get => _selectTop;
            set => _selectTop = value;
        }

        //private DbContext _context;
        //public DbContext Context
        //{
        //    get => _context;
        //    set => _context = value;
        //}       

        private string _transCode;
        [Category("Base4Data")]
        public string FormTransCode
        {
            get => _transCode;
            set => _transCode = value;
        }


        private string _primaryKey = string.Empty;
        public string Where = string.Empty;
        public string OrderBy = string.Empty;

        private IQueryable _linqQuery;    
        protected IQueryable LinqQuery
        {
            get => _linqQuery;
            set
            {
                _linqQuery = value;
                myBdGridView1.LinqQuery = _linqQuery;
            }
        }

        #endregion

        private BindingList<MySearchFields> _mySearchFieldsCollection = new BindingList<MySearchFields>();

        [Category("Base4Data")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(BdFormTypeEditor), typeof(UITypeEditor))]
        [TypeConverter(typeof(CollectionConverter))]
        public BindingList<MySearchFields> MySearchFieldsCollection
        {
            get => _mySearchFieldsCollection;
            set => _mySearchFieldsCollection = value;
        }

        //private string _baseTest = "";

        //[Category("Base4Data")]
        //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        //[Editor(typeof(TestTypeEditor), typeof(UITypeEditor))]
        //[TypeConverter(typeof(CollectionConverter))]
        //public string BaseTest
        //{
        //    get => _baseTest;
        //    set => _baseTest = value;
        //}

        [Browsable(false)]
        public Type MyGenericType => typeof(TParentEntity);


        #region MyOtherProperties        

        public ObservableCollection<MyWhere> MyWhereFieldsList = new ObservableCollection<MyWhere>();

        protected BaseSql<TParentEntity> BaseSql;

        private ObservableCollection<MyDisplayFields> _mydisplayFields = new ObservableCollection<MyDisplayFields>();

        private string _fieldsToDisplay = string.Join(",", EntityBase.BaseGetTableFieldList<TParentEntity>().Keys);

        [Browsable(false)]
        public string FieldsToDisplay
        {
            get => _fieldsToDisplay;
            set => _fieldsToDisplay = value;

        }

        [Category("Base4Data")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public ObservableCollection<MyDisplayFields> MyDisplayFields
        {
            get => _mydisplayFields;
            set => _mydisplayFields = value;
        }


        private string _tableName;
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public string TableName
        {
            get => _tableName;
            set
            {
                _tableName = value;
                myBdGridView1.TableName = value;
            }
        }
        #endregion

        #region Constructors



        public BrowseBase4()
        {
            InitializeComponent();
            MyInitialize();
            //components.SetStyle(this);
        }
     
        private void MyInitialize()
        {
            myBdGridView1.IsFromBd = true;



            if (!Utils.IsInDesignMode)
            {
                Context = EntityBase.MyCreateNewDbContextInstance();
                //Context.Database.Connection.Open();
                //((Model1) Context).Database.Connection.Open();
               TableName = typeof(TParentEntity).Name;
                Text = _transCode + @" " + Text;
                _primaryKey = EntityBase.MyGetPrimaryKey(typeof(TParentEntity).Name);
              
            }
            MyDisplayFields.CollectionChanged += MyDisplayFields_CollectionChanged;
                myBdGridView1.DataBindingComplete += MyBdGridView1_DataBindingComplete;
                Load += MyBrowseForm_Load;

            myBdGridView1.MySearchButton.Click += MySearchButton_Click;
                myBdGridView1.IsCrud = false;

                Closed += MyBrowseForm_Closed;

            MyBdPanel.RowStyles[2].Height = 0;
            KeyPreview = true;
            KeyPress += MyBrowseForm_KeyPress;
            //myBdGridView1.BrowseDialogDelegateGrid = this;

            _bg.DoWork += Bg_DoWork;
            _bg.RunWorkerCompleted += Bg_RunWorkerCompleted;

            //MySearchBox.Visible = false;

            this.KeyDown += BrowseBase4_KeyDown;
        }

        private async void BrowseBase4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            e.SuppressKeyPress = true;
            e.Handled = true;
            this.Invalidate();
            this.Refresh();
            _bg.RunWorkerAsync();


            //MySearchBox.ShowDialog();
            //_waitForm = await BaseMessages.BaseMessageSearchAsync(this);
            _waitForm = await BaseMessages.BaseMessageSearchAsync(this);
            _waitForm.StartPosition = FormStartPosition.Manual;
            _waitForm.Location = new Point(this.Right - _waitForm.Width - 20, this.Top + _waitForm.Height + 10);

            //_waitForm.Location = new Point(this.Right + 10, this.Top - _waitForm.Height - 10);

            _waitForm.ShowDialog();
            _waitForm.Refresh();
           
        }

        private void MyBrowseForm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SetSearch(true);
            }
            //base.OnKeyUp(e);
        }

        private void MyBdGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (var fieldinfo in MyDisplayFields)
            {
                if (myBdGridView1.Columns.Contains(fieldinfo.BindingField) && fieldinfo.DisplayName != string.Empty)
                {
                    myBdGridView1.Columns[fieldinfo.BindingField].HeaderText = fieldinfo.DisplayName;
                }
            }
        }

        private void MyBrowseForm_Closed(object sender, EventArgs e)
        {

            Context.Dispose();
            toolStripContainer1.Dispose();
            MyBdPanel.Dispose();
            panel4.Dispose();
            
            myBdGridView1.Dispose();
            MySearchPanel.Dispose();
            //MySearchFieldsPanel.Dispose();

        }

        private IQueryable _listToDisplay;
        private void SetSearch(bool pSearchClicked = false)
        {          
            try
            {
                if (!pSearchClicked)
                {

                    //myBdGridView1.DataSource = LinqQuery.ToDynamicList();
                    return;
                }
                
                Where = string.IsNullOrWhiteSpace(Where) ? "1=1" : Where;
                
                if(FieldsToDisplay.Contains(_primaryKey))
                   OrderBy = string.IsNullOrWhiteSpace(OrderBy) ? _primaryKey + " ASC " : OrderBy;

                
                LinqQuery = BaseSql.MyProcessSearchFields(SearchFieldsCollection).Values.First();
                    //.Select("new(" + FieldsToDisplay + ")", null).Where(Where);

                if (!string.IsNullOrEmpty(OrderBy))
                    LinqQuery.OrderBy(OrderBy);



                //if (LinqQuery.ToDynamicList().Count != 0)
                //    myBdGridView1.Columns.Clear();

                _listToDisplay = !string.IsNullOrEmpty(OrderBy) ? LinqQuery.Select("new(" + FieldsToDisplay + ")", null).OrderBy(OrderBy) : LinqQuery.Select("new(" + FieldsToDisplay + ")", null);

              


            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.InnerException);
                BaseMessages.BaseShowMessages("Query Build Failure",e.GetBaseException().Message,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                //BaseMessages.BaseShowMessages("Query Build Failure", "Unable to process Linq Query! Possible Reasons:\n" +
                //                                            "1- Where clause not supported with Joins\n" +
                //                                            "2- Display Field not supported with Joins\n",
                //    MessageBoxButtons.OK,
                //    MessageBoxIcon.Error);                
            }
        }

        private readonly BackgroundWorker _bg = new BackgroundWorker();
        private MySearchBox _waitForm;

        private async void MySearchButton_Click(object sender, EventArgs e)
        {
            this.Invalidate();
            this.Refresh();
            _bg.RunWorkerAsync();


            //MySearchBox.ShowDialog();
            //_waitForm = await BaseMessages.BaseMessageSearchAsync(this);
            _waitForm = await BaseMessages.BaseMessageSearchAsync(this);
            _waitForm.StartPosition = FormStartPosition.Manual;
            _waitForm.Location = new Point(this.Right - _waitForm.Width - 20, this.Top + _waitForm.Height + 10);

            //_waitForm.Location = new Point(this.Right + 10, this.Top - _waitForm.Height - 10);

            _waitForm.ShowDialog();
            _waitForm.Refresh();
        }
      

        private void Bg_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
             //MySearchBox.Close();
            _waitForm.Close();
                myBdGridView1.Columns.Clear();
                myBdGridView1.DataSource = SelectTop != 0 ? (object)_listToDisplay.Take(SelectTop) : _listToDisplay.ToDynamicList();

                myBdGridView1.ReNameColumns();
            

            //_waitForm.Dispose();
           
        }

        private void Bg_DoWork(object sender, DoWorkEventArgs e)
        {
            
           
            SetSearch(true);
        }


        #endregion

        #region Events  

        private void MyDisplayFields_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (MyDisplayFields == null) return;
            myBdGridView1.Columns.Clear();
            foreach (var displayField in MyDisplayFields)
            {
                if (string.IsNullOrEmpty(displayField.BindingField)) continue;
                if (myBdGridView1.Columns.Contains(displayField.BindingField)) continue;
                myBdGridView1.Columns.Add(displayField.BindingField, displayField.BindingField);
                myBdGridView1.Columns[displayField.BindingField].HeaderText = displayField.DisplayName;
            }
            myBdGridView1.Invalidate();
        }

        private void MyBrowseForm_Load(object sender, EventArgs e)
        {
            if (Utils.IsInDesignMode) return;

            FieldsToDisplay = MyDisplayFields.Count == 0
                ? FieldsToDisplay
                : string.Join(",", MyDisplayFields.Select(field => field.BindingField));
            //JOINS
            if (LinqQuery == null)
                LinqQuery = (IQueryable<dynamic>) Context.GetPropValue(MyGenericType.Name);


            BaseSql = new BaseSql<TParentEntity>(Context, LinqQuery); //TODO::This may need to be disposed 

            MySetSearchFieldsOnBrowseForm();
            SetSearch();

           
            Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(Text)?.ToString() ?? Text;

            Focus();

            
        
        }

        #endregion
        
        #region BdFunctions

        public readonly Dictionary<string, List<Control>> SearchFieldsCollection = new Dictionary<string, List<Control>>();

        private void MySetSearchFieldsOnBrowseForm()
        {
            var total = 20;

            var hasSection2 = false;
            var loControlList = new List<Control>();
            var loCurrentControl = new Control();

            
            var tempList = MySearchFieldsCollection.Select(MyControls.MyGetSearchFieldControl).ToList();

            if(tempList.Count == 0) return;

            var maxLabelWidth = 120;
            var maxTotalWitdh = 120;
            try
            {
                 maxLabelWidth = tempList.Max(x => (int)x.GetPropValue("LabelWidth"));
                 maxTotalWitdh = tempList.Max(x => (int)x.GetPropValue("TotalWidth"));
            }
            catch (Exception e)
            {
                //Console.WriteLine(e);
                //throw;
            }
          

            for (var i = 0; i<= MySearchFieldsCollection.Count - 1;  i++)
            {                
                var section  = MySearchFieldsCollection[i].Section;
                loControlList.Clear();

              

                if (section == "1")
                {
                    loCurrentControl = MyControls.MyGetSearchFieldControl(MySearchFieldsCollection[i]);
                    var bindingField = loCurrentControl.GetPropValue("BindingField").ToString();

                    if (SearchFieldsCollection.ContainsKey(bindingField))
                        SearchFieldsCollection[bindingField].Add(loCurrentControl);
                    else                    
                        SearchFieldsCollection.Add(bindingField,new List<Control>{loCurrentControl});                    

                    //SearchFieldsCollection.Add(loCurrentControl.GetPropValue("BindingField").ToString(), loCurrentControl);

                    loCurrentControl.Location = new Point(maxLabelWidth + 30, total);
                    total += 40;
                    MySearchPanel.Controls.Add(loCurrentControl);
                }

                if (i + 1 <= MySearchFieldsCollection.Count-1)
                {
                    var loControl2 = MyControls.MyGetSearchFieldControl(MySearchFieldsCollection[i+1]);
                    var bindingField = loControl2.GetPropValue("BindingField").ToString();
                    section = MySearchFieldsCollection[i+1].Section;

                    if (section == "2")
                    {
                        if (SearchFieldsCollection.ContainsKey(bindingField))
                            SearchFieldsCollection[bindingField].Add(loControl2);
                        else
                            SearchFieldsCollection.Add(bindingField, new List<Control> { loControl2 });

                        //SearchFieldsCollection.Add(loControl2.GetPropValue("BindingField").ToString(), loControl2);

                       
                        loControl2.Location = new Point(maxTotalWitdh + maxLabelWidth + 30, loCurrentControl.Location.Y);
                        hasSection2 = true;
                        MySearchPanel.Controls.Add(loControl2);
                        i++;
                    }
                }                                                                                                   
            }

            if (hasSection2)
            {
                Width = Width < (maxTotalWitdh * 2) + maxLabelWidth ? maxTotalWitdh * 2 + maxLabelWidth : Width;
            }
                
            

            MyBdPanel.RowStyles[0].Height = total + 30;
        }
        #endregion

        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        public IBaseBrowseDialog BrowseDialogDelegate;
        
        private void ButtonConfirm_Click(object sender, EventArgs e)
        {
                         
            try
            {
                var primaryKeyValue = myBdGridView1.CurrentRow.DataBoundItem.GetPropValue(_primaryKey);
                BrowseDialogDelegate.ReturnSelectedRow( primaryKeyValue);
                Close();
            }
            catch (Exception)
            {
                Base4MessageBox.Show(this, "No Rows are Selected " , "Error");
             }
            
        }

        public void ReturnSelectedRow(object PrimaryKeyValue)
        {
            try
            {
                //var primaryKeyValue = myBdGridView1.CurrentRow.DataBoundItem.GetPropValue(_primaryKey);
                BrowseDialogDelegate.ReturnSelectedRow(PrimaryKeyValue);
                Close();
            }
            catch (Exception)
            {
                Base4MessageBox.Show(this, "No Rows are Selected ", "Error");
            }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        private bool _watchOnly = false;
        
        [Category("Base4 Appearance")]
        public bool WatchOnly
        {
            get => _watchOnly;
            set
            {
                _watchOnly = value;
                myBdGridView1.WatchOnly = _watchOnly;
            }
        } 
    }
}

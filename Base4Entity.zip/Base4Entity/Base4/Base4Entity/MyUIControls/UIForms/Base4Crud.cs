﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using Base4Controls;
using Base4Controls.MessageBox;
using Base4Entity.EFHelper;
using Base4Entity.Extensions;
using Base4Entity.MyUIControls.Controls;

namespace Base4Entity.MyUIControls.UIForms
{

    public partial class Base4Crud : Base4Form
    {
        public delegate void AfterSave(object pCurrentRecord,string pTableName, bool pIsChild,OperationStatus operationStatus );

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        public delegate void BeforeSave(object pCurrentRecord);

        [Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
        internal event AfterSave AfterSaveEvent;


        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        private bool _showToolStrip = true;

      
        [Category("Base4 Appearance")]
        public bool ShowToolStrip
        {
            get { return _showToolStrip; }
            set
            {
                _showToolStrip = value;
                toolStrip1.Visible = _showToolStrip;
            }
        }
        internal bool IsChild;       

        public event BeforeSave BeforeSaveEvent;
        internal string MyPrimaryKey;
        
        internal object MyPkValue;
        
        
        internal bool IsFromBd;
            
        public object TestData;
        
        private object _parentDataUnchanged;
        private BaseErrorBox _errorDialog;

        internal bool IsSaveClicked;
       
        //private readonly string _projectName = Assembly.GetExecutingAssembly().GetName().Name;
        public enum CrudActions
        {
            Add,Edit,Idle
        }


        
        public CrudActions EditingState;        
        internal string TableName;

        private bool _validation = true;
        [Category("MyFrameWork")]
        public bool Validation
        {
            get => _validation;
            set => _validation = value;
        }       

        
        public Base4Crud()
        {
            InitializeComponent();
            MyInitialize();
        }
        public Base4Crud(CrudActions pCrudEditingState)
        {
            InitializeComponent();
            MyInitialize(pCrudEditingState);
        }



        private void MyInitialize(CrudActions pCrudEditingState = CrudActions.Add)
        {
            SetBaseConfigurations();

            if (!Utils.IsInDesignMode)
            {
                Context = EntityBase.MyCreateNewDbContextInstance();                
            }
            
            
            EditingState = pCrudEditingState;
            Load += MyForm2_Load;
            toolStrip1.GripStyle = ToolStripGripStyle.Hidden;
            toolStrip1.BackColor = Base4Colors.White;
            BeforeSaveEvent += MyCrud_BeforeSaveEvent;
            
            AutoValidate = AutoValidate.EnableAllowFocusChange;
            FormClosing += MyCrud_FormClosing;
            MouseClick += MyCrud_MouseClick;
            BindingSource.DataSourceChanged += MyBindingSource_DataSourceChanged1;
            
        }

        private void MyBindingSource_DataSourceChanged1(object sender, EventArgs e)
        {
            if(DesignMode) return;
            if (BindingSource.Count == 0) return;
            TestData = TestData ?? BindingSource.DataSource;
            TableName = TableName??TestData.GetType().BaseType?.Name;
        }

        private void MyCrud_MouseClick(object sender, MouseEventArgs e)
        {
            //ErrorDialog.Visible = false;
        }

        private void MyBindingSource_DataSourceChanged(object sender, EventArgs e)
        {
                        
        }


        private void AddNewItem()
        {
            if (Utils.IsInDesignMode) return;

            try
            {
                Type type = Assembly.GetEntryAssembly()
                    .DefinedTypes
                    .FirstOrDefault(t => t.Name == TableName);

                TestData = Activator.CreateInstance(type, false);
                BindingSource.DataSource = TestData;
            }
            catch (Exception)
            {
                //BaseMessages.BaseShowMessages("Add New", "Unable to Create new POCO Instance", MessageBoxButtons.OK,MessageBoxIcon.Error);
            }           
        }


        private void EditIdle()
        {          
            if(IsFromBd)
                try
                {
                    //CONTACTS_BASE a = null;
                    //a.Age = 12;
                    //Console.WriteLine(EntityBase.BaseGetChilds(TableName));
                    TestData = ((dynamic)(IQueryable)Context.GetPropValue(TableName)).Find(MyPkValue);
                    //TestData = EntityBase.GetDataWithChilds(TableName, Context, MyPkValue, MyPrimaryKey);
                    _parentDataUnchanged = Context.Entry(TestData).CurrentValues.ToObject();

                    BindingSource.DataSource = TestData;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.GetBaseException().Message);
                }
            else
            {               
                try
                {                    
                    _parentDataUnchanged = Context.Entry(TestData).CurrentValues.ToObject();
                }
                catch (Exception)
                {

                    try
                    {
                        _parentDataUnchanged = TestData.Clone();
                    }
                    catch (Exception)
                    {
                        //BaseMessages.BaseShowMessages("Entity Error", e.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //throw
                    }
                    

                }
                BindingSource.DataSource = TestData;

            }
        }

     

        private void MyForm2_Load(object sender, EventArgs e)
        {
            if(Utils.IsInDesignMode) return;

            try
            {
                if (TableName != null && !TableName.Equals("Object"))
                {
                }
                else
                {
                    TableName= EntityBase.MyGetTableName(BindingSource);
                }

                //TableName = !TableName.Equals("Object") && !string.IsNullOrEmpty(TableName) ?                
            }
            catch (Exception exception)
            {
                //return;
                Base4MessageBox.Show(this, exception.Message, exception.InnerException?.ToString());
            }
            


            FindValidationFields(Controls);
            MyCrudOpeningSettings();
            //this.components.SetStyle(this);
        }

        private void ClearErrors(IEnumerable pControls)
        {
            foreach (Control item in pControls)
            {
                if (item.GetPropValue("MyBindingField") != null || item.DataBindings.Count != 0)
                {
                    //item.GetPropValue("MyBindingField") ?? item.DataBindings[0].BindingMemberInfo.BindingField;

                    try
                    {
                        ((dynamic)item).HasRules = false;
                    }
                    catch (Exception)
                    {
                        //Ignored
                    }
                }

                ClearErrors(item.Controls);
            }
        }

        private readonly List<Control> _controlsToValidate = new List<Control>();

        private void FindValidationFields(IEnumerable pControls) //LoadDa kontrol et
        {
                        
            foreach (Control item in pControls)
            {        
                
                if (item.GetPropValue("BindingField") != null ||item.DataBindings.Count != 0)
                {
                    // ??
                    if (null !=(item.GetPropValue("BindingField")??item.DataBindings[0].BindingMemberInfo.BindingField))
                    {
                        if (!_controlsToValidate.Contains(item))
                            _controlsToValidate.Add(item);
                    }
                                
                }
                FindValidationFields(item.Controls);                
            }
        }
        private void ValidateFields(List<ValidationResult> pErrors)
        {
            var tempErrors = new List<ValidationResult>(pErrors);
            //ErrorDialog.Visible = false;
            foreach (var fields in _controlsToValidate)
            {

                var bindingField = fields.GetPropValue("BindingField") ??fields.DataBindings[0].BindingMemberInfo.BindingField;
                foreach (var error in pErrors)
                {
                    
                    if (!error.MemberNames.First().Equals(bindingField))
                        continue;
                    try
                    {
                        ((dynamic) fields).SetErrorMessage(error.ErrorMessage);
                    }
                    catch (Exception)
                    {
                        // ignored
                    }
                    //tempErrors.Remove(error);
                }
            }


            if (tempErrors.Count == 0) return;

            BaseMessages.BaseMessageDialog(this, tempErrors);


        }
        public void MySetCrudVisibility(CrudActions pActions, IEnumerable pControls)
        {            
            foreach (Control item in pControls)
            {
                if (EditingState == CrudActions.Idle)
                {
                    if (item.DataBindings.Count != 0)
                    {
                        item.Enabled = false;
                    }

                    if (item is Base4GridView)
                    {
                        ((Base4GridView) item).MyBdNewBtn.Visible = false;
                        ((Base4GridView) item).MyBdEditBtn.Visible = false;
                        ((Base4GridView) item).MyRemoveBtn.Visible = false;
                        ((Base4GridView) item).MySearchButton.Visible = false;

                    }
                }
                else
                {
                    MyDeleteBtn.Visible = false;
                }

                if (item.DataBindings.Count != 0 && item.DataBindings["Text"] != null)
                {                    
                    //PaeentmiDeğil mi kontrolü yap ve ona göre tableName i al                    
                    if (MyPrimaryKey is null)
                    {                        
                        if (item.DataBindings["Text"].BindingMemberInfo.BindingField.Equals(EntityBase.MyGetPrimaryKey(TableName)) && EntityBase.MyIsAutoIncrement(TableName))
                            item.Enabled = false;
                    }
                    else
                    {
                        if (item.DataBindings["Text"].BindingMemberInfo.BindingField.Equals(MyPrimaryKey) && EntityBase.MyIsAutoIncrement(TableName))
                            item.Enabled = false;
                    }                    
                }

                MySetCrudVisibility(pActions, item.Controls);
            }
        }     
        private void MyCrudOpeningSettings()
        {
            MySetCrudVisibility(EditingState, Controls);

            switch (EditingState)
            {
                case CrudActions.Add:
                {
                    AddNewItem();                                       
                    break;
                }

                case CrudActions.Edit:
                {
                    EditIdle();
                    break;                    
                }
                    
                case CrudActions.Idle:
                {
                    EditIdle();                    
                    break;
                 }                
            }
        }      
        private void MyCrud_FormClosing(object sender, FormClosingEventArgs e)
        {

            //_baseConfiguration.Dispose();
            if(IsSaveClicked) return;

            //MyBindingSource.ResetCurrentItem();
            //When Cancelled, restore old values     

           
                try
                {

                    Context.Entry(TestData).CurrentValues.SetValues(_parentDataUnchanged);
                }
                catch (Exception)
                {
                    AfterSaveEvent?.Invoke(_parentDataUnchanged, TableName, IsChild, OperationStatus.Canceled);
                }
           
            
            Invalidate();

        }

        
    
       
        private void MyCrud_BeforeSaveEvent(object pCurrentRecord)
        {
            
        }
        private void MySaveBtn_Click(object sender, EventArgs e)
        {
            IsSaveClicked = true;
            BeforeSaveEvent?.Invoke(TestData);


            if (!IsChild) //If is Parent
            {               
                try
                {
                    Context.Entry(TestData).CurrentValues.SetValues(TestData);
                }
                catch (Exception)
                {
                    try
                    {
                        var runtimeKnownDbSet = Context.GetPropValue(TableName);

                        runtimeKnownDbSet.MyCallFunction("Add", TestData);
                    }
                    catch (Exception)
                    {
                        // ignored
                    }
                }



                try
                {
                    ClearErrors(Controls);

                    if (TestData.GetPropValue("Count") == null)
                    {
                        if (!DoValidationFor(TestData))
                            return;
                    }
                     
                    Context.SaveChanges();
                }
                catch (DbEntityValidationException)
                {
                    //TODO::Clear errors first
                    ClearErrors(Controls);

                    if (!DoValidationFor(TestData))                
                        return;                    
                       
                }
            }
            else
            {
                ClearErrors(Controls);

                if (!DoValidationFor(TestData))
                {
                    IsSaveClicked = false;
                    return;
                }
                    
            }
          
            AfterSaveEvent?.Invoke(TestData, TableName,IsChild,OperationStatus.Save);


            Close();
        }


        private bool DoValidationFor(object pData)
        {
            var vc = new ValidationContext(pData, null, null);
            var vResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(pData, vc, vResults, false);

            var errorsList = (List<ValidationResult>)pData.MyCallFunction("Validate", vc);


            if (errorsList != null && errorsList.Count != 0)
            {
                isValid = false;

                 vResults = vResults.Except(errorsList).ToList();


                if (errorsList.Count != 0)
                {
                    foreach (var error in errorsList)
                    {
                        if (!vResults.Any(x => x.MemberNames.First().Equals(error.MemberNames.First()) && x.ErrorMessage.Equals(error.ErrorMessage)))
                        {
                            vResults.Add(error);
                        }                      
                    }
                }
               
            }

            if (isValid) return true;
            ValidateFields(vResults);
            return false;
        }
        private void MyDeleteBtn_Click(object sender, EventArgs e)
        {
            if (Utils.IsInDesignMode) return;

            var dialog = BaseMessages.BaseShowMessages(@"Delete", @"Kaydı silmek istediğinizden emin misiniz?",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
           
            if (dialog != DialogResult.Yes) return;


            //using (Context)
            //{
            if (IsChild)
            {
                Context.GetPropValue(TableName).MyCallFunction("Remove", BindingSource.Current);
                ((IObjectContextAdapter) Context).ObjectContext.SaveChanges();
                Context.SaveChanges();

            }
            else
            {
                Context.GetPropValue(TableName).MyCallFunction("Remove", BindingSource.Current);
                ((IObjectContextAdapter)Context).ObjectContext.SaveChanges();
                Context.SaveChanges();
                
            }
            IsSaveClicked = true;
            //AfterSaveEvent?.Invoke(ParentData ?? MyBindingSource.DataSource, TableName);
            //}


            Close();
        }

        private void SetBaseConfigurations()
        {
            MySaveBtn.Image = BaseConfigurations.BaseConfigurations.CrudSaveBtn;
            MyDeleteBtn.Image = BaseConfigurations.BaseConfigurations.CrudDeleteBtn;
        }    
    }
}

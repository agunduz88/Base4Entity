﻿namespace Base4Entity.MyUIControls.UIForms
{
    public enum OperationStatus
    {
        Save,Canceled
    }
}
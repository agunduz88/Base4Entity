﻿using System.ComponentModel;
using System.Windows.Forms;
using Base4Entity.MyUIControls.Controls;
using efcfwf.MyUIControls.Controls;

namespace Base4Entity.MyUIControls.UIForms
{
    partial class BrowseBase4<TParentEntity> where TParentEntity:class
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.MyBdPanel = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.myBdGridView1 = new Base4Entity.MyUIControls.Controls.Base4GridView();
            this.MySearchPanel = new System.Windows.Forms.Panel();
            this.base4Panel1 = new Base4Entity.MyUIControls.Controls.Base4Panel();
            this.ButtonConfirm = new Base4Entity.MyUIControls.Controls.Base4Button();
            this.ButtonCancel = new Base4Entity.MyUIControls.Controls.Base4Button();
            //this.MySearchBox  = new MySearchBox();
            //MySearchBox.label1.Text = "Searching";
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.MyBdPanel.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myBdGridView1)).BeginInit();
            this.base4Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.toolStripContainer1.ContentPanel.Controls.Add(this.MyBdPanel);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(578, 374);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 60);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(578, 399);
            this.toolStripContainer1.TabIndex = 1;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // MyBdPanel
            // 
            this.MyBdPanel.ColumnCount = 1;
            this.MyBdPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MyBdPanel.Controls.Add(this.panel4, 0, 1);
            this.MyBdPanel.Controls.Add(this.MySearchPanel, 0, 0);
            this.MyBdPanel.Controls.Add(this.base4Panel1, 0, 2);
            this.MyBdPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MyBdPanel.Location = new System.Drawing.Point(0, 0);
            this.MyBdPanel.Name = "MyBdPanel";
            this.MyBdPanel.RowCount = 3;
            this.MyBdPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.MyBdPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.MyBdPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.MyBdPanel.Size = new System.Drawing.Size(574, 370);
            this.MyBdPanel.TabIndex = 1;
            // 
            // panel4
            // 
            //this.panel4.Controls.Add(this.MySearchBox);
            this.panel4.Controls.Add(this.myBdGridView1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 33);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(568, 298);
            this.panel4.TabIndex = 3;
            // 
            // myBdGridView1
            // 
            this.myBdGridView1.AllowUserToAddRows = false;
            this.myBdGridView1.AllowUserToDeleteRows = false;
            this.myBdGridView1.AllowUserToResizeRows = false;
            this.myBdGridView1.BackgroundColor = System.Drawing.Color.White;
            this.myBdGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.myBdGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.myBdGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.myBdGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.myBdGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.myBdGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.myBdGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.myBdGridView1.EnableHeadersVisualStyles = false;
            this.myBdGridView1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.myBdGridView1.GridColor = System.Drawing.Color.LightGray;
            this.myBdGridView1.Location = new System.Drawing.Point(0, 25);
            this.myBdGridView1.MultiSelect = false;
            this.myBdGridView1.MyCrudName = "";
            this.myBdGridView1.Name = "myBdGridView1";
            this.myBdGridView1.ParentResourceManager = null;
            this.myBdGridView1.ReadOnly = true;
            this.myBdGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.myBdGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.myBdGridView1.RowHeadersVisible = false;
            this.myBdGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.myBdGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.myBdGridView1.Size = new System.Drawing.Size(568, 273);
            this.myBdGridView1.TabIndex = 0;
            this.myBdGridView1.VirtualMode = true;
            this.myBdGridView1.WatchOnly = false;
            // 
            // MySearchPanel
            // 
            this.MySearchPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MySearchPanel.Location = new System.Drawing.Point(3, 3);
            this.MySearchPanel.Name = "MySearchPanel";
            this.MySearchPanel.Size = new System.Drawing.Size(568, 24);
            this.MySearchPanel.TabIndex = 2;
            // 
            // base4Panel1
            // 
            this.base4Panel1.Controls.Add(this.ButtonConfirm);
            this.base4Panel1.Controls.Add(this.ButtonCancel);
            this.base4Panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.base4Panel1.HorizontalScrollbarBarColor = true;
            this.base4Panel1.HorizontalScrollbarHighlightOnWheel = false;
            this.base4Panel1.HorizontalScrollbarSize = 10;
            this.base4Panel1.Location = new System.Drawing.Point(3, 337);
            this.base4Panel1.Name = "base4Panel1";
            this.base4Panel1.Size = new System.Drawing.Size(568, 30);
            this.base4Panel1.Style = Base4Controls.Base4ColorStyle.Blue;
            this.base4Panel1.TabIndex = 4;
            this.base4Panel1.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.base4Panel1.VerticalScrollbarBarColor = true;
            this.base4Panel1.VerticalScrollbarHighlightOnWheel = false;
            this.base4Panel1.VerticalScrollbarSize = 10;
            // 
            // ButtonConfirm
            // 
            this.ButtonConfirm.Dock = System.Windows.Forms.DockStyle.Right;
            this.ButtonConfirm.Location = new System.Drawing.Point(418, 0);
            this.ButtonConfirm.Name = "ButtonConfirm";
            this.ButtonConfirm.Size = new System.Drawing.Size(75, 30);
            this.ButtonConfirm.Style = Base4Controls.Base4ColorStyle.Blue;
            this.ButtonConfirm.TabIndex = 3;
            this.ButtonConfirm.Text = "Ok";
            this.ButtonConfirm.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.ButtonConfirm.UseSelectable = true;
            this.ButtonConfirm.Click += new System.EventHandler(this.ButtonConfirm_Click);
            // 
            // ButtonCancel
            // 
            this.ButtonCancel.Dock = System.Windows.Forms.DockStyle.Right;
            this.ButtonCancel.Location = new System.Drawing.Point(493, 0);
            this.ButtonCancel.Name = "ButtonCancel";
            this.ButtonCancel.Size = new System.Drawing.Size(75, 30);
            this.ButtonCancel.Style = Base4Controls.Base4ColorStyle.Blue;
            this.ButtonCancel.TabIndex = 2;
            this.ButtonCancel.Text = "Cancel";
            this.ButtonCancel.Theme = Base4Controls.Base4ThemeStyle.Light;
            this.ButtonCancel.UseSelectable = true;
            this.ButtonCancel.Click += new System.EventHandler(this.ButtonCancel_Click);
            // 
            // base4Label1
            // 
            //this.MySearchBox.AutoSize = true;
            //this.MySearchBox.Location = new System.Drawing.Point(486, 25);
            
            //this.MySearchBox.Size = new System.Drawing.Size(79, 19);
            ////this.MySearchBox.Style = Base4Controls.Base4ColorStyle.Blue;
            //this.MySearchBox.TabIndex = 2;
            //this.MySearchBox.Text = "base4Label1";
            //this.MySearchBox.Theme = Base4Controls.Base4ThemeStyle.Light;
            // 
            // BrowseBase4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackImagePadding = new System.Windows.Forms.Padding(25, 15, 2, 10);
            this.BackMaxSize = 40;
            this.ClientSize = new System.Drawing.Size(578, 459);
            this.Controls.Add(this.toolStripContainer1);
            this.Name = "BrowseBase4";
            this.Padding = new System.Windows.Forms.Padding(0, 60, 0, 0);
            this.TextAlign = Base4Controls.Forms.MetroFormTextAlign.Center;
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.MyBdPanel.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myBdGridView1)).EndInit();
            this.base4Panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private ToolStripContainer toolStripContainer1;
        //private GroupBox groupBox1;
        internal TableLayoutPanel MyBdPanel;
        private Panel panel4;
        public Base4GridView myBdGridView1;
        private Panel MySearchPanel;
        private Base4Panel base4Panel1;
        private Base4Button ButtonConfirm;
        private Base4Button ButtonCancel;
        //private MySearchBox MySearchBox;
    }
}
﻿using Base4Entity.EFHelper;

namespace Base4Entity.MyUIControls.Properties
{
    public struct MyWhere
    {
        public string BindingField;
        public MyExpressions Expression;
        public object Value;
    }
}

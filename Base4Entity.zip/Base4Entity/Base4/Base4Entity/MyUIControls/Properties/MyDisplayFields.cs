﻿namespace Base4Entity.MyUIControls.Properties
{

    public class MyDisplayFields
    {       
        private string _displayName = string.Empty;
        private string _bindingField = string.Empty;


        public string DisplayName
        {
            get => _displayName ?? BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(BindingField)?.ToString();
            set { _displayName = value; }
        }

        public string BindingField
        {
            get { return _bindingField; }
            set
            {
                _bindingField = value;
                DisplayName = BindingField;
            }
        }

        public MyDisplayFields()
        {
            _displayName = string.Empty;
            _bindingField = string.Empty;
            
        }
                
    }
}

﻿using System.Drawing;

namespace efcfwf.MyUIControls.Controls
{
    public class Animations
    {
        public enum AnimateStyle
        {
            SlideDown = 1,
            FadeIn = 2,
            ZoomIn = 3
        }

        public enum Icon
        {
            Application = 1,
            Exclamation = 2,
            Error = 3,
            Warning = 4,
            Info = 5,
            Question = 6,
            Shield = 7,
            Search = 8
        }

        public Size FormSize;
        public AnimateStyle Style;

        public Animations(Size formSize, AnimateStyle style)
        {
            FormSize = formSize;
            Style = style;
        }
    }
}

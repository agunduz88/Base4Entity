﻿using System;
using System.ComponentModel;
using System.Data.Entity;
using Base4Controls.Forms;
using Base4Entity.Properties;

//using efcfwf.Properties;

namespace Base4Entity.MyUIControls.Controls
{
    [Browsable(false)]
    public class Base4Form:BaseForm
    {
        private DbContext _context;
        public DbContext Context
        {
            get => _context;
            set => _context = value;
        }
        public Base4Form()
        {
            Load += Base4Form_Load;
            

        }

        private void Base4Form_Load(object sender, EventArgs e)
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;
            Text = Resources.ResourceManager.GetObject(Text)?.ToString() ?? Text;
        }
    }
}

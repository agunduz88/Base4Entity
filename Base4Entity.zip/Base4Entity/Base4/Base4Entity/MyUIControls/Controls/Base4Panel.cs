﻿using System;
using Base4Controls.Controls;

namespace Base4Entity.MyUIControls.Controls
{
public class Base4Panel:BasePanel
    {

        public Base4Panel()
        {

            HandleCreated += Base4Panel_HandleCreated;
            
        }

        private void Base4Panel_HandleCreated(object sender, EventArgs e)
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;
        }


    }
}

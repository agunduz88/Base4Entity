﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Base4Entity.MyUIControls.Controls
{
    
    class MyCrudGridView : DataGridView
    {       
        //[Category("MyFrameWork")]
        //public BindingSource MyBindingSource { get; set; }
        
        internal List<object> MyDeletedRows = new List<object>();

        #region MyToolStripProperties
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        private readonly ToolStrip _myTopToolStrip = new ToolStrip();
        private readonly ToolStrip _mySideToolStrip = new ToolStrip();
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal readonly ToolStripButton MyRemoveRowBtn = new ToolStripButton();
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal readonly ToolStripButton MyAddButton = new ToolStripButton();
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal readonly ToolStripButton MyUpButton = new ToolStripButton();
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        internal readonly ToolStripButton MyDownButton = new ToolStripButton();

        private bool _hasAddButton;
        [Category("MyFrameWork")]
        public bool HasAddButton
        {
            get => _hasAddButton;
            set
            {
                _hasAddButton = value;
                MyAddButton.Visible = _hasAddButton;

            }
        }

        private bool _hasRemoveButton;
        [Category("MyFrameWork")]
        public bool HasRemoveButton
        {
            get => _hasRemoveButton;
            set
            {
                _hasRemoveButton = value;
                MyRemoveRowBtn.Visible = _hasRemoveButton;
            }
        }
       
        #endregion

        #region MyBdProperties          
        private bool _myToolBarIsVisible = true;
        [Category("MyFrameWork")]
        public bool MyToolBarIsVisible
        {
            get => _myToolBarIsVisible;
            set
            {
                _myToolBarIsVisible = value;
                _myTopToolStrip.Visible = _myToolBarIsVisible;
            }
        }

        private bool _mySideToolBarIsVisible = true;
        [Category("MyFrameWork")]
        public bool MySideToolBarIsVisible
        {
            get => _mySideToolBarIsVisible;
            set
            {
                _mySideToolBarIsVisible = value;
                _mySideToolStrip.Visible = _mySideToolBarIsVisible;
            }
            
        }

       

        #endregion

        #region Constructors
        public MyCrudGridView()
        {
            //context = new MyGymEntities();
            BackgroundColor = Color.White;
            RowHeadersVisible = false;
            GridColor = Color.LightGray;
            BorderStyle = BorderStyle.None;
            MultiSelect = false;
            SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AllowUserToOrderColumns = false;
            AllowUserToResizeRows = false;
            AutoGenerateColumns = true;
            //ReadOnly = true;

            MyAddToolStripButtons();
            ParentChanged += MyGridView_ParentChanged;
            LocationChanged += MyGridView_LocationChanged;
            Disposed += MyGridView_Disposed;
            DataError += MyCrudGridView_DataError;
            MyAddButton.Visible = false;
        }

        private void MyCrudGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            
        }

        #endregion

        #region ToolStripFunctions        
        private void AutoAddTopToolStrip()
        {
            if (Parent == null) return;

            _myTopToolStrip.Location = new Point(Location.X, Location.Y - _myTopToolStrip.Padding.Bottom);
            _mySideToolStrip.Location = new Point(Location.X,Location.Y);
            _mySideToolStrip.Dock = DockStyle.Left;
            //_mySideToolStrip.Width = 10;
            Parent.Controls.Add(_myTopToolStrip);
            Parent.Controls.Add(_mySideToolStrip);
        }

        private void MyAddToolStripButtons()
        {
            MyAddButton.Text = @"+";
            _myTopToolStrip.Items.Add(MyAddButton);
            MyAddButton.Click += MyAddButton_Click;

            MyRemoveRowBtn.Text = @"-";
            _myTopToolStrip.Items.Add(MyRemoveRowBtn);
            MyRemoveRowBtn.Click += _myRemoveRowBtn_Click;


            MyUpButton.Text = @"U";
            _mySideToolStrip.Items.Add(MyUpButton);
            MyUpButton.Click += MyUpButton_Click;

            MyDownButton.Text = @"D";
            _mySideToolStrip.Items.Add(MyDownButton);
            MyDownButton.Click += MyDownButton_Click;
        }

        private void MyDownButton_Click(object sender, EventArgs e)
        {
            
        }

        private void MyUpButton_Click(object sender, EventArgs e)
        {
            
        }

        internal void MyAddButton_Click(object sender, EventArgs e)
        {
            
        }
        #endregion

        #region BdClickEvents        


        internal void _myRemoveRowBtn_Click(object sender, EventArgs e)
        {
            //Boş row silinemesin kontrolü yapılsın
            
            
            if (SelectedRows.Count > 0)
            {
                var row = SelectedRows[0];
                if (row.DataBoundItem is null) return;

                var detail = row.DataBoundItem;

                if (detail == null) return;
                MyDeletedRows.Add(detail);

                Rows.Remove(SelectedRows[0]);                 
            }
        }
    
    
        #endregion

        #region GridViewEvents
        private void MyGridView_ParentChanged(object sender, EventArgs e)
        {
            AutoAddTopToolStrip();
        }



        private void MyGridView_LocationChanged(object sender, EventArgs e)
        {

        }

        private void MyGridView_Disposed(object sender, EventArgs e)
        {
            _myTopToolStrip.Dispose();
        }


        #endregion      
    }
}

﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Windows.Forms;
using Base4Controls.Components;
using Base4Controls.Controls;
using Base4Entity.EFHelper;
using Base4Entity.Extensions;
using Base4Entity.MyUIControls.UIForms;

//using efcfwf;
//using efcfwf.Migrations;

//using CONTACTS_BASE = efcfwf.CONTACTS_BASE;

namespace Base4Entity.MyUIControls.Controls
{

    public class Base4ComboBox : BaseComboBox
    {
        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public new object DataBindings { get; set; }


        //private IListSource binding = new BindingSource();
        [Category("Base4Data")]
        public new object DataSource
        {
            get => base.DataSource;
            set => base.DataSource = value;
        }


        [Category("Base4Data")]
        public new string DisplayMember
        {
            get => base.DisplayMember;
            set => base.DisplayMember = value;
        }
        [Category("Base4Data")]
        public new string ValueMember
        {
            get => base.ValueMember;
            set => base.ValueMember = value;
        }
        private object _parentData;
        private object _originalData;
        internal Base4Crud.CrudActions EditingState;
        //private string _myBindingField;

        private string _bindingField;
        [Category("Base4Data")]
        //[Browsable(false)]
        public string BindingField
        {
            get => _bindingField;
            set
            {

                _bindingField = value;
                FieldName = value;
                if (BindingField != null)
                    _label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(BindingField)?.ToString() ?? value;
            }
        }


        private string _fieldName;
        [Category("Base4Data")]
        public string FieldName
        {
            get => _fieldName;
            set
            {
                if (value == null) return;
                _fieldName = value;
                _label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(value)?.ToString() == null
                    ? value
                    : (BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(BindingField)?.ToString() ?? BindingField);
            }
        }
        private MyExpressions _myExpression = MyExpressions.Equals;
        public MyExpressions MyExpression
        {
            get => _myExpression;
            set => _myExpression = value;
        }

        private readonly Base4Label _label;


        [Browsable(false)]
        public int TotalWidth => _label.Width + Width;

        [Browsable(false)]
        public int LabelWidth => _label.Width;

        public Base4ComboBox()
        {
            DropDownStyle = ComboBoxStyle.DropDownList;

            BindingContextChanged += MyLbComboBox_BindingContextChanged;
            SelectedIndexChanged += MyLbComboBox3_SelectedIndexChanged;
            _label = new Base4Label();
            _label.Resize += Label_Resize;

            HandleCreated += Base4ComboBox_HandleCreated;
            Disposed += Base4ComboBox_Disposed;
            base.DataBindings.DefaultDataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;


            GotFocus += Base4ComboBox_GotFocus;
            LostFocus += Base4ComboBox_LostFocus;
            MouseHover += Base4ComboBox_MouseHover;
        }

        private void Base4ComboBox_MouseHover(object sender, EventArgs e)
        {
            using (var g = Graphics.FromHwnd(Handle))
            {
                Rectangle bounds = new Rectangle(0, 0, Width, Height);
                ControlPaint.DrawBorder(g, bounds, BaseConfigurations.BaseConfigurations.StyleColor, ButtonBorderStyle.Solid);
            }
        }

        private void Base4ComboBox_LostFocus(object sender, EventArgs e)
        {
            _isOnFocus = false;
        }

        private void Base4ComboBox_GotFocus(object sender, EventArgs e)
        {
            _isOnFocus = true;

        }



        private void Base4ComboBox_Disposed(object sender, EventArgs e)
        {
            _label.Dispose();
        }

        private void Base4ComboBox_HandleCreated(object sender, EventArgs e)
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;
        }

        private bool _isOnFocus;

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);

            if (!_isOnFocus) return;
            using (var g = Graphics.FromHwnd(Handle))
            {
                Rectangle bounds = new Rectangle(0, 0, Width, Height);
                ControlPaint.DrawBorder(g, bounds, BaseConfigurations.BaseConfigurations.StyleColor, ButtonBorderStyle.Solid);
            }
        }

        readonly Base4ToolTip _requiredToolTip = new Base4ToolTip
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme,
            Style = BaseConfigurations.BaseConfigurations.Style,
            ToolTipIcon = ToolTipIcon.Error,
            ShowAlways = true
        };


        private string _errrorMessage;
        public void SetErrorMessage(string pErrorMessage)
        {
            _errrorMessage = pErrorMessage;
            HasRules = true;
        }
        private bool _hasRules;
        [Browsable(false)]
        public bool HasRules
        {
            get => _hasRules;
            set
            {
                _hasRules = value;
                if (HasRules)
                {
                    _requiredToolTip.SetToolTip(this, _errrorMessage);
                    UseCustomBackColor = true;
                    BackColor = BaseConfigurations.BaseConfigurations.StyleColor;
                    //DefaultBackColor = BaseConfigurations.StyleColor;
                }
                else
                {
                    _requiredToolTip.RemoveAll();
                    BackColor = BaseConfigurations.BaseConfigurations.ThemeColor;
                }

            }
        }
        protected override void OnParentChanged(EventArgs e)
        {
            base.OnParentChanged(e);
            _label.Parent = Parent;

        }
        protected override void OnLocationChanged(EventArgs e)
        {
            base.OnLocationChanged(e);
            MoveLabel();
        }
        private void MoveLabel()
        {
            _label.Location = new Point(Left - _label.Width - 10, Top + 3);

        }


        private void Label_Resize(object sender, EventArgs e)
        {
            MoveLabel();
        }




        private void MyLbComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                _parentData.SetPropertyValue(BindingField, SelectedValue);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void MyLbComboBox_BindingContextChanged(object sender, EventArgs e)
        {

            if (!Utils.IsInDesignMode && EditingState != Base4Crud.CrudActions.Add)
            {
                MySetDropDownWidth();
            }

            try
            {
                ((Form)TopLevelControl).Load += MyLbComboBox3_Load1;
            }
            catch (Exception)
            {
                //continue
            }


        }



        private void MyLbComboBox3_Load1(object sender, EventArgs e)
        {
            //if(sender.GetType() != typeof(Base4Crud)) return;
            if (sender.GetType().BaseType != typeof(Base4Crud)) return;
            EditingState = ((Base4Crud)sender).EditingState;
            if (DataSource == null) return;
            if (DataSource.GetType() != typeof(BindingSource)) return;
            if (EditingState == Base4Crud.CrudActions.Idle)
                Enabled = false;
            _parentData = ((Base4Crud)sender).TestData ??
                         ((Base4Crud)sender).BindingSource.Current;


            var tableName = string.IsNullOrEmpty(((BindingSource)DataSource).DataMember)
                ? ((BindingSource)DataSource).DataSource.GetPropValue("Name").ToString()
                : ((BindingSource)DataSource).DataMember;
            //var fakeData = ((IEnumerable)((Base4Crud)sender).Context.GetPropValue(((BindingSource)DataSource).DataMember)).ToDynamicList();
            var fakeData = ((IEnumerable)((Base4Crud)sender).Context.GetPropValue(tableName)).ToDynamicList();

            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == tableName);



            //var projectName = Assembly.GetExecutingAssembly().GetName().Name;
            var fakeInstance = Activator.CreateInstance(type, false);

            try
            {
                fakeInstance.SetPropertyValue(ValueMember, null);
            }
            catch (Exception)
            {
                //fakeInstance.SetPropertyValue(ValueMember, 0);
            }
            fakeInstance.SetPropertyValue(DisplayMember, "<Select>");



            try
            {
                _originalData = ((Base4Crud)TopLevelControl)?.Context.Entry(_parentData).CurrentValues.ToObject();
            }
            catch (Exception)
            {

                try
                {
                    _originalData = _parentData.Clone();
                }
                catch (Exception)
                {
                    // ignored
                }
            }
            //OriginalData = ParentData.Clone();
            fakeData.Insert(0, fakeInstance);


            DataSource = fakeData;

            foreach (object data in fakeData)
            {
                if (data.GetPropValue(ValueMember) == null && _originalData.GetPropValue(BindingField) == null)
                    SelectedItem = data;
                else if (data.GetPropValue(ValueMember) == null)
                    continue;
                else if (data.GetPropValue(ValueMember).Equals(_originalData.GetPropValue(BindingField)))
                    SelectedItem = data;
            }

            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;

        }


        internal int MySetDropDownWidth()
        {
            if (Items.Count == 0) return 0;

            if (Items.Count >1)
                SelectedIndex = 1;
       
            SelectedIndex = 0;

            var maxWidth = (from object obj in Items select TextRenderer.MeasureText(obj.GetPropValue(DisplayMember).ToString(), Font).Width).Concat(new[] { 0 }).Max();
            Width = maxWidth + 80;
            return Width;
        }

        internal void MyFillComboDataSource()
        {
            if (Utils.IsInDesignMode) return;

            if (DataSource == null)
                Console.WriteLine(@"Datasource is empty");

            var tableName = DataSource.GetPropValue("DataSource").GetPropValue("Name").ToString()
                .Contains("BindingSource")
                ? DataSource.GetPropValue("DataSource").GetPropValue("Name").ToString()
                    .Replace("BindingSource", "")
                : DataSource.GetPropValue("DataSource").GetPropValue("Name").ToString();

            using (var context = EntityBase.MyCreateNewDbContextInstance())
            {
                var data = ((IEnumerable)context.GetPropValue(tableName)).ToDynamicList();
                if (data.Count == 0) return;


                Type type = Assembly.GetEntryAssembly()
                    .DefinedTypes
                    .FirstOrDefault(t => t.Name == tableName);

                var fakeInstance = Activator.CreateInstance(type, false);

                //var projectName = Assembly.GetExecutingAssembly().GetName().Name;


                //var projectName = Assembly.GetExecutingAssembly().GetName().Name;
                //var fakeInstance = Assembly.GetExecutingAssembly().CreateInstance(projectName + "." + tableName);
                fakeInstance.SetPropertyValue(ValueMember, -1);
                fakeInstance.SetPropertyValue(DisplayMember, "<Seçiniz>");

                data.Insert(0, fakeInstance);
                DataSource = data;
            }
        }



    }
}

﻿using System;
using System.Windows.Forms;
using Base4Controls;

namespace Base4Entity.MyUIControls.Controls
{
    public class Base4ToolStrip:ToolStrip
    {

        public Base4ToolStrip()
        {
            HandleCreated += Base4ToolStrip_HandleCreated;
            Renderer  = new MySr();
        }

        private void Base4ToolStrip_HandleCreated(object sender, EventArgs e)
        {
            BackColor = BaseConfigurations.BaseConfigurations.ThemeColor;
            ForeColor = BaseConfigurations.BaseConfigurations.Theme == Base4ThemeStyle.Dark?Base4Colors.White:Base4Colors.Black;

        }
        protected void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
        {
           

        }
    }
    public class MySr : ToolStripSystemRenderer
    {
        protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
        {
            //base.OnRenderToolStripBorder(e);
        }
    }
}

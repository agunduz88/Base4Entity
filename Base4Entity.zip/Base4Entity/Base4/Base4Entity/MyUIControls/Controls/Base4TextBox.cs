﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using Base4Controls.Components;
using Base4Controls.Controls;
using Base4Controls.Forms;
using Base4Controls.MessageBox;
using Base4Entity.Base4Interfaces;
using Base4Entity.EFHelper;
using Base4Entity.Extensions;
using Base4Entity.MyUIControls.UIForms;

namespace Base4Entity.MyUIControls.Controls
{    
    public class Base4TextBox : BaseTextBox,IBaseBrowseDialog
    {
        #region CustomProperties        

        private string _bindingField;

        [Browsable(false)]
        public string BindingField
        {
            get => _bindingField;
            set
            {

                _bindingField = value;
                if (BindingField != null)
                    _label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(BindingField)?.ToString() ?? value;
            }
        }


        //private Base4UserControl _informationPanela { get; set; }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)] [Browsable(false)]
        private Base4UserControl _informationPanel;       

        private string _fieldName;
        [Category("Data")]
        public string FieldName
        {
            get => _fieldName;
            set
            {                
                _fieldName = value;
                if (FieldName != null)
                    _label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(value)?.ToString() == null
                    ? value
                    : (BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(BindingField)?.ToString() ?? BindingField);
            }
        }

        private string _browseDialogName;
        [Category("Data")]
        public string BrowseDialogName
        {
            get => _browseDialogName;
            set => _browseDialogName = value;
        }

        private string _informationPanelName;
        [Category("Data")]
        public string InformationPanelName
        {
            get => _informationPanelName;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    _informationPanel.Visible = false;

                    originalInfVisibleState = false;                    
                }                    
                else
                {
                    _informationPanelName = value;
                    originalInfVisibleState = true;
                    CreateInfPanel();
                }               
            }
        }
        
        private MyExpressions _myExpression;
        public MyExpressions Expression
        {
            get => _myExpression;
            set => _myExpression = value;
        }
        #endregion
      

        public Base4TextBox()
        {
            MyInitialize();
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;
        }      

        private void MyInitialize()
        {
            _myExpression = MyExpressions.Equals;
            
            _label = new Base4Label
            {
                AutoSize = true,
                Font = Font,
                Location = Location                
            };
            _informationPanel = new Base4UserControl();
            //_informationPanel.Visible = false;
            DataBindings.DefaultDataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;

            _label.Resize += Label_Resize;            
            

            Disposed += BaseTextBox_Disposed;

            BindingContextChanged += BaseTextBox_BindingContextChanged;

            DataBindings.CollectionChanged += DataBindings_CollectionChanged;

            ButtonClick += Base4TextBox_ButtonClick;
            Validated += Base4TextBox_Validated;
            LostFocus += Base4TextBox_LostFocus;
            
            Resize += Base4TextBox_Resize;

            originalLabelVisibleState = true;

        }

       

        private void Base4TextBox_Resize(object sender, EventArgs e)
        {
            MoveInfPanel();
        }

        private void Base4TextBox_ButtonClick(object sender, EventArgs e)
        {

            var bd = EntityBase.CreateGenericBrowseForm(BrowseDialogName);
            if(bd == null) return;
            
            try
            {
                using (bd)
                {                    

                    ((dynamic)bd).BrowseDialogDelegate = this;
                    ((dynamic)bd).MyBdPanel.RowStyles[2].Height = 36;
                    ((dynamic)bd).myBdGridView1.BrowseDialogDelegateGrid = ((dynamic)bd);
                    ((dynamic) bd).myBdGridView1.HideButtons();
                    //Bd.BrowseDialogDelegate = this;
                    //Bd.MyBdPanel.RowStyles[2].Height = 36;
                    //Bd.myBdGridView1.BrowseDialogDelegateGrid = Bd;
                    bd.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                var innerMessage = ex.GetBaseException().Message;

                Base4MessageBox.Show((Form)TopLevelControl, innerMessage, "Error");
                }
            }

        private void DataBindings_CollectionChanged(object sender, CollectionChangeEventArgs e)
        {
            try
            {
                BindingField = DataBindings.BindableComponent.DataBindings[0].BindingMemberInfo.BindingField;
                FieldName = DataBindings.BindableComponent.DataBindings[0].BindingMemberInfo.BindingField;                
            }
            catch (Exception)
            {
                // ignored
            }
        }

        private void BaseTextBox_BindingContextChanged(object sender, EventArgs e)
        {           
            try
            {       
                if(TopLevelControl != null)
                   ((BaseForm) TopLevelControl).Load += BaseTextBox_Load;
                       
            }
            catch (Exception)
            {
                // ignored
            }
        }                

        private void BaseTextBox_Load(object sender, EventArgs e)
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;

            if (_informationPanel.Visible && !string.IsNullOrEmpty(InformationPanelName))
            {
                FillInfPanelDataSource();
            }
                

        }

        
        
        private Base4Label _label;

        [Browsable(false)]
        public int TotalWidth => _label.Width + Width;

        [Browsable(false)]
        public int LabelWidth => _label.Width;

        private bool _hasRules;
        
        readonly Base4ToolTip _requiredToolTip = new Base4ToolTip
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme,
            Style = BaseConfigurations.BaseConfigurations.Style,
            ToolTipIcon = ToolTipIcon.Error,
            ShowAlways = true
        };

        private string _errrorMessage;
        public void SetErrorMessage(string pErrorMessage)
        {
            _errrorMessage = pErrorMessage;
            HasRules = true;
        }

        private void BaseTextBox_Disposed(object sender, EventArgs e)
        {            
            _label.Dispose();

            _informationPanel.Dispose();

        }

       

        private void Label_Resize(object sender, EventArgs e)
        {
            MoveLabel();
        }
      
        protected override void OnParentChanged(EventArgs e)
        {
            base.OnParentChanged(e);            
            _label.Parent = Parent;
            _informationPanel.Parent = Parent;

        }
        protected override void OnLocationChanged(EventArgs e)
        {
            base.OnLocationChanged(e);
            MoveLabel();
            MoveInfPanel();
        }
        
        private void MoveLabel()
        {           
            _label.Location = new Point(Left - _label.Width - 10, Top + 2);          
        }

        private void MoveInfPanel()
        {
            if (string.IsNullOrWhiteSpace(InformationPanelName))
                _informationPanel.Visible = false;
            _informationPanel.Location = new Point(Right + 10, Top - 2);
        }

        
        [Browsable(false)]
        public bool HasRules
        {
            get => _hasRules;
            set
            {
                _hasRules = value;
                if (HasRules)
                {
                    _requiredToolTip.SetToolTip(this, _errrorMessage);
                    UseCustomBackColor = true;
                    BackColor = BaseConfigurations.BaseConfigurations.StyleColor;
                    //DefaultBackColor = BaseConfigurations.StyleColor;
                }
                else
                {
                    _requiredToolTip.RemoveAll();
                    BackColor = BaseConfigurations.BaseConfigurations.ThemeColor;
                }
                    
            }
        }

        public void ReturnSelectedRow(object primaryKeyValue)
        {                        
            Text = primaryKeyValue.ToString();
            var loDbSet = (((Base4Form)TopLevelControl)?.Context).GetPropValue(_tableName);
            try
            {
                _informationPanel.BindingSource.DataSource = loDbSet.GetType().GetMethod("Find")?.Invoke(loDbSet, new object[] { new object[] { Text } });
            }
            catch (Exception e)
            {
                _informationPanel.BindingSource.DataSource = loDbSet.GetType().GetMethod("Find")?.Invoke(loDbSet, new object[] { new object[] { Convert.ToInt32(Text) } });
            }
            
        }
      
        private void Base4TextBox_Validated(object sender, EventArgs e)
        {
            if (!ShowButton || string.IsNullOrWhiteSpace(InformationPanelName)) return;
            FillInfPanelDataSource();
            if (!Text.Equals(string.Empty)) return;
            try
            {
                ((Base4Crud)((Base4TextBox)sender).TopLevelControl)?.TestData.SetPropertyValue(BindingField,null);
            }
            catch (Exception)
            {
                // ignored
            }
        }

        private bool originalLabelVisibleState;
        private bool originalInfVisibleState;
        
        protected override void OnVisibleChanged(EventArgs e)
        {                                             
            base.OnVisibleChanged(e);

            if (!Visible)
            {
                _label.Visible = false;
                _informationPanel.Visible = false;
            }
            else
            {
                _label.Visible = originalLabelVisibleState;
                _informationPanel.Visible = originalInfVisibleState;
            }
           
        }

        private void Base4TextBox_LostFocus(object sender, EventArgs e)
        {
            if (!ShowButton || string.IsNullOrWhiteSpace(InformationPanelName)) return;
            FillInfPanelDataSource();
            if (!Text.Equals(string.Empty)) return;
            try
            {
                ((Base4Crud)((Base4TextBox)sender).TopLevelControl)?.TestData.SetPropertyValue(BindingField, null);
            }
            catch (Exception)
            {
                // ignored
            }
        }
        private void FillInfPanelDataSource()
        {
            try
            {
                if (string.IsNullOrEmpty(Text))
                {
                    _informationPanel.BindingSource.DataSource = EntityBase.CreatePocoInstanceOf(_tableName);
                }
                else
                {
                    var loDbSet = (((Base4Form) TopLevelControl)?.Context).GetPropValue(_tableName);
                    try
                    {
                        _informationPanel.BindingSource.DataSource = loDbSet.GetType().GetMethod("Find")?.Invoke(loDbSet, new object[] { new object[] { Text } });
                    }
                    catch (Exception)
                    {
                        _informationPanel.BindingSource.DataSource = loDbSet.GetType().GetMethod("Find")?.Invoke(loDbSet, new object[] { new object[] { Convert.ToInt32(Text) } });
                    }                  
                }
            }
            catch (Exception)
            {
                Base4MessageBox.Show((Form)TopLevelControl, $"{Text} is not a valid entry", "Error");
                Clear();
            }
        }


        
        //private void SetInfPanelLocation()
        //{
        //    _informationPanel.Location = new Point(Right +10, Top-2);
        //}
        private string _tableName;
        private string _primaryKey;
        private void CreateInfPanel()
        {            
           if(string.IsNullOrEmpty(InformationPanelName))return;
            try
            {
                try
                {
                    var type = Assembly.GetEntryAssembly().DefinedTypes.FirstOrDefault(x => x.Name == InformationPanelName);
                    _informationPanel = Activator.CreateInstance(type, false) as Base4UserControl;
                }
                catch (Exception e)
                {
                   
                }
                

                if (_informationPanel != null)
                {
                    _informationPanel.Parent = Parent;
                    _informationPanel.Enabled = false;
                    _informationPanel.Visible = true;
                    //_informationPanel.BringToFront();
                    _tableName = _informationPanel.BindingSource.DataSource.GetPropValue("Name").ToString();
                }
                //_primaryKey = EntityBase.MyGetPrimaryKey(_tableName);             
            }
            catch (Exception ex)
            {
                var innerMessage = ex.GetBaseException().Message;

                Base4MessageBox.Show((Form)TopLevelControl, innerMessage, "Error");
            }
        }
    }
}

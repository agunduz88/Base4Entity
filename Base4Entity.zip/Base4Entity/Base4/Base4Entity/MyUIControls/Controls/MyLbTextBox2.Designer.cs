﻿using System.ComponentModel;
using System.Windows.Forms;
using Base4Entity.EFHelper;

namespace Base4Entity.MyUIControls.Controls
{
    partial class MyLbTextBox2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.myLbTextBox1 = new Base4TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // myLbTextBox1
            // 
            this.myLbTextBox1.Location = new System.Drawing.Point(100, 6);
            this.myLbTextBox1.Margin = new System.Windows.Forms.Padding(100, 3, 3, 3);
            this.myLbTextBox1.BindingField = null;
            this.myLbTextBox1.Expression = MyExpressions.Equals;
            this.myLbTextBox1.Name = "myLbTextBox1";
            this.myLbTextBox1.Size = new System.Drawing.Size(100, 20);
            this.myLbTextBox1.TabIndex = 1;
            // 
            // MyLbTextBox2
            // 
            //this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            //this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.myLbTextBox1);
            this.Controls.Add(this.label1);
            this.Name = "MyLbTextBox2";
            this.Size = new System.Drawing.Size(204, 30);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Base4TextBox myLbTextBox1;
    }
}

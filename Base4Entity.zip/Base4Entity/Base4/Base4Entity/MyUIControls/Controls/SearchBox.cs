﻿using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Base4Controls.Forms;

namespace Base4Entity.MyUIControls.Controls
{
    //    [ToolboxItem(false)]
    //    [Browsable(false)]
    //    [EditorBrowsable(EditorBrowsableState.Never)]
    public partial class MySearchBox : Form
    {
        public MySearchBox()
        {
            InitializeComponent();
            MyInitialize();
        }

        private void MyInitialize()
        {
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            //StartPosition = FormStartPosition.CenterScreen;
           
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
           
            Graphics g = e.Graphics;
            Rectangle rect = new Rectangle(new Point(0, 0), new Size(Width - 1, Height - 1));
             
            Pen pen = new Pen( Color.FromArgb(0, 151, 251));

            g.DrawRectangle(pen, rect);
            
        }

    }

    
}

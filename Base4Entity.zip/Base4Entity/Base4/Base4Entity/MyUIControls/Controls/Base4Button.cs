﻿using System;
using Base4Controls.Controls;
using Base4Entity.Properties;

//using efcfwf.Properties;

namespace Base4Entity.MyUIControls.Controls
{
    public class Base4Button:BaseButton
    {
        public Base4Button()
        {
            HandleCreated += Base4Button_HandleCreated;
        }

        private void Base4Button_HandleCreated(object sender, EventArgs e)
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;
            //Text =  Resources.ResourceManager.GetObject(Text)?.ToString() ?? Text;
        }

       
    }
}

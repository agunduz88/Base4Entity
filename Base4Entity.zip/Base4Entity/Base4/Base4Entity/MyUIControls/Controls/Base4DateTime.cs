﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Base4Controls.Components;
using Base4Controls.Controls;
using Base4Entity.EFHelper;
using Base4Entity.Extensions;

namespace Base4Entity.MyUIControls.Controls
{

    public class MyDateTime : BaseDateTime
    {
        private string _bindingField;

        [Browsable(false)]
        public string BindingField
        {
            get => _bindingField;
            set
            {

                _bindingField = value;
                //if (BindingField != null)
                    //_label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetString(BindingField) ?? value;
            }
        }
        private MyExpressions _myExpression;

        public MyExpressions Expression
        {
            get => _myExpression;
            set => _myExpression = value;
        }
    }
public class Base4DateTime : BaseDateTime
    {
        #region Member variables
        private string _bindingField;

        [Browsable(false)]
        public string BindingField
        {
            get => _bindingField;
            set
            {

                _bindingField = value;
                if (BindingField != null)
                    _label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetString(BindingField) ?? value;
            }
        }
        private MyExpressions _myExpression;

        public MyExpressions Expression
        {
            get => _myExpression;
            set => _myExpression = value;
        }
        // true, when no date shall be displayed (empty DateTimePicker)
        private bool _isNull;

        // If _isNull = true, this value is shown in the DTP
        private string _nullValue;

        // The format of the DateTimePicker control
        private DateTimePickerFormat _format = DateTimePickerFormat.Short;

        // The custom format of the DateTimePicker control
        private string _customFormat;

        // The format of the DateTimePicker control as string

        #endregion

        #region Constructor

        /// <inheritdoc />
        /// <summary>
        /// Default Constructor
        /// </summary>
        public Base4DateTime()
        {
            base.Format = DateTimePickerFormat.Custom;
            

            DataBindings.DefaultDataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;
            NullValue = " ";
            //Format = DateTimePickerFormat.Long;

            if (!Utils.IsInDesignMode)
            {
                HandleCreated += Base4DateTime_HandleCreated;
            }



            _label = new Base4Label
            {
                AutoSize = true,
                Font = Font,
                Location = Location
            };

            Disposed += Base4DateTime_Disposed;
            _label.Resize += _label_Resize;

            DataBindings.CollectionChanged += DataBindings_CollectionChanged;
            this.DropDown += Base4DateTime_DropDown;            
        }

        private void Base4DateTime_DropDown(object sender, EventArgs e)
        {
            base.Format = DateTimePickerFormat.Short;
        }

        private void DataBindings_CollectionChanged(object sender, CollectionChangeEventArgs e)
        {
            try
            {
                BindingField = DataBindings.BindableComponent.DataBindings[0].BindingMemberInfo.BindingField;
                FieldName = DataBindings.BindableComponent.DataBindings[0].BindingMemberInfo.BindingField;
            }
            catch (Exception)
            {
                // ignored
            }
        }

        private void Base4DateTime_HandleCreated(object sender, EventArgs e)
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;
        }

       
        #endregion

        #region Public properties

       


        private string _fieldName;
        [Category("Data")]
        public string FieldName
        {
            get => _fieldName;
            set
            {
                //if(value == null) return;
                _fieldName = value;
                _label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetString(value) == null
                    ? value
                    : (BaseConfigurations.BaseConfigurations.Base4Resources.GetString(BindingField) ?? BindingField);
            }
        }
        [Bindable(true)]
        [Browsable(false)]
        public new object Value
        {
            get
            {
                if (_isNull)
                    return null;
                return base.Value;
            }
            set
            {
                if (value == null || value == DBNull.Value|| value is string)
                {
                    SetToNullValue();
                }
                else
                {
                    SetToDateTimeValue();                   
                    base.Value = Convert.ToDateTime(value);
                }
            }
        }      
        [Browsable(true)]
        [DefaultValue(DateTimePickerFormat.Long), TypeConverter(typeof(Enum))]
        public new DateTimePickerFormat Format
        {
            get => _format;
            set
            {
                _format = value;
                if (!_isNull)
                    SetFormat();
                OnFormatChanged(EventArgs.Empty);
            }
        }

        /// <summary>
        /// Gets or sets the custom date/time format string.
        /// <value>A string that represents the custom date/time format. The default is a null
        /// reference (<b>Nothing</b> in Visual Basic).</value>
        /// </summary>
        public new String CustomFormat
        {
            get => _customFormat;
            set => _customFormat = value;
        }

        /// <summary>
        /// Gets or sets the string value that is assigned to the control as null value. 
        /// </summary>
        /// <value>The string value assigned to the control as null value.</value>
        /// <remarks>
        /// If the <see cref="Value"/> is <b>null</b>, <b>NullValue</b> is
        /// shown in the <b>DateTimePicker</b> control.
        /// </remarks>
        [Browsable(true)]
        [Category("Behavior")]
        [Description("The string used to display null values in the control")]
        [DefaultValue(" ")]
        public String NullValue
        {
            get => _nullValue;
            set => _nullValue = value;
        }
        #endregion

        #region Private methods/properties
        /// <summary>
        /// Stores the current format of the DateTimePicker as string. 
        /// </summary>
        private string FormatAsString
        {
            set => base.CustomFormat = value;
        }

        /// <summary>
        /// Sets the format according to the current DateTimePickerFormat.
        /// </summary>
        private void SetFormat()
        {
            CultureInfo ci = Thread.CurrentThread.CurrentCulture;
            DateTimeFormatInfo dtf = ci.DateTimeFormat;
            switch (_format)
            {
                case DateTimePickerFormat.Long:
                    FormatAsString = dtf.LongDatePattern;
                    break;
                case DateTimePickerFormat.Short:
                    FormatAsString = dtf.ShortDatePattern;
                    break;
                case DateTimePickerFormat.Time:
                    FormatAsString = dtf.ShortTimePattern;
                    break;
                case DateTimePickerFormat.Custom:
                    FormatAsString = CustomFormat;
                    break;
            }
        }

        /// <summary>
        /// Sets the <b>DateTimePicker</b> to the value of the <see cref="NullValue"/> property.
        /// </summary>
        private void SetToNullValue()
        {
            _isNull = true;
            base.CustomFormat = string.IsNullOrEmpty(_nullValue) ? " " : "'" + _nullValue + "'";
        }

        /// <summary>
        /// Sets the <b>DateTimePicker</b> back to a non null value.
        /// </summary>
        private void SetToDateTimeValue()
        {
            if (_isNull)
            {
                SetFormat();
                _isNull = false;
                base.OnValueChanged(new EventArgs());
            }
        }
        #endregion

        #region Events
        /// <inheritdoc />
        /// <summary>
        /// This member overrides <see cref="M:System.Windows.Forms.Control.WndProc(System.Windows.Forms.Message@)" />.
        /// </summary>
        /// <param name="m"></param>
        protected override void WndProc(ref Message m)
        {
            if (_isNull)
            {
                if (m.Msg == 0x4e)                         // WM_NOTIFY
                {
                    Nmhdr nm = (Nmhdr)m.GetLParam(typeof(Nmhdr));
                    if (nm.Code == -746 || nm.Code == -722)  // DTN_CLOSEUP || DTN_?
                        SetToDateTimeValue();
                }
            }
            base.WndProc(ref m);

        }

        [StructLayout(LayoutKind.Sequential)]
        private struct Nmhdr
        {
            private readonly IntPtr HwndFrom;
            private readonly int IdFrom;
            public readonly int Code;
        }

        /// <summary>
        /// This member overrides <see cref="Control.OnKeyDown"/>.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                base.Format = DateTimePickerFormat.Custom;
                Value = null;                
                OnValueChanged(EventArgs.Empty);
            }
            base.OnKeyUp(e);
        }

        protected override void OnValueChanged(EventArgs eventargs)
        {
            base.OnValueChanged(eventargs);
        }

        #endregion


        #region LabelAndRules
       
       
        private Base4Label _label;

        [Browsable(false)]
        public int TotalWidth => _label.Width + Width;

        [Browsable(false)]
        public int LabelWidth => _label.Width;

        private bool _hasRules;
        //_label = new Base4Label()
        //{
        //    AutoSize = true,
        //    Font = Font,
        //    Location = Location
        //};
        Base4ToolTip requiredToolTip = new Base4ToolTip
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme,
            Style = BaseConfigurations.BaseConfigurations.Style,
            ToolTipIcon = ToolTipIcon.Error,
            ShowAlways = true
        };

        private string _errrorMessage;
        public void SetErrorMessage(string pErrorMessage)
        {
            _errrorMessage = pErrorMessage;
            HasRules = true;
        }


        private void _label_Resize(object sender, EventArgs e)
        {
            MoveLabel();
        }


        private void Base4DateTime_Disposed(object sender, EventArgs e)
        {
            _label.Dispose();
        }


        protected override void OnParentChanged(EventArgs e)
        {
            base.OnParentChanged(e);
            _label.Parent = Parent;

        }
        protected override void OnLocationChanged(EventArgs e)
        {
            base.OnLocationChanged(e);
            MoveLabel();
        }
        private void MoveLabel()
        {
            _label.Location = new Point(Left - _label.Width - 10, Top + 3);

        }
        
        [Browsable(false)]
        public bool HasRules
        {
            get => _hasRules;
            set
            {
                _hasRules = value;
                if (HasRules)
                {
                    requiredToolTip.SetToolTip(this, _errrorMessage);
                    UseCustomBackColor = true;
                    BackColor = BaseConfigurations.BaseConfigurations.StyleColor;
                    //DefaultBackColor = BaseConfigurations.StyleColor;
                }
                else
                {
                    requiredToolTip.RemoveAll();
                    BackColor = BaseConfigurations.BaseConfigurations.ThemeColor;
                }

            }
        }

        #endregion
    }
}

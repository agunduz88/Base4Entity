﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Resources;
using System.Windows.Forms;
using Base4Controls.Controls;
using Base4Controls.MessageBox;
using Base4Entity.Base4Interfaces;
using Base4Entity.EFHelper;
using Base4Entity.Extensions;
using Base4Entity.MyUIControls.UIForms;
using efcfwf.MyUIControls.Controls;


//using MetroFramework.Controls;

namespace Base4Entity.MyUIControls.Controls
{
    //[Browsable(false)]
    public sealed class Base4GridView : BaseGrid
    {
        private Base4Crud.CrudActions _editingState;

        private bool _isCrud = true;
        //private bool _isParent;

        private DbContext _context;
        internal IQueryable LinqQuery;
        public IBaseBrowseDialog BrowseDialogDelegateGrid;
        internal Base4Crud MyForm;
        //internal bool MyPkIsAi;
        [Browsable(false)]
        internal bool IsFromBd;

        internal string TableName;
        internal object MyPkValue;

        public ResourceManager ParentResourceManager { get; set; }
        //private object _parentData;
        //internal IQueryable ProcessedQuery;

        internal bool IsCrud
        {
            get => _isCrud;
            set
            {
                _isCrud = value;
                MyRemoveBtn.Visible = value;

                if (!value)
                    MySearchButton.Visible = true;
            }
        }

        [Category("Base4 Appearance")]
        public string MyCrudName { get; set; } = string.Empty;

        
        private string MyPrimaryKey { get; set; }
      

        private void MyGetPrimaryKeyValueFromBd()
        {
            if (!IsFromBd) return;
            //CONTACTS_BASE a = null;
            //a.Age = 12;
            TableName = ((dynamic)TopLevelControl)?.MyGenericType.Name;
            MyPrimaryKey = EntityBase.MyGetPrimaryKey(TableName);
            
            try
            {
                MyPkValue = CurrentRow?.DataBoundItem.GetPropValue(MyPrimaryKey);
                
            }
            catch (Exception)
            {
                BaseMessages.BaseShowMessages("Query", "Query must contain Primary Key Value", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void MyCreateFormToOpenFromBd(Base4Crud.CrudActions pEditingState)
        {
            _editingState = pEditingState;

            MyGetPrimaryKeyValueFromBd();

            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == MyCrudName);

            //var fakeInstance = Activator.CreateInstance(type, false);

            //var type = Type.GetType(MyCrudName);
           
            try
            {                               
                MyForm = Activator.CreateInstance(type) as Base4Crud;

                using (MyForm)
                {

                    MyForm.EditingState = _editingState;
                    MyForm.AfterSaveEvent += MyForm_AfterSaveEvent; 
                    MyForm.BeforeSaveEvent += MyForm_BeforeSaveEvent;

                    //MyForm.Context = _context ?? MyForm.Context;
                    MyForm.MyPrimaryKey = MyPrimaryKey;
                    MyForm.MyPkValue = MyPkValue;
                    MyForm.IsFromBd = true;
                    //MyForm.TableName = BdTableName;
                    //MyForm.TestData =  

                    MyForm.ShowDialog();                  
                }
            }
            catch (Exception e)
            {
                var innerMessage = e.GetBaseException().Message;
                BaseMessages.BaseMessageDialog((Form)TopLevelControl, innerMessage, "").ShowDialog();
                return;               
            }
        }


        private void MyForm_BeforeSaveEvent(object pCurrentRecord)
        {
            
        }

      
        private void MySetFormToOpen(Base4Crud.CrudActions pEditingState)
        {
            _editingState = pEditingState;

            Type type = Assembly.GetEntryAssembly()
                .DefinedTypes
                .FirstOrDefault(t => t.Name == MyCrudName);

            try
            {
                MyForm = Activator.CreateInstance(type) as Base4Crud;

                using (MyForm)
                {
                    
                    MyForm.EditingState = _editingState;
                    MyForm.AfterSaveEvent += MyForm_AfterSaveEvent;
                    MyForm.BeforeSaveEvent += MyForm_BeforeSaveEvent;
                    MyForm.Context = _context= ((Base4Crud)TopLevelControl)?.Context ?? MyForm.Context;
                    if (MyPrimaryKey == null && MyPkValue == null)
                    {
                        
                        TableName = CurrentRow?.DataBoundItem.GetType().BaseType?.Name;


                        if (!string.IsNullOrEmpty(TableName) && !TableName.Equals("Object"))
                        {
                            var loPrimaryKey = EntityBase.MyGetPrimaryKey(TableName);
                            var loPkValue = EntityBase.MyGetPrimaryKeyValue(CurrentRow?.DataBoundItem, MyPrimaryKey);
                            MyForm.MyPrimaryKey = loPrimaryKey;
                            MyForm.MyPkValue = loPkValue;
                            
                            MyForm.TableName = TableName;
                        }
                        MyForm.IsChild = true;
                        //else
                        //{
                        //    MyForm.IsChild = true;
                        //}                                                                                               
                    }                   
                    else
                    {
                        MyForm.MyPrimaryKey = MyPrimaryKey;
                        MyForm.MyPkValue = MyPkValue;
                        MyForm.IsChild = false;
                    }
                                        
                    MyForm.TestData = _editingState != Base4Crud.CrudActions.Add ? CurrentRow?.DataBoundItem : null;                    

                    MyForm.Closed += MyForm_Closed;
                    MyForm.ShowDialog();
                }
            }
            catch (Exception e)
            {
                var innerMessage = e.GetBaseException().Message;
                 BaseMessages.BaseMessageDialog((Form)TopLevelControl, innerMessage, "").ShowDialog();
                //Base4MessageBox.Show((Form)TopLevelControl, innerMessage, "Error");
                return;
            }

           
        }

        private void MyForm_Closed(object sender, EventArgs e)
        {
            Invalidate();
        }

        private void MyForm_AfterSaveEvent(object pCurrentRecord, string pTable, bool pIsChild, OperationStatus pOperationStatus)
        {
            
            if (pIsChild)
            {
                try
                {
                    var parentData = ((Base4Crud)TopLevelControl)?.BindingSource.DataSource;

                    if (_editingState == Base4Crud.CrudActions.Add)
                    {
                        if (pOperationStatus == OperationStatus.Save)
                        {
                            try
                            {
                                parentData.GetPropValue(pTable).MyCallFunction("Add", pCurrentRecord);
                            }
                            catch (Exception)
                            {
                                parentData.MyCallFunction("Add", pCurrentRecord);
                            }
                        }
                       
                        DataSource = new BindingSource(parentData, null);
                    }


                    if (_editingState == Base4Crud.CrudActions.Edit)
                    {
                        if (pOperationStatus == OperationStatus.Canceled) //İf Canceled{
                        {
                            parentData.GetPropValue(pTable).MyCallFunction("Remove", CurrentRow?.DataBoundItem);
                            parentData.GetPropValue(pTable).MyCallFunction("Add", pCurrentRecord);
                        }
                        //else
                        //{
                        //    if (IsFromBd)
                        //    {
                        //        DataSource = new BindingSource(pCurrentRecord, null);
                        //    }
                        //}
                        
                        
                        //DataSource = new BindingSource(_context.GetPropValue(pTable) ?? pCurrentRecord, null);

                    }
                    
                }
                catch (Exception)
                {
                    _context.GetPropValue(pTable).MyCallFunction("Add", pCurrentRecord);
                    DataSource = new BindingSource(_context.GetPropValue(pTable), null);
                }
                
            }
            else
            {

                try
                {
                    var fieldsToDisplay = TopLevelControl?.GetPropValue("FieldsToDisplay").ToString();
                    if (!string.IsNullOrEmpty(fieldsToDisplay))
                    {                
                        var loDatasource = LinqQuery.Where(
                            MyPrimaryKey + "  =  @0" ,EntityBase.MyGetPrimaryKeyValue(pCurrentRecord, MyPrimaryKey)).
                            Select("new(" + fieldsToDisplay + ")", null).ToDynamicList();
                        Columns.Clear();
                        DataSource = loDatasource;
                    }
                    else
                    {
                       
                        var loDatasource  = LinqQuery.Where(
                                MyPrimaryKey + "  =  " + EntityBase.MyGetPrimaryKeyValue(pCurrentRecord, MyPrimaryKey),
                                null)
                            .ToDynamicList();
                        Columns.Clear();
                        DataSource = loDatasource;
                    }

                }
                catch (Exception)
                {

                    if (_editingState == Base4Crud.CrudActions.Add)
                    {
                        if (pOperationStatus != OperationStatus.Canceled)
                            DataSource = new BindingSource(((IQueryable)_context.GetPropValue(pTable)).ToDynamicList(), null);
                    }
                }

            }
            Invalidate();
        }


        private void MyBdNewBtn_Click(object sender, EventArgs e)
        {            
            if (IsFromBd)
                MyCreateFormToOpenFromBd(Base4Crud.CrudActions.Add);
            else
                MySetFormToOpen(Base4Crud.CrudActions.Add);           
            
        }

        private void MyBdEditBtn_Click(object sender, EventArgs e)
        {
            if (CurrentRow?.DataBoundItem == null) return;


            if (IsFromBd)
                MyCreateFormToOpenFromBd(Base4Crud.CrudActions.Edit);
            else
                MySetFormToOpen(Base4Crud.CrudActions.Edit);
            //MySetFormToOpen(MyCrud.CrudActions.Edit);
            
        }

        private void MyBdIdleBtn_Click(object sender, EventArgs e)
        {
            if (CurrentRow?.DataBoundItem == null) return;
            if (IsFromBd)
                MyCreateFormToOpenFromBd(Base4Crud.CrudActions.Idle);
            else
                MySetFormToOpen(Base4Crud.CrudActions.Idle);
        }

        private void _myBdDeleteButton_Click(object sender, EventArgs e)
        {
            if (Utils.IsInDesignMode) return;
            if (CurrentRow?.DataBoundItem == null) return;

            var dialog = BaseMessages.BaseShowMessages(@"Delete", @"Kaydı silmek istediğinizden emin misiniz?",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialog != DialogResult.Yes) return;

                       

            try
            {
                var runtimeKnownDbSet = _context.GetPropValue(TableName);

                runtimeKnownDbSet.MyCallFunction("Remove", CurrentRow?.DataBoundItem);
                Rows.Remove(CurrentRow);
            }
            catch (Exception)
            {
                Rows.Remove(CurrentRow);
            }
            
            Invalidate();
        }

        #region MyToolStripProperties

        private readonly Base4ToolStrip _myTopToolStrip = new Base4ToolStrip();
        internal readonly ToolStripButton MySearchButton = new ToolStripButton();
        internal readonly ToolStripButton MyBdNewBtn = new ToolStripButton();
        internal readonly ToolStripButton MyBdEditBtn = new ToolStripButton();
        internal readonly ToolStripButton MyWatchBtn = new ToolStripButton();
        internal readonly ToolStripButton MyRemoveBtn = new ToolStripButton();

        #endregion

        #region Constructors

        //private readonly BaseConfiguration _baseConfiguration = new BaseConfiguration();

        public Base4GridView()
        {
            SetBaseConfigurations();
            
            RowHeadersVisible = false;            
            //BorderStyle = BorderStyle.None;
            
            MultiSelect = false;
            SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AllowUserToOrderColumns = false;
            AllowUserToResizeRows = false;            
           
            AllowUserToAddRows = false;
            AllowUserToDeleteRows = false;
            AutoGenerateColumns = true;
            ReadOnly = true;
            
            DoubleBuffered = true;
            VirtualMode = true;
            
            MyAddToolStripButtons();
            ParentChanged += MyGridView_ParentChanged;        
            Disposed += MyGridView_Disposed;
            _myTopToolStrip.Location = Location;
            DataSourceChanged += MyBdGridView_DataSourceChanged;
            Dock = DockStyle.Fill;
            DataError += MyBdGridView_DataError;

          
            BindingContextChanged += Base4GridView_BindingContextChanged;

            HandleCreated += Base4GridView_HandleCreated;
            Columns.CollectionChanged += Columns_CollectionChanged;
            CellFormatting += Base4GridView_CellFormatting;

            DoubleClick += Base4GridView_DoubleClick;

            this.KeyDown += Base4GridView_KeyDown;
        }

        private void Base4GridView_KeyDown(object sender, KeyEventArgs e)
        {
            //CONTACTS_BASE A = null;
            //A.Age = 12;
         
            if (e.KeyCode == Keys.R && e.Control)
            {
                if(CurrentRow?.DataBoundItem == null) return;

                var currentresourcemanager = ParentResourceManager ?? Base4Entity.Properties.Resources.ResourceManager;
                try
                {
                    ((List<dynamic>)DataSource).ToExcelSheet(currentresourcemanager);
                }
                catch (Exception a)
                {
                    var rowsItems = Rows.ToDynamicList();
                    var dataList = (from DataGridViewRow row in rowsItems select row.DataBoundItem).ToList();
                    dataList.ToExcelSheet(currentresourcemanager);
                }
            }
        }

        private void Base4GridView_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                var primaryKeyValue = CurrentRow.DataBoundItem.GetPropValue(MyPrimaryKey);
                BrowseDialogDelegateGrid.ReturnSelectedRow(primaryKeyValue);
             }
            catch (Exception)
            {
                if(BrowseDialogDelegateGrid != null)
                    Base4MessageBox.Show(this, "No Rows are Selected ", "Error");

                
            }
        }

        private void Base4GridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            try
            {
                if (Rows[e.RowIndex].DataBoundItem != null &&
                    Columns[e.ColumnIndex].DataPropertyName.Contains("."))
                {
                    e.Value = BindProperty(
                        Rows[e.RowIndex].DataBoundItem,
                        Columns[e.ColumnIndex].DataPropertyName
                    );

                    var indexofDot = Columns[e.ColumnIndex].DataPropertyName.IndexOf(".", StringComparison.Ordinal);
                    var propertyName = Columns[e.ColumnIndex].DataPropertyName.Substring(indexofDot + 1);


                    Columns[e.ColumnIndex].HeaderText = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(Columns[e.ColumnIndex].HeaderText)?.ToString() ?? Columns[e.ColumnIndex].HeaderText;
                }
            }
            catch (Exception)
            {               
            }
        }
        private string BindProperty(object property, string propertyName)
        {
            string retValue = "";

            if (propertyName.Contains("."))
            {
                var leftPropertyName = propertyName.Substring(0, propertyName.IndexOf(".", StringComparison.Ordinal));
                var arrayProperties = property.GetType().GetProperties();

                foreach (var propertyInfo in arrayProperties)
                {
                    if (propertyInfo.Name != leftPropertyName) continue;
                    retValue = BindProperty(
                        propertyInfo.GetValue(property, null),
                        propertyName.Substring(propertyName.IndexOf(".") + 1));
                    break;
                }
            }
            else
            {
                var propertyType = property.GetType();
                var propertyInfo = propertyType.GetProperty(propertyName);
                retValue = propertyInfo?.GetValue(property, null).ToString();
            }

            return retValue;
        }
        private void Base4GridView_HandleCreated(object sender, EventArgs e)
        {
            _context = (DbContext)TopLevelControl?.GetPropValue("Context");
             TableName = EntityBase.MyGetTableName(DataSource);
        }


        private void Base4GridView_BindingContextChanged(object sender, EventArgs e)
        {
            try
            {
                ((Form)TopLevelControl).Load += Base4GridView_Load;

            }
            catch (Exception)
            {
                //continue
            }
            foreach (DataGridViewColumn column in Columns)
            {           
                column.HeaderText = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(column.HeaderText)?.ToString() ??
                                    column.HeaderText;
            }
        }

        private void Base4GridView_Load(object sender, EventArgs e)
        {
            //Console.WriteLine(Columns);
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;

            //ReNameColumns();
            foreach (DataGridViewColumn column in Columns)
            {

                column.HeaderText = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(column.HeaderText)?.ToString() ?? column.HeaderText;
               
                if (column.CellType != typeof(DataGridViewComboBoxCell)) continue;
                //try
                //{
                //    var tableName = ((BindingSource)((DataGridViewComboBoxColumn)column).DataSource).DataSource.GetPropValue("Name").ToString();
                //    ((BindingSource)((DataGridViewComboBoxColumn)column).DataSource).DataSource = ((IEnumerable)((Base4Crud)sender).Context.GetPropValue(tableName)).ToDynamicList();
                //}
                //catch (Exception)
                //{
                //}

                ((DataGridViewComboBoxColumn)column).DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
            }
        }
        public void ReNameColumns()
        {
            foreach (DataGridViewColumn column in Columns)
            {
                column.HeaderText = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(column.HeaderText)?.ToString() ?? column.HeaderText;
            }
            Invalidate();
        }

        private void Columns_CollectionChanged(object sender, CollectionChangeEventArgs e)
        {
           ReNameColumns();
          
        }
        private void MyBdGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
        }

        private void MyBdGridView_DataSourceChanged(object sender, EventArgs e)
        {            

            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;
            MyGetPrimaryKeyValueFromBd();            

        }

        #endregion

        #region ToolStripFunctions        

        private void AutoAddTopToolStrip()
        {
            if (Parent == null) return;

            //_myTopToolStrip.Dock = DockStyle.None;
            _myTopToolStrip.GripStyle = ToolStripGripStyle.Hidden;
            _myTopToolStrip.Height = 200;
            BorderStyle = BorderStyle.Fixed3D;
            _myTopToolStrip.Width = Width;
            Parent.Controls.Add(_myTopToolStrip);
        }

        private void MyAddToolStripButtons()
        {
            MySearchButton.Text = @"Search";
            MySearchButton.TextImageRelation = TextImageRelation.ImageBeforeText;
            //MySearchButton.Image = _search;
            MySearchButton.Visible = false;
            _myTopToolStrip.Items.Insert(0, MySearchButton);

            MyBdNewBtn.Text = @"Add New";
            MyBdNewBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            //MyBdNewBtn.Image = _addNew;
            _myTopToolStrip.Items.Insert(1, MyBdNewBtn);
            MyBdNewBtn.Click += MyBdNewBtn_Click;

            MyBdEditBtn.Text = @"Edit";
            MyBdEditBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            //MyBdEditBtn.Image = _edit;
            _myTopToolStrip.Items.Insert(2, MyBdEditBtn);
            MyBdEditBtn.Click += MyBdEditBtn_Click;

            MyWatchBtn.Text = @"Watch";
            //MyWatchBtn.Image = _find;
            MyWatchBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            _myTopToolStrip.Items.Insert(3, MyWatchBtn);
            MyWatchBtn.Click += MyBdIdleBtn_Click;

            MyRemoveBtn.Text = @"Remove";
            //MyRemoveBtn.Image = _remove;
            MyRemoveBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            _myTopToolStrip.Items.Insert(4, MyRemoveBtn);
            MyRemoveBtn.Click += _myBdDeleteButton_Click;
        }

        #endregion

        #region GridViewEvents

        private void MyGridView_ParentChanged(object sender, EventArgs e)
        {
            AutoAddTopToolStrip();            
        }

        private void MyGridView_Disposed(object sender, EventArgs e)
        {
         
            //_baseConfiguration.Dispose();          

            _myTopToolStrip.Dispose();
        }

        public void HideButtons()
        {
            //MySearchButton.Visible = false;
            MyBdEditBtn.Visible = false;
            MyWatchBtn.Visible = false;
            MyBdNewBtn.Visible = false;
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        private bool _watchOnly;
        [Category("Base4 Appearance")]
        //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public bool WatchOnly
        {
            get => _watchOnly;
            set
            {
             
                _watchOnly = value;

                if (IsFromBd)
                {
                    MyBdEditBtn.Visible = !_watchOnly;
                    MyBdNewBtn.Visible = !_watchOnly;
                    //MyRemoveBtn.Visible = !_watchOnly;
                }
                else
                {
                    MyBdEditBtn.Visible = !_watchOnly;
                    MyBdNewBtn.Visible = !_watchOnly;
                    MyRemoveBtn.Visible = !_watchOnly;

                }
               
            }
        }
       

        private void SetBaseConfigurations()
        {
            
            MyBdNewBtn.Image = BaseConfigurations.BaseConfigurations.NewBtnImage;
            MySearchButton.Image = BaseConfigurations.BaseConfigurations.SearchBtnImage;
            MyBdEditBtn.Image = BaseConfigurations.BaseConfigurations.EditBtnImage;
            MyRemoveBtn.Image = BaseConfigurations.BaseConfigurations.RemoveBtnImage;
            MyWatchBtn.Image = BaseConfigurations.BaseConfigurations.WatchBtnImage;          
        }

        #endregion

       
    }
}
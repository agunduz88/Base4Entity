﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Base4Controls.Components;
using Base4Controls.Controls;

namespace Base4Entity.MyUIControls.Controls
{
    public class Base4CheckBox:BaseCheckBox
    {
      
        public Base4CheckBox()
        {
            
            BindingContextChanged += Base4CheckBox_BindingContextChanged;

            _label = new Base4Label();          
            _label.Resize += _label_Resize;

            HandleCreated += Base4CheckBox_HandleCreated;

            Disposed += Base4CheckBox_Disposed;
            DataBindings.DefaultDataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;
        }

       

        private void Base4CheckBox_HandleCreated(object sender, EventArgs e)
        {
            ResetText();
            Text = @" ";
        }

     
        private void Base4CheckBox_BindingContextChanged(object sender, EventArgs e)
        {           
            try
            {
                BindingField = DataBindings.BindableComponent.DataBindings[0].BindingMemberInfo.BindingField;
                FieldName = DataBindings.BindableComponent.DataBindings[0].BindingMemberInfo.BindingField;
                ((Form)TopLevelControl).Load += Base4CheckBox_Load;
            }
            catch (Exception)
            {
                //continue
            }
            
        }

        private void Base4CheckBox_Load(object sender, EventArgs e)
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;
        }


        #region LabelAndRules
        private string _bindingField;

        [Browsable(false)]
        public string BindingField
        {
            get => _bindingField;
            set
            {

                _bindingField = value;
                if (BindingField != null)
                    _label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(BindingField)?.ToString() ?? value;
            }
        }


        private string _fieldName;
        [Category("Data")]
        public string FieldName
        {
            get => _fieldName;
            set
            {
                //if(value == null) return;
                _fieldName = value;
                _label.Text = BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(value)?.ToString() == null
                    ? value
                    : (BaseConfigurations.BaseConfigurations.Base4Resources.GetObject(BindingField)?.ToString() ?? BindingField);
            }
        }
        private Base4Label _label;
        private bool _hasRules;
        //_label = new Base4Label()
        //{
        //    AutoSize = true,
        //    Font = Font,
        //    Location = Location
        //};
        Base4ToolTip requiredToolTip = new Base4ToolTip
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme,
            Style = BaseConfigurations.BaseConfigurations.Style,
            ToolTipIcon = ToolTipIcon.Error,
            ShowAlways = true
        };

        private string _errrorMessage;
        public void SetErrorMessage(string pErrorMessage)
        {
            _errrorMessage = pErrorMessage;
            HasRules = true;
        }


        private void _label_Resize(object sender, EventArgs e)
        {
            MoveLabel();
        }


        private void Base4CheckBox_Disposed(object sender, EventArgs e)
        {
            _label.Dispose();
        }


        protected override void OnParentChanged(EventArgs e)
        {
            base.OnParentChanged(e);
            _label.Parent = Parent;

        }
        protected override void OnLocationChanged(EventArgs e)
        {
            base.OnLocationChanged(e);
            MoveLabel();
        }
        private void MoveLabel()
        {
            _label.Location = new Point(Left - _label.Width - 10, Top -3);

        }
        [Category("Base4Data")]
        public string LabelName
        {
            get => _label.Text;
            set => _label.Text = value;
        }
        [Browsable(false)]
        public bool HasRules
        {
            get => _hasRules;
            set
            {
                _hasRules = value;
                if (HasRules)
                {
                    requiredToolTip.SetToolTip(this, _errrorMessage);
                    UseCustomBackColor = true;
                    BackColor = BaseConfigurations.BaseConfigurations.StyleColor;
                    
                }
                else
                {
                    requiredToolTip.RemoveAll();
                    BackColor = BaseConfigurations.BaseConfigurations.ThemeColor;
                }

            }
        }

        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Windows.Forms;
using Base4Entity.EFHelper;
using Base4Entity.Extensions;

namespace Base4Entity.MyUIControls.Controls
{
    //[EditorBrowsable(EditorBrowsableState.)]

    public class MyLbComboBox : ComboBox
    {        
        //#region HidedProperties
        //[Browsable(false)]
        //public new string AccessibleDescription
        //{
        //    get => base.AccessibleDescription;
        //    set => base.AccessibleDescription = value;
        //}

        //[Browsable(false)]
        //public new string AccessibleName
        //{
        //    get => base.AccessibleName;
        //    set => base.AccessibleName = value;
        //}

        //[Browsable(false)]
        //public new AccessibleRole AccessibleRole
        //{
        //    get => base.AccessibleRole;
        //    set => base.AccessibleRole = value;
        //}

        //[Browsable(false)]
        //public new bool AllowDrop
        //{
        //    get => base.AllowDrop;
        //    set => base.AllowDrop = value;
        //}

        //[Browsable(false)]
        //public new AnchorStyles Anchor
        //{
        //    get => base.Anchor;
        //    set => base.Anchor = value;
        //}

        //[Browsable(false)]
        //public new AutoCompleteStringCollection AutoCompleteCustomSource
        //{
        //    get => base.AutoCompleteCustomSource;
        //    set => base.AutoCompleteCustomSource = value;
        //}

        //[Browsable(false)]
        //public new AutoCompleteMode AutoCompleteMode
        //{
        //    get => base.AutoCompleteMode;
        //    set => base.AutoCompleteMode = value;
        //}

        //[Browsable(false)]
        //public new AutoCompleteSource AutoCompleteSource
        //{
        //    get => base.AutoCompleteSource;
        //    set => base.AutoCompleteSource = value;
        //}

        //[Browsable(false)]
        //public new Color BackColor
        //{
        //    get => base.BackColor;
        //    set => base.BackColor = value;
        //}

        //[Browsable(false)]
        //public new bool CausesValidation
        //{
        //    get => base.CausesValidation;
        //    set => base.CausesValidation = value;
        //}

        //[Browsable(false)]
        //public new ContextMenuStrip ContextMenuStrip
        //{
        //    get => base.ContextMenuStrip;
        //    set => base.ContextMenuStrip = value;
        //}

        //[Browsable(false)]
        //public new Cursor Cursor
        //{
        //    get => base.Cursor;
        //    set => base.Cursor = value;
        //}

        //[Browsable(false)]
        //public new DockStyle Dock
        //{
        //    get => base.Dock;
        //    set => base.Dock = value;
        //}

        //[Browsable(false)]
        //public new DrawMode DrawMode
        //{
        //    get => base.DrawMode;
        //    set => base.DrawMode = value;
        //}

        //[Browsable(false)]
        //public new int DropDownHeight
        //{
        //    get => base.DropDownHeight;
        //    set => base.DropDownHeight = value;
        //}

        //[Browsable(false)]
        //public new ComboBoxStyle DropDownStyle
        //{
        //    get => base.DropDownStyle;
        //    set => base.DropDownStyle = value;
        //}

        //[Browsable(false)]
        //public new int DropDownWidth
        //{
        //    get => base.DropDownWidth;
        //    set => base.DropDownWidth = value;
        //}

        //[Browsable(false)]
        //public new bool Enabled
        //{
        //    get => base.Enabled;
        //    set => base.Enabled = value;
        //}

        //[Browsable(false)]
        //public new FlatStyle FlatStyle
        //{
        //    get => base.FlatStyle;
        //    set => base.FlatStyle = value;
        //}

        //[Browsable(false)]
        //public new Font Font
        //{
        //    get => base.Font;
        //    set => base.Font = value;
        //}

        //[Browsable(false)]
        //public new Color ForeColor
        //{
        //    get => base.ForeColor;
        //    set => base.ForeColor = value;
        //}

        //[Browsable(false)]
        //public new bool FormattingEnabled
        //{
        //    get => base.FormattingEnabled;
        //    set => base.FormattingEnabled = value;
        //}

        //[Browsable(false)]
        //public new ImeMode ImeMode
        //{
        //    get => base.ImeMode;
        //    set => base.ImeMode = value;
        //}

        //[Browsable(false)]
        //public new bool IntegralHeight
        //{
        //    get => base.IntegralHeight;
        //    set => base.IntegralHeight = value;
        //}

        //[Browsable(false)]
        //public new int ItemHeight
        //{
        //    get => base.ItemHeight;
        //    set => base.ItemHeight = value;
        //}

        //[Browsable(false)]
        //public new ObjectCollection Items
        //{
        //    get => base.Items;
        //    //set => base.Items = value;
        //}

        //[Browsable(false)]
        //public new string FormatString
        //{
        //    get => base.FormatString;
        //    set => base.FormatString = value;
        //}

        //[Browsable(false)]
        //public new Point Location
        //{
        //    get => base.Location;
        //    set => base.Location = value;
        //}

        //[Browsable(false)]
        //public new Padding Margin
        //{
        //    get => base.Margin;
        //    set => base.Margin = value;
        //}

        //[Browsable(false)]
        //public new Size MaximumSize
        //{
        //    get => base.MaximumSize;
        //    set => base.MaximumSize = value;
        //}

        //[Browsable(false)]
        //public new int MaxLength
        //{
        //    get => base.MaxLength;
        //    set => base.MaxLength = value;
        //}

        //[Browsable(false)]
        //public new Size MinimumSize
        //{
        //    get => base.MinimumSize;
        //    set => base.MinimumSize = value;
        //}

        //[Browsable(false)]
        //public new RightToLeft RightToLeft
        //{
        //    get => base.RightToLeft;
        //    set => base.RightToLeft = value;
        //}

        //[Browsable(false)]
        //public new Size Size
        //{
        //    get => base.Size;
        //    set => base.Size = value;
        //}

        //[Browsable(false)]
        //public new int TabIndex
        //{
        //    get => base.TabIndex;
        //    set => base.TabIndex = value;
        //}

        //[Browsable(false)]
        //public new bool UseWaitCursor
        //{
        //    get => base.UseWaitCursor;
        //    set => base.UseWaitCursor = value;
        //}

        //[Browsable(false)]
        //public new int MaxDropDownItems
        //{
        //    get => base.MaxDropDownItems;
        //    set => base.MaxDropDownItems = value;
        //}

        //[Browsable(false)]
        //public new bool TabStop
        //{
        //    get => base.TabStop;
        //    set => base.TabStop = value;
        //}

        //[Browsable(false)]
        //public new object Tag
        //{
        //    get => base.Tag;
        //    set => base.Tag = value;
        //}

        //[Browsable(false)]
        //public new string Text
        //{
        //    get => base.Text;
        //    set => base.Text = value;
        //}
       
        //#endregion

        private string _myBindingField;
        public string MyBindingField
        {
            get { return _myBindingField; }
            set { _myBindingField = value; }
        }
        private MyExpressions _myExpression = MyExpressions.Equals;
        public MyExpressions MyExpression
        {
            get { return _myExpression; }
            set { _myExpression = value; }
        }
        public MyLbComboBox()
        {
            DropDownStyle = ComboBoxStyle.DropDownList;
            DataSourceChanged += MyLbComboBox_DataSourceChanged;
            BindingContextChanged += MyLbComboBox_BindingContextChanged;
        }

        private void MyLbComboBox_BindingContextChanged(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }

        private void MyLbComboBox_DataSourceChanged(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }

        internal void MySetDropDownWidth()
        {
            var maxWidth = (from object obj in Items select TextRenderer.MeasureText(obj.GetPropValue(DisplayMember).ToString(), Font).Width).Concat(new[] { 0 }).Max();
            Width = maxWidth + 30;
        }

        internal void MyFillComboDataSource()
        {
            if (Utils.IsInDesignMode) return;

            if (DataSource == null)
                Console.WriteLine(@"Datasource is empty");

            var tableName = DataSource.GetPropValue("DataSource").GetPropValue("Name").ToString()
                .Contains("BindingSource")
                ? DataSource.GetPropValue("DataSource").GetPropValue("Name").ToString()
                    .Replace("BindingSource", "")
                : DataSource.GetPropValue("DataSource").GetPropValue("Name").ToString();

            using (var context = EntityBase.MyCreateNewDbContextInstance())
            {
                var data = ((IEnumerable)context.GetPropValue(tableName)).ToDynamicList();
                if (data.Count == 0) return;

                var projectName = Assembly.GetExecutingAssembly().GetName().Name;
                var fakeInstance = Assembly.GetExecutingAssembly().CreateInstance(projectName + "." + tableName);
                fakeInstance.SetPropertyValue(ValueMember, -1);
                fakeInstance.SetPropertyValue(DisplayMember, "<Seçiniz>");

                data.Insert(0, fakeInstance);
                DataSource = data;
            }
        }
    }  
}

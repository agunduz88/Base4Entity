﻿using System;
using Base4Controls.Controls;
using Base4Controls.Forms;
using Base4Entity.Extensions;

namespace Base4Entity.MyUIControls.Controls
{
public class Base4TabControl : BaseTabControl
    {

        public Base4TabControl()
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;            

            ParentChanged += Base4TabControl_ParentChanged;
        }

        private void Base4TabControl_ParentChanged(object sender, EventArgs e)
        {
            if (Utils.IsInDesignMode) return;
            if (TopLevelControl != null)
                ((BaseForm) TopLevelControl).Load += Base4TabControl_Load;
        }

        private void Base4TabControl_Load(object sender, EventArgs e)
        {
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;

            foreach (BaseTabPage variable in TabPages)
            {
                variable.Theme = BaseConfigurations.BaseConfigurations.Theme;
                variable.Style = BaseConfigurations.BaseConfigurations.Style;
            }
        }
        
    }
}

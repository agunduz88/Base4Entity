﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Base4Entity.EFHelper;

namespace Base4Entity.MyUIControls.Controls
{
     partial class MyLbTextBox2 : TextBox
    {
        #region HidedProperties

        [Browsable(false)]
        public new string AccessibleDescription
        {
            get => base.AccessibleDescription;
            set => base.AccessibleDescription = value;
        }

        [Browsable(false)]
        public new string AccessibleName
        {
            get => base.AccessibleName;
            set => base.AccessibleName = value;
        }

        [Browsable(false)]
        public new AccessibleRole AccessibleRole
        {
            get => base.AccessibleRole;
            set => base.AccessibleRole = value;
        }

        [Browsable(false)]
        public new bool AllowDrop
        {
            get => base.AllowDrop;
            set => base.AllowDrop = value;
        }

        [Browsable(false)]
        public new AnchorStyles Anchor
        {
            get => base.Anchor;
            set => base.Anchor = value;
        }

        [Browsable(false)]
        public new AutoCompleteStringCollection AutoCompleteCustomSource
        {
            get => base.AutoCompleteCustomSource;
            set => base.AutoCompleteCustomSource = value;
        }

        [Browsable(false)]
        public new AutoCompleteMode AutoCompleteMode
        {
            get => base.AutoCompleteMode;
            set => base.AutoCompleteMode = value;
        }

        [Browsable(false)]
        public new AutoCompleteSource AutoCompleteSource
        {
            get => base.AutoCompleteSource;
            set => base.AutoCompleteSource = value;
        }

        [Browsable(false)]
        public new Color BackColor
        {
            get => base.BackColor;
            set => base.BackColor = value;
        }

        [Browsable(false)]
        public new bool CausesValidation
        {
            get => base.CausesValidation;
            set => base.CausesValidation = value;
        }

        [Browsable(false)]
        public new ContextMenuStrip ContextMenuStrip
        {
            get => base.ContextMenuStrip;
            set => base.ContextMenuStrip = value;
        }

        [Browsable(false)]
        public new Cursor Cursor
        {
            get => base.Cursor;
            set => base.Cursor = value;
        }

        [Browsable(false)]
        public new DockStyle Dock
        {
            get => base.Dock;
            set => base.Dock = value;
        }



        [Browsable(false)]
        public new bool Enabled
        {
            get => base.Enabled;
            set => base.Enabled = value;
        }
        [Browsable(false)]
        public new Font Font
        {
            get => base.Font;
            set => base.Font = value;
        }

        [Browsable(false)]
        public new Color ForeColor
        {
            get => base.ForeColor;
            set => base.ForeColor = value;
        }
        [Browsable(false)]
        public new ImeMode ImeMode
        {
            get => base.ImeMode;
            set => base.ImeMode = value;
        }

        [Browsable(false)]
        public new Point Location
        {
            get => base.Location;
            set => base.Location = value;
        }

        [Browsable(false)]
        public new Padding Margin
        {
            get => base.Margin;
            set => base.Margin = value;
        }

        [Browsable(false)]
        public new Size MaximumSize
        {
            get => base.MaximumSize;
            set => base.MaximumSize = value;
        }

        [Browsable(false)]
        public new int MaxLength
        {
            get => base.MaxLength;
            set => base.MaxLength = value;
        }

        [Browsable(false)]
        public new Size MinimumSize
        {
            get => base.MinimumSize;
            set => base.MinimumSize = value;
        }

        [Browsable(false)]
        public new RightToLeft RightToLeft
        {
            get => base.RightToLeft;
            set => base.RightToLeft = value;
        }

        [Browsable(false)]
        public new Size Size
        {
            get => base.Size;
            set => base.Size = value;
        }

        [Browsable(false)]
        public new int TabIndex
        {
            get => base.TabIndex;
            set => base.TabIndex = value;
        }

        [Browsable(false)]
        public new bool UseWaitCursor
        {
            get => base.UseWaitCursor;
            set => base.UseWaitCursor = value;
        }


        [Browsable(false)]
        public new bool TabStop
        {
            get => base.TabStop;
            set => base.TabStop = value;
        }

        [Browsable(false)]
        public new object Tag
        {
            get => base.Tag;
            set => base.Tag = value;
        }

        [Browsable(false)]
        public new string Text
        {
            get => base.Text;
            set => base.Text = value;
        }

        [Browsable(false)]
        public new ControlBindingsCollection DataBindings
        {
            get => base.DataBindings;
        }

        [Browsable(false)]
        public new bool AcceptsReturn
        {
            get => base.AcceptsReturn;
            set => base.AcceptsReturn = value;
        }

        [Browsable(false)]
        public new bool AcceptsTab
        {
            get => base.AcceptsTab;
            set => base.AcceptsTab = value;
        }

        [Browsable(false)]
        public new BorderStyle BorderStyle
        {
            get => base.BorderStyle;
            set => base.BorderStyle = value;
        }

        [Browsable(false)]
        public new bool HideSelection
        {
            get => base.HideSelection;
            set => base.HideSelection = value;
        }

        [Browsable(false)]
        public new string[] Lines
        {
            get => base.Lines;
            set => base.Lines = value;
        }

        [Browsable(false)]
        public new char PasswordChar
        {
            get => base.PasswordChar;
            set => base.PasswordChar = value;
        }

        [Browsable(false)]
        public new bool ReadOnly
        {
            get => base.ReadOnly;
            set => base.ReadOnly = value;
        }

        [Browsable(false)]
        public new ScrollBars ScrollBars
        {
            get => base.ScrollBars;
            set => base.ScrollBars = value;
        }

        [Browsable(false)]
        public new bool ShortcutsEnabled
        {
            get => base.ShortcutsEnabled;
            set => base.ShortcutsEnabled = value;
        }

        [Browsable(false)]
        public new HorizontalAlignment TextAlign
        {
            get => base.TextAlign;
            set => base.TextAlign = value;
        }

        [Browsable(false)]
        public new bool UseSystemPasswordChar
        {
            get => base.UseSystemPasswordChar;
            set => base.UseSystemPasswordChar = value;
        }

        [Browsable(false)]
        public new bool Visible
        {
            get => base.Visible;
            set => base.Visible = value;
        }

        [Browsable(false)]
        public new bool WordWrap
        {
            get => base.WordWrap;
            set => base.WordWrap = value;
        }

        [Browsable(false)]
        public new bool Multiline
        {
            get => base.Multiline;
            set => base.Multiline = value;
        }

        #endregion
        #region TextBoxProperties
        public CharacterCasing CharacterCasing
        {
            get => myLbTextBox1.CharacterCasing;
            set => myLbTextBox1.CharacterCasing = value;
        }
        public string MyBindingField
        {
            get => myLbTextBox1.BindingField;
            set => myLbTextBox1.BindingField = value;
        }
        public MyExpressions MyExpression
        {
            get => myLbTextBox1.Expression;
            set => myLbTextBox1.Expression = value;
        }

        public object MyValue;
        #endregion
        private Label label;
        public MyLbTextBox2()
        {            
            InitializeComponent();                       
            label1.Dock = DockStyle.Left;            
            myLbTextBox1.Dock = DockStyle.Left;
            myLbTextBox1.AutoSize = true;
            myLbTextBox1.TextChanged += MyLbTextBox1_TextChanged;
            AutoSize = true;
        }

        private void MyLbTextBox1_TextChanged(object sender, EventArgs e)
        {
            MyValue = myLbTextBox1.Text;
        }
    }
}

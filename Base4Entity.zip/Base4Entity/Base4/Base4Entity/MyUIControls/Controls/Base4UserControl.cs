﻿using System;
using System.Windows.Forms;
using Base4Controls.Controls;

namespace Base4Entity.MyUIControls.Controls
{
    public partial class Base4UserControl : BaseUserControl
    {
        public Base4UserControl()
        {
            InitializeComponent();
            Theme = BaseConfigurations.BaseConfigurations.Theme;
            Style = BaseConfigurations.BaseConfigurations.Style;

            ControlAdded += Base4UserControl_ControlAdded;
        }

        private void Base4UserControl_ControlAdded(object sender, ControlEventArgs e)
        {
            try
            {
                ((dynamic)e.Control).Theme = BaseConfigurations.BaseConfigurations.Theme;
                ((dynamic)e.Control).Style = BaseConfigurations.BaseConfigurations.Style;
                //Style = BaseConfigurations.Style;
            }
            catch (Exception)
            {
                //Console.WriteLine(exception);
                //throw;
            }
        }

        public void ClearFields()
        {
            
        }
    }
}

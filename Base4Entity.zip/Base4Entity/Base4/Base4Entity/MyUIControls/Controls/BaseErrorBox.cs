﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using efcfwf.MyUIControls.Controls;

namespace Base4Entity.MyUIControls.Controls
{
    [EditorBrowsable(EditorBrowsableState.Never)]
    [Browsable(false)]
    public class BaseErrorBox:Form
    {               
        private const int CsDropshadow = 0x00020000;
    
        private readonly Panel _plHeader = new Panel();
        private readonly Label _lblTitle = new Label
        {
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 9,FontStyle.Bold),
            Dock = DockStyle.Top,

            Height = 20
        };        

        private readonly Panel _plIcon = new Panel();
        private readonly PictureBox _picIcon = new PictureBox();


        private readonly Label _lblMessage = new Label
        {
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 8),
            Padding = new Padding(8),
            Dock = DockStyle.Fill


        };

   
        private static Timer _timer;

        public BaseErrorBox(string message, string title, Animations.Icon icon, Animations.AnimateStyle style)
        {
            FormBorderStyle = FormBorderStyle.None;
            BackColor = Color.FromArgb(45, 45, 48);
            Padding = new Padding(5);
            
            _plHeader.Dock = DockStyle.Fill;
            _plHeader.Padding = new Padding(0);
            _plHeader.Controls.Add(_lblMessage);
            _plHeader.Controls.Add(_lblTitle);

            _picIcon.Width = 32;
            _picIcon.Height = 32;
            _picIcon.Location = new Point(20, 20);

            _plIcon.Dock = DockStyle.Left;
            _plIcon.Padding = new Padding(20);
            _plIcon.Width = 70;
            _plIcon.Controls.Add(_picIcon);

            Controls.Add(_plHeader);
            Controls.Add(_plIcon);
            Set(message, title, icon, style);
            Closed += BaseErrorBox_Closed;
        }

        public BaseErrorBox(string message, string title, Animations.Icon icon)
        {
            FormBorderStyle = FormBorderStyle.None;
            BackColor = Color.FromArgb(45, 45, 48);
            Padding = new Padding(5);

            _plHeader.Dock = DockStyle.Fill;
            _plHeader.Padding = new Padding(0);
            _plHeader.Controls.Add(_lblMessage);
            _plHeader.Controls.Add(_lblTitle);

            _picIcon.Width = 32;
            _picIcon.Height = 32;
            _picIcon.Location = new Point(20, 20);

            _plIcon.Dock = DockStyle.Left;
            _plIcon.Padding = new Padding(20);
            _plIcon.Width = 70;
            _plIcon.Controls.Add(_picIcon);

            Controls.Add(_plHeader);
            Controls.Add(_plIcon);
            Set(message, title, icon);
            Closed += BaseErrorBox_Closed;
        }

        public BaseErrorBox(string message, string title)
        {
            FormBorderStyle = FormBorderStyle.None;
            BackColor = Color.FromArgb(45, 45, 48);
            Padding = new Padding(5);

            _plHeader.Dock = DockStyle.Fill;
            _plHeader.Padding = new Padding(0);
            _plHeader.Controls.Add(_lblMessage);
            _plHeader.Controls.Add(_lblTitle);

            _picIcon.Width = 32;
            _picIcon.Height = 32;
            _picIcon.Location = new Point(20, 20);

            _plIcon.Dock = DockStyle.Left;
            _plIcon.Padding = new Padding(20);
            _plIcon.Width = 70;
            _plIcon.Controls.Add(_picIcon);

            Controls.Add(_plHeader);
            Controls.Add(_plIcon);
            Set(message, title);
            Closed += BaseErrorBox_Closed;
            
        }

        private void BaseErrorBox_Closed(object sender, EventArgs e)
        {
            _plHeader.Dispose();
            _lblTitle.Dispose();
            _plIcon.Dispose();
            _picIcon.Dispose();
            _lblMessage.Dispose();
            _timer.Dispose();
        }

        //private void BaseErrorBox_Deactivate(object sender, EventArgs e)
        //{
        //    Close();
        //}
        public sealed override Color BackColor
        {
            get => base.BackColor;
            set => base.BackColor = value;
        }
       
        private  void InitIcon(Animations.Icon icon)
        {
            switch (icon)
            {
                case Animations.Icon.Application:
                    _picIcon.Image = SystemIcons.Application.ToBitmap();
                    break;

                case Animations.Icon.Exclamation:
                    _picIcon.Image = SystemIcons.Exclamation.ToBitmap();
                    break;

                case Animations.Icon.Error:
                    _picIcon.Image = SystemIcons.Error.ToBitmap();
                    break;

                case Animations.Icon.Info:
                    _picIcon.Image = SystemIcons.Information.ToBitmap();
                    break;

                case Animations.Icon.Question:
                    _picIcon.Image = SystemIcons.Question.ToBitmap();
                    break;

                case Animations.Icon.Shield:
                    _picIcon.Image = SystemIcons.Shield.ToBitmap();
                    break;

                case Animations.Icon.Warning:
                    _picIcon.Image = SystemIcons.Warning.ToBitmap();
                    break;
            }
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            Capture = true;
            //this.();
        }

        protected override void OnMouseCaptureChanged(EventArgs e)
        {
            if (!Capture)
            {
                if (!RectangleToScreen(DisplayRectangle).Contains(Cursor.Position))
                {
                    Close();
                    using (this)
                    {
                        //disposing messagebox
                    }                    
                }
                else
                {
                    Capture = true;
                }
            }

            base.OnMouseCaptureChanged(e);
        }

        private  Size MessageSize(string message)
        {
            var g = CreateGraphics();
            var width = 350;
            
            int ExtraHeight = (message.Split('\n').Length -1) * 5;
            var height =  80 + ExtraHeight;
            var size = g.MeasureString(message, new Font("Segoe UI", 8));

            if (message.Length < 150)
            {
                if ((int)size.Width > 350)
                {
                    width = (int)size.Width;
                }
            }
            else
            {
                string[] groups = (from Match m in Regex.Matches(message, ".{1,180}") select m.Value).ToArray();
                int lines = groups.Length + 1;
                width = 700;
                height += (int)(size.Height + 10) * lines;
            }
            return new Size(width, height);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ClassStyle |= CsDropshadow;
                return cp;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;
            Rectangle rect = new Rectangle(new Point(0, 0), new Size(Width - 1, Height - 1));
            Pen pen = new Pen(Color.FromArgb(0, 151, 251));

            g.DrawRectangle(pen, rect);
        }

        private  void timer_Tick(object sender, EventArgs e)
        {
            var timer = (Timer)sender;
            var animate = (Animations)timer.Tag;

            switch (animate.Style)
            {
                case Animations.AnimateStyle.SlideDown:
                    if (Height < animate.FormSize.Height)
                    {
                        Height += 17;
                        Invalidate();
                    }
                    else
                    {
                        _timer.Stop();
                        _timer.Dispose();
                    }
                    break;

                case Animations.AnimateStyle.FadeIn:
                    if (Opacity < 1)
                    {
                        Opacity += 0.1;
                        Invalidate();
                    }
                    else
                    {
                        _timer.Stop();
                        _timer.Dispose();
                    }
                    break;

                case Animations.AnimateStyle.ZoomIn:
                    if (Width > animate.FormSize.Width)
                    {
                        Width -= 17;
                        Invalidate();
                    }
                    if (Height > animate.FormSize.Height)
                    {
                        Height -= 17;
                        Invalidate();
                    }
                    break;
            }
        }



        private  void Set(string message, string title)
        {

            _lblMessage.Text = message;
            _lblTitle.Text = title;
            Size = MessageSize(message);
        }



        private void Set(string message, string title, Animations.Icon icon)
        {

            _lblMessage.Text = message;
            _lblTitle.Text = title;

            InitIcon(icon);

            Size = MessageSize(message);

        }
        private  void Set(string message, string title, Animations.Icon icon, Animations.AnimateStyle style)
        {
         
            _lblMessage.Text = message;
            _lblTitle.Text = title;
            Height = 0;

        
            InitIcon(icon);

            _timer = new Timer();
            var formSize = MessageSize(message);

            switch (style)
            {
                case Animations.AnimateStyle.SlideDown:
                    Size = new Size(formSize.Width, 0);
                    _timer.Interval = 1;
                    _timer.Tag = new Animations(formSize, style);
                    break;

                case Animations.AnimateStyle.FadeIn:
                    Size = formSize;
                    Opacity = 0;
                    _timer.Interval = 20;
                    _timer.Tag = new Animations(formSize, style);
                    break;

                case Animations.AnimateStyle.ZoomIn:
                    Size = new Size(formSize.Width + 100, formSize.Height + 100);
                    _timer.Tag = new Animations(formSize, style);
                    _timer.Interval = 1;
                    break;
            }

            _timer.Tick += timer_Tick;
            _timer.Start();
          
        }
    }
   
}

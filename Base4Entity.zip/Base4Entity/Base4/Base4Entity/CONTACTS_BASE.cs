namespace Base4Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CONTACTS_BASE
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CONTACTS_BASE()
        {
            ORDERS = new HashSet<ORDER>();
        }

        [Key]
        public int CB_REFNO { get; set; }

        [Required]
        public string CB_NAME { get; set; }

        [Required]
        public string CB_SURNAME { get; set; }

        public string CB_TELNO { get; set; }

        public int? Age { get; set; }

        public DateTime? CB_REG_DATE { get; set; }

        [StringLength(128)]
        public string CB_SPORTS_REFNO { get; set; }

        public virtual SPORT SPORT { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ORDER> ORDERS { get; set; }
    }
}

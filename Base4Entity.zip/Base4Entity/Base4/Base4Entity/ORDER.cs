namespace Base4Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ORDERS")]
    public partial class ORDER
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ORDER()
        {
            ORDER_DETAILS = new HashSet<ORDER_DETAILS>();
        }

        [Key]
        public int OR_ROWID { get; set; }

        public int? OR_REFNO { get; set; }

        [StringLength(128)]
        public string OR_PROD_CODE { get; set; }

        [Required]
        public string OR_NAME { get; set; }

        public DateTime? OR_DATE { get; set; }

        public bool OR_AVAILABLE { get; set; }

        public virtual CONTACTS_BASE CONTACTS_BASE { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ORDER_DETAILS> ORDER_DETAILS { get; set; }

        public virtual ORDER_TYPES ORDER_TYPES { get; set; }
    }
}

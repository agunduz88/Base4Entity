﻿using System.Windows.Forms;

namespace Base4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
